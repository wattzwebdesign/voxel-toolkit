<?php
/**
 * Duplicate Post Elementor Widget
 *
 * @package Voxel_Toolkit
 */

if (!defined('ABSPATH')) {
    exit;
}

class Voxel_Toolkit_Duplicate_Post_Widget extends \Elementor\Widget_Base {
    
    /**
     * Get widget name
     */
    public function get_name() {
        return 'voxel-toolkit-duplicate-post';
    }
    
    /**
     * Get widget title
     */
    public function get_title() {
        return __('Duplicate Post (VT)', 'voxel-toolkit');
    }
    
    /**
     * Get widget icon
     */
    public function get_icon() {
        return 'eicon-copy';
    }
    
    /**
     * Get widget categories
     */
    public function get_categories() {
        return ['voxel-toolkit'];
    }
    
    /**
     * Register widget controls
     */
    protected function _register_controls() {
        // Content Section
        $this->start_controls_section(
            'content_section',
            [
                'label' => __('Content', 'voxel-toolkit'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );
        
        $this->add_control(
            'button_text',
            [
                'label' => __('Button Text', 'voxel-toolkit'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Duplicate Post', 'voxel-toolkit'),
                'placeholder' => __('Enter button text', 'voxel-toolkit'),
            ]
        );
        
        $this->add_control(
            'redirect_type',
            [
                'label' => __('Redirect After Duplicate', 'voxel-toolkit'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'create_page',
                'options' => [
                    'create_page' => __('Create/Edit Page', 'voxel-toolkit'),
                    'current_page' => __('Current Page', 'voxel-toolkit'),
                ],
            ]
        );
        
        $this->add_control(
            'copying_text',
            [
                'label' => __('Copying Text', 'voxel-toolkit'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Duplicating...', 'voxel-toolkit'),
                'placeholder' => __('Enter text shown while copying', 'voxel-toolkit'),
                'description' => __('Text displayed on button while duplication is in progress', 'voxel-toolkit'),
            ]
        );
        
        $this->add_control(
            'title_suffix',
            [
                'label' => __('Title Suffix', 'voxel-toolkit'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('(Copy)', 'voxel-toolkit'),
                'placeholder' => __('Enter suffix for duplicated title', 'voxel-toolkit'),
                'description' => __('Text added to the end of the duplicated post title', 'voxel-toolkit'),
            ]
        );
        
        $this->end_controls_section();
        
        // Button Style Section
        $this->start_controls_section(
            'button_style_section',
            [
                'label' => __('Button Style', 'voxel-toolkit'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
        
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'button_typography',
                'selector' => '{{WRAPPER}} .voxel-toolkit-duplicate-btn',
            ]
        );
        
        $this->start_controls_tabs('button_style_tabs');
        
        // Normal State
        $this->start_controls_tab(
            'button_normal',
            [
                'label' => __('Normal', 'voxel-toolkit'),
            ]
        );
        
        $this->add_control(
            'button_text_color',
            [
                'label' => __('Text Color', 'voxel-toolkit'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} .voxel-toolkit-duplicate-btn' => 'color: {{VALUE}};',
                ],
            ]
        );
        
        $this->add_group_control(
            \Elementor\Group_Control_Background::get_type(),
            [
                'name' => 'button_background',
                'label' => __('Background', 'voxel-toolkit'),
                'types' => ['classic', 'gradient'],
                'selector' => '{{WRAPPER}} .voxel-toolkit-duplicate-btn',
            ]
        );
        
        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name' => 'button_border',
                'selector' => '{{WRAPPER}} .voxel-toolkit-duplicate-btn',
            ]
        );
        
        $this->add_control(
            'button_border_radius',
            [
                'label' => __('Border Radius', 'voxel-toolkit'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .voxel-toolkit-duplicate-btn' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        
        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'button_box_shadow',
                'selector' => '{{WRAPPER}} .voxel-toolkit-duplicate-btn',
            ]
        );
        
        $this->add_responsive_control(
            'button_padding',
            [
                'label' => __('Padding', 'voxel-toolkit'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .voxel-toolkit-duplicate-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        
        $this->end_controls_tab();
        
        // Hover State
        $this->start_controls_tab(
            'button_hover',
            [
                'label' => __('Hover', 'voxel-toolkit'),
            ]
        );
        
        $this->add_control(
            'button_text_color_hover',
            [
                'label' => __('Text Color', 'voxel-toolkit'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .voxel-toolkit-duplicate-btn:hover' => 'color: {{VALUE}};',
                ],
            ]
        );
        
        $this->add_group_control(
            \Elementor\Group_Control_Background::get_type(),
            [
                'name' => 'button_background_hover',
                'label' => __('Background', 'voxel-toolkit'),
                'types' => ['classic', 'gradient'],
                'selector' => '{{WRAPPER}} .voxel-toolkit-duplicate-btn:hover',
            ]
        );
        
        $this->add_control(
            'button_border_color_hover',
            [
                'label' => __('Border Color', 'voxel-toolkit'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .voxel-toolkit-duplicate-btn:hover' => 'border-color: {{VALUE}};',
                ],
            ]
        );
        
        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'button_box_shadow_hover',
                'selector' => '{{WRAPPER}} .voxel-toolkit-duplicate-btn:hover',
            ]
        );
        
        $this->add_control(
            'button_hover_animation',
            [
                'label' => __('Hover Animation', 'voxel-toolkit'),
                'type' => \Elementor\Controls_Manager::HOVER_ANIMATION,
            ]
        );
        
        $this->end_controls_tab();
        
        $this->end_controls_tabs();
        
        $this->add_responsive_control(
            'button_align',
            [
                'label' => __('Alignment', 'voxel-toolkit'),
                'type' => \Elementor\Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => __('Left', 'voxel-toolkit'),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => __('Center', 'voxel-toolkit'),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => __('Right', 'voxel-toolkit'),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'default' => 'left',
                'selectors' => [
                    '{{WRAPPER}} .voxel-toolkit-duplicate-wrapper' => 'text-align: {{VALUE}};',
                ],
                'separator' => 'before',
            ]
        );
        
        $this->end_controls_section();
    }
    
    /**
     * Render the widget
     */
    protected function render() {
        global $post;
        
        if (!$post) {
            if (\Elementor\Plugin::$instance->editor->is_edit_mode()) {
                echo '<div class="voxel-toolkit-duplicate-wrapper">';
                echo '<button class="voxel-toolkit-duplicate-btn elementor-button">Preview Mode: Duplicate Button</button>';
                echo '</div>';
            }
            return;
        }
        
        $settings = $this->get_settings_for_display();
        $button_text = !empty($settings['button_text']) ? $settings['button_text'] : __('Duplicate Post', 'voxel-toolkit');
        $redirect_type = $settings['redirect_type'];
        $copying_text = !empty($settings['copying_text']) ? $settings['copying_text'] : __('Duplicating...', 'voxel-toolkit');
        $title_suffix = !empty($settings['title_suffix']) ? $settings['title_suffix'] : __('(Copy)', 'voxel-toolkit');
        
        // Check if duplication is enabled for this post type and if user can duplicate
        $settings_instance = Voxel_Toolkit_Settings::instance();
        $duplicate_settings = $settings_instance->get_function_settings('duplicate_post', array());
        
        // First check if duplicate post function is enabled
        if (!isset($duplicate_settings['enabled']) || !$duplicate_settings['enabled']) {
            if (\Elementor\Plugin::$instance->editor->is_edit_mode()) {
                echo '<div class="voxel-toolkit-duplicate-wrapper">';
                echo '<button class="voxel-toolkit-duplicate-btn elementor-button" disabled>Duplication Disabled</button>';
                echo '</div>';
            }
            return;
        }
        
        // Check if enabled for this post type
        $enabled_post_types = isset($duplicate_settings['post_types']) ? $duplicate_settings['post_types'] : array();
        if (!in_array($post->post_type, $enabled_post_types)) {
            if (\Elementor\Plugin::$instance->editor->is_edit_mode()) {
                echo '<div class="voxel-toolkit-duplicate-wrapper">';
                echo '<button class="voxel-toolkit-duplicate-btn elementor-button" disabled>Not Enabled for This Post Type</button>';
                echo '</div>';
            }
            return;
        }
        
        // Check if user can duplicate based on role settings
        $can_duplicate = false;
        
        // Check if user is logged in and has permission based on settings
        if (is_user_logged_in()) {
            $allowed_roles = isset($duplicate_settings['allowed_roles']) ? $duplicate_settings['allowed_roles'] : array('contributor', 'author', 'editor', 'administrator');
            
            // If "all_roles" is selected, allow everyone
            if (in_array('all_roles', $allowed_roles)) {
                $can_duplicate = true;
            } else {
                // Check if user has any of the allowed roles
                $user = wp_get_current_user();
                $user_roles = $user->roles;
                
                foreach ($user_roles as $role) {
                    if (in_array($role, $allowed_roles)) {
                        $can_duplicate = true;
                        break;
                    }
                }
            }
        }
        
        if (!$can_duplicate) {
            if (\Elementor\Plugin::$instance->editor->is_edit_mode()) {
                echo '<div class="voxel-toolkit-duplicate-wrapper">';
                echo '<button class="voxel-toolkit-duplicate-btn elementor-button" disabled>Login Required</button>';
                echo '</div>';
            }
            return;
        }
        
        $hover_class = '';
        if (!empty($settings['button_hover_animation'])) {
            $hover_class = 'elementor-animation-' . $settings['button_hover_animation'];
        }
        
        ?>
        <div class="voxel-toolkit-duplicate-wrapper">
            <button class="voxel-toolkit-duplicate-btn elementor-button <?php echo esc_attr($hover_class); ?>" 
                    data-post-id="<?php echo esc_attr($post->ID); ?>"
                    data-redirect="<?php echo esc_attr($redirect_type); ?>"
                    data-copying-text="<?php echo esc_attr($copying_text); ?>"
                    data-title-suffix="<?php echo esc_attr($title_suffix); ?>">
                <?php echo esc_html($button_text); ?>
            </button>
        </div>
        <?php
    }
}