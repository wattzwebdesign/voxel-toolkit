<?php
/**
 * Admin Columns Feature
 *
 * Configure custom columns for Voxel post types in WordPress admin list tables.
 *
 * @package Voxel_Toolkit
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

class Voxel_Toolkit_Admin_Columns {

    /**
     * Singleton instance
     */
    private static $instance = null;

    /**
     * Column renderer instance
     */
    private $renderer = null;

    /**
     * Column types instance
     */
    private $column_types = null;

    /**
     * Get singleton instance
     */
    public static function instance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Constructor
     */
    private function __construct() {
        // Only run in admin
        if (!is_admin()) {
            return;
        }

        $this->load_dependencies();
        $this->init_hooks();
    }

    /**
     * User columns instance
     */
    private $user_columns = null;

    /**
     * Filter logic (AND/OR)
     */
    private $filter_logic = 'AND';

    /**
     * All filters for combined processing
     */
    private $all_post_filters = array();

    /**
     * Current post type being filtered
     */
    private $filtering_post_type = null;

    /**
     * Load required files
     */
    private function load_dependencies() {
        require_once VOXEL_TOOLKIT_PLUGIN_DIR . 'includes/admin-columns/class-column-types.php';
        require_once VOXEL_TOOLKIT_PLUGIN_DIR . 'includes/admin-columns/class-column-renderer.php';
        require_once VOXEL_TOOLKIT_PLUGIN_DIR . 'includes/admin-columns/class-user-columns.php';
        require_once VOXEL_TOOLKIT_PLUGIN_DIR . 'includes/admin-columns/class-filter-bar.php';

        $this->column_types = new Voxel_Toolkit_Column_Types();
        $this->renderer = new Voxel_Toolkit_Column_Renderer($this->column_types);
        $this->user_columns = Voxel_Toolkit_User_Columns::instance();
    }

    /**
     * Initialize hooks
     */
    private function init_hooks() {
        // Admin menu
        add_action('admin_menu', array($this, 'add_admin_menu'), 25);

        // Scripts and styles
        add_action('admin_enqueue_scripts', array($this, 'enqueue_scripts'));

        // AJAX endpoints
        add_action('wp_ajax_vt_admin_columns_get_post_types', array($this, 'ajax_get_post_types'));
        add_action('wp_ajax_vt_admin_columns_get_fields', array($this, 'ajax_get_fields'));
        add_action('wp_ajax_vt_admin_columns_save', array($this, 'ajax_save_config'));
        add_action('wp_ajax_vt_admin_columns_load', array($this, 'ajax_load_config'));
        add_action('wp_ajax_vt_admin_columns_restore_defaults', array($this, 'ajax_restore_defaults'));
        add_action('wp_ajax_vt_admin_columns_export', array($this, 'ajax_export_data'));

        // Bulk edit AJAX endpoints
        add_action('wp_ajax_vt_admin_columns_bulk_get_terms', array($this, 'ajax_bulk_get_terms'));
        add_action('wp_ajax_vt_admin_columns_bulk_get_posts', array($this, 'ajax_bulk_get_posts'));
        add_action('wp_ajax_vt_admin_columns_bulk_apply', array($this, 'ajax_bulk_apply'));

        // Register column hooks for configured post types
        add_action('admin_init', array($this, 'register_column_hooks'));
    }

    /**
     * Add admin menu
     */
    public function add_admin_menu() {
        add_submenu_page(
            'voxel-toolkit',
            __('Admin Columns', 'voxel-toolkit'),
            __('Admin Columns', 'voxel-toolkit'),
            'manage_options',
            'vt-admin-columns',
            array($this, 'render_settings_page')
        );
    }

    /**
     * Enqueue scripts and styles
     */
    public function enqueue_scripts($hook) {
        // Load on settings page
        if (strpos($hook, 'vt-admin-columns') !== false) {
            $this->enqueue_settings_page_assets();
            return;
        }

        // Load on post list pages (edit.php) for configured post types
        if ($hook === 'edit.php') {
            $this->enqueue_post_list_assets();
        }
    }

    /**
     * Enqueue assets for the settings page
     */
    private function enqueue_settings_page_assets() {
        // Deregister any existing Vue to ensure we use the full build with template compiler
        wp_deregister_script('vue');

        // Vue 3 (full build with template compiler for in-DOM templates)
        wp_enqueue_script(
            'vue',
            'https://unpkg.com/vue@3.4.21/dist/vue.global.js',
            array(),
            '3.4.21',
            true
        );

        // SortableJS for drag and drop
        wp_enqueue_script(
            'sortablejs',
            'https://cdn.jsdelivr.net/npm/sortablejs@1.15.2/Sortable.min.js',
            array(),
            '1.15.2',
            true
        );

        // Admin Columns App
        wp_enqueue_script(
            'vt-admin-columns-app',
            VOXEL_TOOLKIT_PLUGIN_URL . 'includes/admin-columns/assets/js/admin-columns-app.js',
            array('vue', 'sortablejs'),
            VOXEL_TOOLKIT_VERSION,
            true
        );

        // Admin Columns CSS
        wp_enqueue_style(
            'vt-admin-columns',
            VOXEL_TOOLKIT_PLUGIN_URL . 'includes/admin-columns/assets/css/admin-columns.css',
            array(),
            VOXEL_TOOLKIT_VERSION
        );
    }

    /**
     * Enqueue assets for post list pages
     */
    private function enqueue_post_list_assets() {
        global $typenow;

        if (empty($typenow)) {
            return;
        }

        $configs = get_option('voxel_toolkit_admin_columns', array());

        if (!isset($configs[$typenow])) {
            return;
        }

        // Admin Columns CSS for column display styles
        wp_enqueue_style(
            'vt-admin-columns',
            VOXEL_TOOLKIT_PLUGIN_URL . 'includes/admin-columns/assets/css/admin-columns.css',
            array(),
            VOXEL_TOOLKIT_VERSION
        );

        // SortableJS for export modal drag and drop
        wp_enqueue_script(
            'sortablejs',
            'https://cdn.jsdelivr.net/npm/sortablejs@1.15.2/Sortable.min.js',
            array(),
            '1.15.2',
            true
        );

        // Output column width styles
        $this->output_column_width_styles($typenow, $configs[$typenow]);

        // Always remove Voxel's default columns when Admin Columns is active for this post type
        add_action('admin_footer', array($this, 'output_voxel_cleanup_script'));

        // Add CSS to hide Voxel's default columns
        wp_add_inline_style('vt-admin-columns', '
            .wp-list-table .column-vx_listing_plan,
            .wp-list-table .column-vx_verified,
            .wp-list-table .column-vx_author,
            .wp-list-table th.column-vx_listing_plan,
            .wp-list-table th.column-vx_verified,
            .wp-list-table th.column-vx_author { display: none !important; }
        ');

        // Add inline script for dropdown positioning
        add_action('admin_footer', array($this, 'output_dropdown_positioning_script'));

        // Bulk edit assets (only if user has manage_options capability)
        if (current_user_can('manage_options')) {
            $this->enqueue_bulk_edit_assets($typenow, $configs[$typenow]);
        }
    }

    /**
     * Enqueue bulk edit assets for editable columns
     */
    private function enqueue_bulk_edit_assets($post_type, $config) {
        // Get all bulk-editable columns with their indices
        $bulk_edit_columns = $this->get_bulk_edit_columns($config, $post_type);

        if (empty($bulk_edit_columns)) {
            return;
        }

        // Bulk Edit CSS
        wp_enqueue_style(
            'vt-admin-bulk-edit',
            VOXEL_TOOLKIT_PLUGIN_URL . 'includes/admin-columns/assets/css/admin-bulk-edit.css',
            array('vt-admin-columns'),
            VOXEL_TOOLKIT_VERSION
        );

        // Bulk Edit JS
        wp_enqueue_script(
            'vt-admin-bulk-edit',
            VOXEL_TOOLKIT_PLUGIN_URL . 'includes/admin-columns/assets/js/admin-bulk-edit.js',
            array('jquery'),
            VOXEL_TOOLKIT_VERSION,
            true
        );

        // Pass config to JavaScript
        wp_localize_script('vt-admin-bulk-edit', 'vtBulkEdit', array(
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('vt_admin_columns_bulk_nonce'),
            'postType' => $post_type,
            'bulkEditColumns' => $bulk_edit_columns,
            'i18n' => array(
                'bulkEdit' => __('Bulk Edit', 'voxel-toolkit'),
                'addTo' => __('Add to existing', 'voxel-toolkit'),
                'replace' => __('Replace all', 'voxel-toolkit'),
                'remove' => __('Remove', 'voxel-toolkit'),
                'setValue' => __('Set value', 'voxel-toolkit'),
                'setTrue' => __('Set to Yes', 'voxel-toolkit'),
                'setFalse' => __('Set to No', 'voxel-toolkit'),
                'searchTerms' => __('Search terms...', 'voxel-toolkit'),
                'searchPosts' => __('Search posts...', 'voxel-toolkit'),
                'noTermsFound' => __('No terms found', 'voxel-toolkit'),
                'noPostsFound' => __('No posts found', 'voxel-toolkit'),
                'noOptionsFound' => __('No options available', 'voxel-toolkit'),
                'selectedPosts' => __('%d posts selected', 'voxel-toolkit'),
                'selectPosts' => __('Select posts to bulk edit', 'voxel-toolkit'),
                'selectValue' => __('Select a value', 'voxel-toolkit'),
                'enterValue' => __('Enter a value', 'voxel-toolkit'),
                'saveChanges' => __('Save Changes', 'voxel-toolkit'),
                'cancel' => __('Cancel', 'voxel-toolkit'),
                'confirm' => __('Confirm', 'voxel-toolkit'),
                'confirmAction' => __('Apply "%s" to %d posts?', 'voxel-toolkit'),
                'processing' => __('Processing... %d/%d', 'voxel-toolkit'),
                'complete' => __('Complete! %d posts updated.', 'voxel-toolkit'),
                'error' => __('Error: %s', 'voxel-toolkit'),
                'close' => __('Close', 'voxel-toolkit'),
            ),
        ));
    }

    /**
     * Get all bulk-editable columns from config with their indices
     * Supports: taxonomy, post-relation, select, multiselect, switcher, text, number
     */
    private function get_bulk_edit_columns($config, $post_type) {
        if (empty($config['columns'])) {
            return array();
        }

        if (!class_exists('\Voxel\Post_Type')) {
            return array();
        }

        $voxel_post_type = \Voxel\Post_Type::get($post_type);
        if (!$voxel_post_type) {
            return array();
        }

        $bulk_edit_columns = array();
        // Field types that support bulk editing - taxonomy only for now
        $editable_types = array('taxonomy');
        // Explicitly exclude complex field types that cannot be bulk edited
        $excluded_types = array('repeater', 'product', 'work-hours', 'file', 'image', 'location', 'ui-step', 'ui-heading', 'ui-image', 'ui-html');

        $column_index = 0;

        foreach ($config['columns'] as $col) {
            $column_index++;

            if (empty($col['field_key'])) {
                continue;
            }

            $field_key = $col['field_key'];

            // Skip WordPress core fields (prefixed with :)
            if (strpos($field_key, ':') === 0) {
                continue;
            }

            $field = $voxel_post_type->get_field($field_key);
            if (!$field) {
                continue;
            }

            $field_type = $field->get_type();

            // Check if this field type is editable
            if (!in_array($field_type, $editable_types) || in_array($field_type, $excluded_types)) {
                continue;
            }

            $column_data = array(
                'index' => $column_index,
                'id' => $col['id'],
                'field_key' => $field_key,
                'label' => isset($col['label']) ? $col['label'] : $field_key,
                'type' => $field_type,
            );

            // Add type-specific data
            switch ($field_type) {
                case 'taxonomy':
                    $taxonomy = $this->get_field_taxonomy($field, $field_key);
                    if (!$taxonomy) {
                        continue 2; // Skip if no valid taxonomy
                    }
                    $column_data['taxonomy'] = $taxonomy;
                    break;

                case 'post-relation':
                    $related_post_type = null;
                    if (method_exists($field, 'get_prop')) {
                        $related_post_type = $field->get_prop('post_type');
                        // Also try 'post_types' (plural)
                        if (empty($related_post_type)) {
                            $related_post_type = $field->get_prop('post_types');
                        }
                    }
                    if (empty($related_post_type)) {
                        continue 2; // Skip if no related post type
                    }
                    // Handle if it's an array
                    if (is_array($related_post_type)) {
                        $related_post_type = reset($related_post_type);
                    }
                    $column_data['relatedPostType'] = $related_post_type;
                    break;

                case 'select':
                case 'multiselect':
                    $options = array();
                    if (method_exists($field, 'get_prop')) {
                        $choices = $field->get_prop('choices');
                        if (is_array($choices)) {
                            foreach ($choices as $choice) {
                                if (isset($choice['value']) && isset($choice['label'])) {
                                    $options[] = array(
                                        'value' => $choice['value'],
                                        'label' => $choice['label'],
                                    );
                                }
                            }
                        }
                    }
                    $column_data['options'] = $options;
                    break;

                case 'switcher':
                    // No additional data needed
                    break;

                case 'text':
                case 'number':
                    // No additional data needed
                    break;
            }

            $bulk_edit_columns[] = $column_data;
        }

        return $bulk_edit_columns;
    }

    /**
     * Get taxonomy slug from a field
     */
    private function get_field_taxonomy($field, $field_key) {
        // Get taxonomy from field props
        if (method_exists($field, 'get_prop')) {
            $taxonomy = $field->get_prop('taxonomy');
            if ($taxonomy && taxonomy_exists($taxonomy)) {
                return $taxonomy;
            }
        }

        // Try get_taxonomy method
        if (method_exists($field, 'get_taxonomy')) {
            $taxonomy = $field->get_taxonomy();
            if ($taxonomy && taxonomy_exists($taxonomy)) {
                return $taxonomy;
            }
        }

        // Fall back to field key as taxonomy slug
        if (taxonomy_exists($field_key)) {
            return $field_key;
        }

        return null;
    }

    /**
     * Output inline script for dropdown positioning
     */
    public function output_dropdown_positioning_script() {
        ?>
        <script>
        (function() {
            document.addEventListener('mouseover', function(e) {
                var toggle = e.target.closest('.vt-ac-relations-toggle');
                if (!toggle) return;

                var dropdown = toggle.nextElementSibling;
                if (!dropdown || !dropdown.classList.contains('vt-ac-relations-dropdown')) return;

                var rect = toggle.getBoundingClientRect();
                var viewportWidth = window.innerWidth;
                var viewportHeight = window.innerHeight;

                // Reset positioning
                dropdown.style.left = '';
                dropdown.style.right = '';
                dropdown.style.top = '';
                dropdown.style.bottom = '';

                // Check horizontal position
                if (rect.right + 300 > viewportWidth) {
                    // Would overflow right, align to right
                    dropdown.style.right = '0';
                    dropdown.style.left = 'auto';
                } else if (rect.left < 300) {
                    // Near left edge, align to left
                    dropdown.style.left = '0';
                    dropdown.style.right = 'auto';
                } else {
                    // Default: align right
                    dropdown.style.right = '0';
                    dropdown.style.left = 'auto';
                }

                // Check vertical position
                if (rect.bottom + 260 > viewportHeight) {
                    // Would overflow bottom, open upward
                    dropdown.style.bottom = '100%';
                    dropdown.style.top = 'auto';
                    dropdown.style.marginTop = '0';
                    dropdown.style.marginBottom = '4px';
                } else {
                    // Default: open downward
                    dropdown.style.top = '100%';
                    dropdown.style.bottom = 'auto';
                    dropdown.style.marginTop = '4px';
                    dropdown.style.marginBottom = '0';
                }
            });
        })();
        </script>
        <?php
    }

    /**
     * Output script to clean up Voxel's injected content
     */
    public function output_voxel_cleanup_script() {
        ?>
        <style>
            /* Hide Voxel's Plan column */
            .wp-list-table .column-vx_listing_plan,
            .wp-list-table th.column-vx_listing_plan,
            .wp-list-table td.column-vx_listing_plan { display: none !important; }
            /* Hide Voxel's injected listing plan links */
            .wp-list-table td > a[href*="voxel-paid-listings"] { display: none !important; }
        </style>
        <script>
        (function() {
            function cleanupVoxelContent() {
                // Remove paid-listings links from table cells only
                document.querySelectorAll('.wp-list-table td a[href*="paid-listings"]').forEach(function(link) {
                    link.remove();
                });
                // Hide plan columns
                document.querySelectorAll('.column-vx_listing_plan, [class*="vx_listing_plan"]').forEach(function(el) {
                    el.style.display = 'none';
                });
            }

            // Run immediately
            cleanupVoxelContent();

            // Run again after a delay (for AJAX content)
            setTimeout(cleanupVoxelContent, 100);
            setTimeout(cleanupVoxelContent, 500);
            setTimeout(cleanupVoxelContent, 1000);

            // Watch for dynamic changes
            var table = document.querySelector('.wp-list-table');
            if (table) {
                var observer = new MutationObserver(function(mutations) {
                    cleanupVoxelContent();
                });
                observer.observe(table, { childList: true, subtree: true });
            }
        })();
        </script>
        <?php
    }

    /**
     * Output inline CSS for column widths
     */
    private function output_column_width_styles($post_type, $config) {
        if (empty($config['columns'])) {
            return;
        }

        $styles = array();

        foreach ($config['columns'] as $col) {
            if (isset($col['width']) && $col['width']['mode'] !== 'auto' && !empty($col['width']['value'])) {
                $column_key = 'vt_' . $col['id'];
                $width_value = intval($col['width']['value']);
                $width_unit = $col['width']['mode'] === '%' ? '%' : 'px';

                $styles[] = sprintf(
                    '.wp-list-table .column-%s { width: %d%s; }',
                    esc_attr($column_key),
                    $width_value,
                    $width_unit
                );
            }
        }

        if (!empty($styles)) {
            wp_add_inline_style('vt-admin-columns', implode("\n", $styles));
        }
    }

    /**
     * Get localization data for JavaScript
     */
    public function get_js_data() {
        return array(
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('vt_admin_columns_nonce'),
            'usersUrl' => admin_url('users.php'),
            'fieldTypes' => $this->column_types->get_field_type_info(),
            'i18n' => array(
                'save' => __('Save Changes', 'voxel-toolkit'),
                'saving' => __('Saving...', 'voxel-toolkit'),
                'saved' => __('Saved!', 'voxel-toolkit'),
                'addColumn' => __('Add Column', 'voxel-toolkit'),
                'removeColumn' => __('Remove', 'voxel-toolkit'),
                'selectPostType' => __('Select a post type', 'voxel-toolkit'),
                'selectField' => __('Select a field', 'voxel-toolkit'),
                'noColumns' => __('No columns configured. Click "Add Column" to get started.', 'voxel-toolkit'),
                'label' => __('Label', 'voxel-toolkit'),
                'field' => __('Field', 'voxel-toolkit'),
                'width' => __('Width', 'voxel-toolkit'),
                'auto' => __('Auto', 'voxel-toolkit'),
                'sortable' => __('Sortable', 'voxel-toolkit'),
                'filterable' => __('Filterable', 'voxel-toolkit'),
                'viewPosts' => __('View Posts', 'voxel-toolkit'),
                'restoreDefaults' => __('Restore Defaults', 'voxel-toolkit'),
                'confirmRestore' => __('Are you sure you want to restore default columns for this post type?', 'voxel-toolkit'),
                'error' => __('An error occurred. Please try again.', 'voxel-toolkit'),
                'loading' => __('Loading...', 'voxel-toolkit'),
                'users' => __('Users', 'voxel-toolkit'),
                'user' => __('User', 'voxel-toolkit'),
            ),
        );
    }

    /**
     * Render settings page
     */
    public function render_settings_page() {
        include VOXEL_TOOLKIT_PLUGIN_DIR . 'includes/admin-columns/templates/admin-columns-page.php';
    }

    /**
     * AJAX: Get Voxel post types
     */
    public function ajax_get_post_types() {
        check_ajax_referer('vt_admin_columns_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => __('Unauthorized', 'voxel-toolkit')));
        }

        if (!class_exists('\Voxel\Post_Type')) {
            wp_send_json_error(array('message' => __('Voxel is not active', 'voxel-toolkit')));
        }

        $voxel_types = \Voxel\Post_Type::get_voxel_types();
        $post_types = array();

        foreach ($voxel_types as $key => $type) {
            $post_types[] = array(
                'key' => $key,
                'label' => $type->get_label(),
                'singular' => $type->get_singular_name(),
                'edit_url' => admin_url("edit.php?post_type={$key}"),
            );
        }

        wp_send_json_success($post_types);
    }

    /**
     * AJAX: Get fields for a post type
     */
    public function ajax_get_fields() {
        check_ajax_referer('vt_admin_columns_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => __('Unauthorized', 'voxel-toolkit')));
        }

        $post_type_key = isset($_POST['post_type']) ? sanitize_text_field($_POST['post_type']) : '';

        if (empty($post_type_key)) {
            wp_send_json_error(array('message' => __('Post type is required', 'voxel-toolkit')));
        }

        if (!class_exists('\Voxel\Post_Type')) {
            wp_send_json_error(array('message' => __('Voxel is not active', 'voxel-toolkit')));
        }

        $post_type = \Voxel\Post_Type::get($post_type_key);

        if (!$post_type) {
            wp_send_json_error(array('message' => __('Invalid post type', 'voxel-toolkit')));
        }

        // Organize fields into groups
        $grouped_fields = array(
            'voxel' => array(
                'label' => __('Voxel Fields', 'voxel-toolkit'),
                'fields' => array(),
            ),
            'wordpress' => array(
                'label' => __('WordPress', 'voxel-toolkit'),
                'fields' => array(),
            ),
            'toolkit' => array(
                'label' => __('Voxel Toolkit', 'voxel-toolkit'),
                'fields' => array(),
            ),
        );

        // Add Voxel post type fields first
        $fields = $post_type->get_fields();
        $skip_types = array('ui-step', 'ui-heading', 'ui-image');

        // Track toolkit field types
        $toolkit_field_types = array('poll');

        foreach ($fields as $field) {
            $type = $field->get_type();

            // Skip UI-only fields
            if (in_array($type, $skip_types)) {
                continue;
            }

            $type_info = $this->column_types->get_type_info($type);

            $field_entry = array(
                'key' => $field->get_key(),
                'label' => $field->get_label(),
                'type' => $type,
                'type_label' => $type_info['label'],
                'sortable' => $type_info['sortable'],
                'filterable' => $type_info['filterable'],
            );

            // Flag image fields for special handling
            if (in_array($type, array('image', 'profile-avatar'))) {
                $field_entry['is_image'] = true;
            }

            // Put toolkit fields in their own group
            if (in_array($type, $toolkit_field_types)) {
                $field_entry['type_label'] = $type_info['label'] . ' (VT)';
                $grouped_fields['toolkit']['fields'][] = $field_entry;
            } else {
                $grouped_fields['voxel']['fields'][] = $field_entry;
            }
        }

        // Add Voxel system fields (view counts, reviews, listing plan)
        $grouped_fields['voxel']['fields'][] = array(
            'key' => ':view_counts',
            'label' => __('View Counts', 'voxel-toolkit'),
            'type' => 'voxel-view-counts',
            'type_label' => __('Voxel', 'voxel-toolkit'),
            'sortable' => true,
            'filterable' => true,
        );

        $grouped_fields['voxel']['fields'][] = array(
            'key' => ':review_stats',
            'label' => __('Review Stats', 'voxel-toolkit'),
            'type' => 'voxel-review-stats',
            'type_label' => __('Voxel', 'voxel-toolkit'),
            'sortable' => true,
            'filterable' => true,
        );

        $grouped_fields['voxel']['fields'][] = array(
            'key' => ':listing_plan',
            'label' => __('Listing Plan', 'voxel-toolkit'),
            'type' => 'voxel-listing-plan',
            'type_label' => __('Voxel', 'voxel-toolkit'),
            'sortable' => false,
            'filterable' => true,
        );

        // Add WordPress core fields (sorted alphabetically)
        $wp_fields = array(
            array(
                'key' => ':author',
                'label' => __('Author', 'voxel-toolkit'),
                'type' => 'wp-author',
                'sortable' => true,
                'filterable' => true,
            ),
            array(
                'key' => ':comments',
                'label' => __('Comments', 'voxel-toolkit'),
                'type' => 'wp-comments',
                'sortable' => true,
                'filterable' => true,
            ),
            array(
                'key' => ':date',
                'label' => __('Date Published', 'voxel-toolkit'),
                'type' => 'wp-date',
                'sortable' => true,
                'filterable' => true,
            ),
            array(
                'key' => ':excerpt',
                'label' => __('Excerpt', 'voxel-toolkit'),
                'type' => 'wp-excerpt',
                'sortable' => false,
                'filterable' => true,
            ),
            array(
                'key' => ':thumbnail',
                'label' => __('Featured Image', 'voxel-toolkit'),
                'type' => 'wp-thumbnail',
                'sortable' => false,
                'filterable' => false,
                'is_image' => true,
            ),
            array(
                'key' => ':modified',
                'label' => __('Last Modified', 'voxel-toolkit'),
                'type' => 'wp-modified',
                'sortable' => true,
                'filterable' => true,
            ),
            array(
                'key' => ':menu_order',
                'label' => __('Menu Order', 'voxel-toolkit'),
                'type' => 'wp-menu-order',
                'sortable' => true,
                'filterable' => true,
            ),
            array(
                'key' => ':parent',
                'label' => __('Parent', 'voxel-toolkit'),
                'type' => 'wp-parent',
                'sortable' => false,
                'filterable' => true,
            ),
            array(
                'key' => ':permalink',
                'label' => __('Permalink', 'voxel-toolkit'),
                'type' => 'wp-permalink',
                'sortable' => false,
                'filterable' => false,
            ),
            array(
                'key' => ':id',
                'label' => __('Post ID', 'voxel-toolkit'),
                'type' => 'wp-id',
                'sortable' => true,
                'filterable' => true,
            ),
            array(
                'key' => ':slug',
                'label' => __('Slug', 'voxel-toolkit'),
                'type' => 'wp-slug',
                'sortable' => true,
                'filterable' => true,
            ),
            array(
                'key' => ':status',
                'label' => __('Status', 'voxel-toolkit'),
                'type' => 'wp-status',
                'sortable' => false,
                'filterable' => true,
            ),
            array(
                'key' => ':word_count',
                'label' => __('Word Count', 'voxel-toolkit'),
                'type' => 'wp-word-count',
                'sortable' => false,
                'filterable' => true,
            ),
        );

        foreach ($wp_fields as $wp_field) {
            $wp_field['type_label'] = __('WordPress', 'voxel-toolkit');
            $grouped_fields['wordpress']['fields'][] = $wp_field;
        }

        // Add Voxel Toolkit specific columns
        $grouped_fields['toolkit']['fields'][] = array(
            'key' => ':article_helpful',
            'label' => __('Article Helpful', 'voxel-toolkit'),
            'type' => 'article-helpful',
            'type_label' => __('Voxel Toolkit', 'voxel-toolkit'),
            'sortable' => true,
            'filterable' => true,
        );

        // Remove empty groups
        $grouped_fields = array_filter($grouped_fields, function($group) {
            return !empty($group['fields']);
        });

        wp_send_json_success($grouped_fields);
    }

    /**
     * AJAX: Save column configuration
     */
    public function ajax_save_config() {
        check_ajax_referer('vt_admin_columns_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => __('Unauthorized', 'voxel-toolkit')));
        }

        $post_type = isset($_POST['post_type']) ? sanitize_text_field($_POST['post_type']) : '';
        $config = isset($_POST['config']) ? json_decode(stripslashes($_POST['config']), true) : null;

        if (empty($post_type)) {
            wp_send_json_error(array('message' => __('Post type is required', 'voxel-toolkit')));
        }

        if (!is_array($config)) {
            wp_send_json_error(array('message' => __('Invalid configuration', 'voxel-toolkit')));
        }

        $sanitized = $this->sanitize_config($config);

        $all_configs = get_option('voxel_toolkit_admin_columns', array());
        $all_configs[$post_type] = $sanitized;

        update_option('voxel_toolkit_admin_columns', $all_configs);

        wp_send_json_success(array('message' => __('Configuration saved', 'voxel-toolkit')));
    }

    /**
     * AJAX: Load column configuration
     */
    public function ajax_load_config() {
        check_ajax_referer('vt_admin_columns_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => __('Unauthorized', 'voxel-toolkit')));
        }

        $post_type = isset($_POST['post_type']) ? sanitize_text_field($_POST['post_type']) : '';

        if (empty($post_type)) {
            wp_send_json_error(array('message' => __('Post type is required', 'voxel-toolkit')));
        }

        $all_configs = get_option('voxel_toolkit_admin_columns', array());

        if (isset($all_configs[$post_type])) {
            // Return saved config
            $config = $all_configs[$post_type];
        } else {
            // Return default columns for new post types
            $config = $this->get_default_config($post_type);
        }

        wp_send_json_success($config);
    }

    /**
     * Get default column configuration for a post type
     */
    private function get_default_config($post_type) {
        $default_columns = array(
            array(
                'id' => 'col_title',
                'field_key' => 'title',
                'label' => __('Title', 'voxel-toolkit'),
                'width' => array('mode' => 'auto', 'value' => null),
                'sortable' => true,
                'filterable' => false,
            ),
            array(
                'id' => 'col_date',
                'field_key' => ':date',
                'label' => __('Date Published', 'voxel-toolkit'),
                'width' => array('mode' => 'auto', 'value' => null),
                'sortable' => true,
                'filterable' => false,
            ),
            array(
                'id' => 'col_author',
                'field_key' => ':author',
                'label' => __('Author', 'voxel-toolkit'),
                'width' => array('mode' => 'auto', 'value' => null),
                'sortable' => true,
                'filterable' => false,
            ),
        );

        return array(
            'columns' => $default_columns,
            'settings' => array(
                'default_sort' => array('column' => 'date', 'order' => 'desc'),
                'primary_column' => 'title',
            ),
        );
    }

    /**
     * AJAX: Restore default columns
     */
    public function ajax_restore_defaults() {
        check_ajax_referer('vt_admin_columns_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => __('Unauthorized', 'voxel-toolkit')));
        }

        $post_type = isset($_POST['post_type']) ? sanitize_text_field($_POST['post_type']) : '';

        if (empty($post_type)) {
            wp_send_json_error(array('message' => __('Post type is required', 'voxel-toolkit')));
        }

        $all_configs = get_option('voxel_toolkit_admin_columns', array());

        if (isset($all_configs[$post_type])) {
            unset($all_configs[$post_type]);
            update_option('voxel_toolkit_admin_columns', $all_configs);
        }

        wp_send_json_success(array('message' => __('Defaults restored', 'voxel-toolkit')));
    }

    /**
     * AJAX: Export data
     */
    public function ajax_export_data() {
        check_ajax_referer('vt_admin_columns_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => __('Unauthorized', 'voxel-toolkit')));
        }

        $post_type = isset($_POST['post_type']) ? sanitize_text_field($_POST['post_type']) : '';
        $columns = isset($_POST['columns']) ? array_map('sanitize_text_field', $_POST['columns']) : array();
        $query_args = isset($_POST['query_args']) ? $_POST['query_args'] : array();

        if (empty($post_type) || empty($columns)) {
            wp_send_json_error(array('message' => __('Invalid parameters', 'voxel-toolkit')));
        }

        // Get config
        $configs = get_option('voxel_toolkit_admin_columns', array());
        if (!isset($configs[$post_type])) {
            wp_send_json_error(array('message' => __('No configuration found', 'voxel-toolkit')));
        }

        $config = $configs[$post_type];

        // Build query args
        $args = array(
            'post_type' => $post_type,
            'posts_per_page' => -1,
            'post_status' => 'any',
        );

        // Apply filters from URL params
        if (!empty($query_args['s'])) {
            $args['s'] = sanitize_text_field($query_args['s']);
        }
        if (!empty($query_args['post_status']) && $query_args['post_status'] !== 'all') {
            $args['post_status'] = sanitize_text_field($query_args['post_status']);
        }
        if (!empty($query_args['author'])) {
            $args['author'] = intval($query_args['author']);
        }
        if (!empty($query_args['m'])) {
            $args['m'] = intval($query_args['m']);
        }
        if (!empty($query_args['orderby'])) {
            $args['orderby'] = sanitize_text_field($query_args['orderby']);
            $args['order'] = !empty($query_args['order']) ? sanitize_text_field($query_args['order']) : 'DESC';
        }

        // Apply custom filters (vt_filter_*)
        $meta_query = array();
        $tax_query = array();

        foreach ($query_args as $key => $value) {
            if (strpos($key, 'vt_filter_') === 0 && !empty($value)) {
                $field_key = str_replace('vt_filter_', '', $key);

                // Check if it's a taxonomy filter
                $field_type = $this->get_field_type($field_key, $post_type);
                if ($field_type === 'taxonomy') {
                    $taxonomy = $this->get_taxonomy_for_field($field_key, $post_type);
                    if ($taxonomy) {
                        $tax_query[] = array(
                            'taxonomy' => $taxonomy,
                            'field' => 'slug',
                            'terms' => sanitize_text_field($value),
                        );
                    }
                } else {
                    $meta_query[] = array(
                        'key' => $field_key,
                        'value' => sanitize_text_field($value),
                    );
                }
            }
        }

        if (!empty($meta_query)) {
            $args['meta_query'] = $meta_query;
        }
        if (!empty($tax_query)) {
            $args['tax_query'] = $tax_query;
        }

        $posts = get_posts($args);

        // Build column mapping
        $column_map = array();
        foreach ($config['columns'] as $col) {
            if (in_array($col['id'], $columns)) {
                $column_map[$col['id']] = $col;
            }
        }

        // Generate CSV data
        $csv_data = array();

        // Headers
        $headers = array();
        foreach ($columns as $col_id) {
            if (isset($column_map[$col_id])) {
                $headers[] = $column_map[$col_id]['label'];
            }
        }
        $csv_data[] = $headers;

        // Rows
        foreach ($posts as $post) {
            $row = array();
            foreach ($columns as $col_id) {
                if (isset($column_map[$col_id])) {
                    $col = $column_map[$col_id];
                    $value = $this->get_export_value($col['field_key'], $post->ID, $col);
                    $row[] = $value;
                }
            }
            $csv_data[] = $row;
        }

        wp_send_json_success(array(
            'data' => $csv_data,
            'filename' => $post_type . '-export-' . date('Y-m-d') . '.csv',
        ));
    }

    /**
     * Get plain text value for export
     */
    private function get_export_value($field_key, $post_id, $column_config = null) {
        // Handle WordPress core fields
        if (strpos($field_key, ':') === 0) {
            return $this->get_wp_export_value($field_key, $post_id, $column_config);
        }

        // Check if Voxel is available
        if (!class_exists('\Voxel\Post')) {
            $meta_value = get_post_meta($post_id, $field_key, true);
            return is_array($meta_value) ? wp_json_encode($meta_value) : $meta_value;
        }

        $post = \Voxel\Post::get($post_id);
        if (!$post) {
            return '';
        }

        $field = $post->get_field($field_key);
        if (!$field) {
            $meta_value = get_post_meta($post_id, $field_key, true);
            return is_array($meta_value) ? wp_json_encode($meta_value) : $meta_value;
        }

        $value = $field->get_value();
        $type = $field->get_type();

        // Handle different field types
        switch ($type) {
            case 'title':
            case 'text':
            case 'textarea':
            case 'description':
            case 'texteditor':
                return wp_strip_all_tags($value);

            case 'number':
                return is_numeric($value) ? $value : '';

            case 'email':
            case 'phone':
            case 'url':
            case 'color':
            case 'timezone':
                return $value;

            case 'date':
                if (!empty($value)) {
                    return date_i18n(get_option('date_format'), strtotime($value));
                }
                return '';

            case 'select':
                return $value;

            case 'multiselect':
                return is_array($value) ? implode(', ', $value) : $value;

            case 'switcher':
                return $value ? __('Yes', 'voxel-toolkit') : __('No', 'voxel-toolkit');

            case 'image':
            case 'file':
                if (is_array($value)) {
                    $urls = array();
                    foreach ($value as $attachment_id) {
                        $url = wp_get_attachment_url($attachment_id);
                        if ($url) {
                            $urls[] = $url;
                        }
                    }
                    return implode(', ', $urls);
                }
                return wp_get_attachment_url($value) ?: '';

            case 'location':
                if (is_array($value) && isset($value['address'])) {
                    return $value['address'];
                }
                return '';

            case 'taxonomy':
                $taxonomy = $field->get_prop('taxonomy');
                if ($taxonomy) {
                    $terms = get_the_terms($post_id, $taxonomy);
                    if ($terms && !is_wp_error($terms)) {
                        return implode(', ', wp_list_pluck($terms, 'name'));
                    }
                }
                return '';

            case 'product':
                if (is_array($value) && isset($value['base_price']['amount'])) {
                    return $value['base_price']['amount'];
                }
                return '';

            case 'post-relation':
                if (is_array($value)) {
                    $titles = array();
                    foreach ($value as $related_id) {
                        $titles[] = get_the_title($related_id);
                    }
                    return implode(', ', $titles);
                }
                return '';

            default:
                if (is_array($value)) {
                    return wp_json_encode($value);
                }
                return $value;
        }
    }

    /**
     * Get WordPress field value for export
     */
    private function get_wp_export_value($field_key, $post_id, $column_config = null) {
        $post = get_post($post_id);
        if (!$post) {
            return '';
        }

        switch ($field_key) {
            case ':date':
                return date_i18n(get_option('date_format') . ' ' . get_option('time_format'), strtotime($post->post_date));

            case ':modified':
                return date_i18n(get_option('date_format') . ' ' . get_option('time_format'), strtotime($post->post_modified));

            case ':author':
                $author = get_userdata($post->post_author);
                return $author ? $author->display_name : '';

            case ':status':
                $status_obj = get_post_status_object($post->post_status);
                return $status_obj ? $status_obj->label : $post->post_status;

            case ':id':
                return $post_id;

            case ':slug':
                return $post->post_name;

            case ':excerpt':
                return wp_strip_all_tags($post->post_excerpt);

            case ':thumbnail':
                $thumbnail_id = get_post_thumbnail_id($post_id);
                return $thumbnail_id ? wp_get_attachment_url($thumbnail_id) : '';

            case ':permalink':
                return get_permalink($post_id);

            case ':comments':
                return $post->comment_count;

            case ':menu_order':
                return $post->menu_order;

            case ':parent':
                return $post->post_parent ? get_the_title($post->post_parent) : '';

            case ':word_count':
                return str_word_count(wp_strip_all_tags($post->post_content));

            case ':listing_plan':
                if (class_exists('\Voxel\Post')) {
                    $voxel_post = \Voxel\Post::get($post_id);
                    if ($voxel_post && method_exists($voxel_post, 'get_priority')) {
                        $priority = $voxel_post->get_priority();
                        if ($priority && isset($priority['plan'])) {
                            return $priority['plan']['label'] ?? '';
                        }
                    }
                }
                return '';

            default:
                return '';
        }
    }

    /**
     * Sanitize configuration
     */
    private function sanitize_config($config) {
        $sanitized = array(
            'columns' => array(),
            'settings' => array(
                'default_sort' => array('column' => 'date', 'order' => 'desc'),
                'primary_column' => 'title',
            ),
        );

        // Sanitize columns
        if (isset($config['columns']) && is_array($config['columns'])) {
            foreach ($config['columns'] as $column) {
                if (!isset($column['field_key']) || empty($column['field_key'])) {
                    continue;
                }

                $sanitized_column = array(
                    'id' => isset($column['id']) ? sanitize_text_field($column['id']) : $this->generate_id(),
                    'field_key' => sanitize_text_field($column['field_key']),
                    'label' => isset($column['label']) ? sanitize_text_field($column['label']) : '',
                    'width' => array(
                        'mode' => isset($column['width']['mode']) && in_array($column['width']['mode'], array('auto', 'px', '%'))
                            ? $column['width']['mode']
                            : 'auto',
                        'value' => isset($column['width']['value']) ? absint($column['width']['value']) : null,
                    ),
                    'sortable' => !empty($column['sortable']),
                    'filterable' => !empty($column['filterable']),
                );

                // Sanitize image settings if present
                if (isset($column['image_settings']) && is_array($column['image_settings'])) {
                    $valid_sizes = array('thumbnail', 'medium', 'medium_large', 'large', 'full');
                    $sanitized_column['image_settings'] = array(
                        'display_width' => isset($column['image_settings']['display_width'])
                            ? min(500, max(20, absint($column['image_settings']['display_width'])))
                            : 60,
                        'display_height' => isset($column['image_settings']['display_height'])
                            ? min(500, max(20, absint($column['image_settings']['display_height'])))
                            : 60,
                        'wp_size' => isset($column['image_settings']['wp_size']) && in_array($column['image_settings']['wp_size'], $valid_sizes)
                            ? $column['image_settings']['wp_size']
                            : 'thumbnail',
                    );
                }

                // Sanitize product settings if present
                if (isset($column['product_settings']) && is_array($column['product_settings'])) {
                    $valid_displays = array('price', 'discounted_price', 'price_range', 'product_type', 'booking_type', 'stock', 'calendar', 'deliverables', 'summary');
                    $sanitized_column['product_settings'] = array(
                        'display' => isset($column['product_settings']['display']) && in_array($column['product_settings']['display'], $valid_displays)
                            ? $column['product_settings']['display']
                            : 'price',
                    );
                }

                // Sanitize poll settings if present
                if (isset($column['poll_settings']) && is_array($column['poll_settings'])) {
                    $valid_displays = array('most_voted', 'most_voted_percent', 'least_voted', 'least_voted_percent', 'total_votes', 'option_count', 'summary');
                    $sanitized_column['poll_settings'] = array(
                        'display' => isset($column['poll_settings']['display']) && in_array($column['poll_settings']['display'], $valid_displays)
                            ? $column['poll_settings']['display']
                            : 'most_voted',
                    );
                }

                // Sanitize work hours settings if present
                if (isset($column['work_hours_settings']) && is_array($column['work_hours_settings'])) {
                    $valid_displays = array('status', 'today', 'badge');
                    $sanitized_column['work_hours_settings'] = array(
                        'display' => isset($column['work_hours_settings']['display']) && in_array($column['work_hours_settings']['display'], $valid_displays)
                            ? $column['work_hours_settings']['display']
                            : 'status',
                    );
                }

                // Sanitize location settings if present
                if (isset($column['location_settings']) && is_array($column['location_settings'])) {
                    $valid_displays = array('address', 'coordinates', 'latitude', 'longitude', 'full');
                    $sanitized_column['location_settings'] = array(
                        'display' => isset($column['location_settings']['display']) && in_array($column['location_settings']['display'], $valid_displays)
                            ? $column['location_settings']['display']
                            : 'address',
                    );
                }

                // Sanitize date settings if present
                if (isset($column['date_settings']) && is_array($column['date_settings'])) {
                    $valid_displays = array('date', 'datetime', 'relative');
                    $valid_date_formats = array('wordpress', 'j F Y', 'F j, Y', 'Y-m-d', 'm/d/Y', 'd/m/Y', 'd.m.Y', 'M j, Y', 'j M Y', 'custom');
                    $valid_time_formats = array('wordpress', 'g:i a', 'g:i A', 'H:i', 'H:i:s', 'custom');
                    $sanitized_column['date_settings'] = array(
                        'display' => isset($column['date_settings']['display']) && in_array($column['date_settings']['display'], $valid_displays)
                            ? $column['date_settings']['display']
                            : 'date',
                        'date_format' => isset($column['date_settings']['date_format']) && in_array($column['date_settings']['date_format'], $valid_date_formats)
                            ? $column['date_settings']['date_format']
                            : 'wordpress',
                        'custom_date_format' => isset($column['date_settings']['custom_date_format'])
                            ? sanitize_text_field($column['date_settings']['custom_date_format'])
                            : '',
                        'time_format' => isset($column['date_settings']['time_format']) && in_array($column['date_settings']['time_format'], $valid_time_formats)
                            ? $column['date_settings']['time_format']
                            : 'wordpress',
                        'custom_time_format' => isset($column['date_settings']['custom_time_format'])
                            ? sanitize_text_field($column['date_settings']['custom_time_format'])
                            : '',
                    );
                }

                // Sanitize recurring date settings if present
                if (isset($column['recurring_date_settings']) && is_array($column['recurring_date_settings'])) {
                    $valid_displays = array('start_date', 'start_datetime', 'end_date', 'end_datetime', 'date_range', 'frequency', 'multiday', 'allday', 'summary');
                    $sanitized_column['recurring_date_settings'] = array(
                        'display' => isset($column['recurring_date_settings']['display']) && in_array($column['recurring_date_settings']['display'], $valid_displays)
                            ? $column['recurring_date_settings']['display']
                            : 'start_date',
                    );
                }

                // Sanitize listing plan settings if present
                if (isset($column['listing_plan_settings']) && is_array($column['listing_plan_settings'])) {
                    $valid_displays = array('plan_name', 'amount', 'frequency', 'purchase_date', 'expiration', 'summary');
                    $sanitized_column['listing_plan_settings'] = array(
                        'display' => isset($column['listing_plan_settings']['display']) && in_array($column['listing_plan_settings']['display'], $valid_displays)
                            ? $column['listing_plan_settings']['display']
                            : 'plan_name',
                    );
                }

                // Sanitize title settings if present
                if (isset($column['title_settings']) && is_array($column['title_settings'])) {
                    $sanitized_column['title_settings'] = array(
                        'show_link' => isset($column['title_settings']['show_link'])
                            ? (bool) $column['title_settings']['show_link']
                            : true,
                        'show_actions' => isset($column['title_settings']['show_actions'])
                            ? (bool) $column['title_settings']['show_actions']
                            : true,
                    );
                }

                // Sanitize text settings if present (for textarea, description, texteditor)
                if (isset($column['text_settings']) && is_array($column['text_settings'])) {
                    $valid_limit_types = array('words', 'characters', 'none');
                    $sanitized_column['text_settings'] = array(
                        'limit_type' => isset($column['text_settings']['limit_type']) && in_array($column['text_settings']['limit_type'], $valid_limit_types)
                            ? $column['text_settings']['limit_type']
                            : 'words',
                        'limit_value' => isset($column['text_settings']['limit_value'])
                            ? min(1000, max(1, absint($column['text_settings']['limit_value'])))
                            : 20,
                    );
                }

                // Sanitize helpful settings if present (for article-helpful)
                if (isset($column['helpful_settings']) && is_array($column['helpful_settings'])) {
                    $valid_displays = array('summary', 'yes_count', 'no_count', 'total', 'percentage');
                    $sanitized_column['helpful_settings'] = array(
                        'display' => isset($column['helpful_settings']['display']) && in_array($column['helpful_settings']['display'], $valid_displays)
                            ? $column['helpful_settings']['display']
                            : 'summary',
                    );
                }

                $sanitized['columns'][] = $sanitized_column;
            }
        }

        // Sanitize settings
        if (isset($config['settings']) && is_array($config['settings'])) {
            if (isset($config['settings']['default_sort'])) {
                $sanitized['settings']['default_sort'] = array(
                    'column' => isset($config['settings']['default_sort']['column'])
                        ? sanitize_text_field($config['settings']['default_sort']['column'])
                        : 'date',
                    'order' => isset($config['settings']['default_sort']['order']) && in_array($config['settings']['default_sort']['order'], array('asc', 'desc'))
                        ? $config['settings']['default_sort']['order']
                        : 'desc',
                );
            }

            if (isset($config['settings']['primary_column'])) {
                $sanitized['settings']['primary_column'] = sanitize_text_field($config['settings']['primary_column']);
            }
        }

        return $sanitized;
    }

    /**
     * Generate unique ID
     */
    private function generate_id() {
        return 'col_' . substr(md5(uniqid()), 0, 8);
    }

    /**
     * Track if hooks have been registered
     */
    private static $hooks_registered = false;

    /**
     * Register column hooks for all configured post types
     */
    public function register_column_hooks() {
        // Prevent double registration
        if (self::$hooks_registered) {
            return;
        }
        self::$hooks_registered = true;

        $configs = get_option('voxel_toolkit_admin_columns', array());

        if (empty($configs)) {
            return;
        }

        foreach ($configs as $post_type => $config) {
            if (empty($config['columns'])) {
                continue;
            }

            // Store config in closure
            $columns_config = $config;
            $renderer = $this->renderer;
            $column_types = $this->column_types;

            // Store for closure
            $current_post_type = $post_type;
            $self = $this;

            // Set up column handling on current_screen (runs after Voxel sets up its handlers)
            add_action('current_screen', function($screen) use ($post_type, $columns_config, $renderer, $self) {
                if ($screen->id !== "edit-{$post_type}") {
                    return;
                }

                // Remove Voxel's column handlers (they output to every column incorrectly)
                remove_all_actions("manage_{$post_type}_posts_custom_column");

                // Add our handler
                add_action("manage_{$post_type}_posts_custom_column", function($column, $post_id) use ($columns_config, $renderer, $self) {
                    $self->render_column_content_public($column, $post_id, $columns_config, $renderer);
                }, 10, 2);

                // Modify column headers at max priority - remove Voxel's default columns
                add_filter("manage_{$post_type}_posts_columns", function($columns) use ($columns_config, $self) {
                    unset($columns['vx_listing_plan']);
                    unset($columns['vx_verified']);
                    unset($columns['vx_author']);
                    return $self->modify_columns($columns, $columns_config);
                }, PHP_INT_MAX);

                // Set our title column as the primary column
                // This ensures WordPress bulk edit can find post titles correctly
                // Row actions are filtered out separately via post_row_actions filter
                add_filter('list_table_primary_column', function($primary, $screen_id) use ($post_type, $columns_config) {
                    if ($screen_id === "edit-{$post_type}") {
                        // Return our title column ID so WordPress bulk edit works correctly
                        return 'col_title';
                    }
                    return $primary;
                }, PHP_INT_MAX, 2);

                // Also filter post_row_actions to return empty array
                // This ensures no row actions are added by WordPress or other plugins
                add_filter('post_row_actions', function($actions, $post) use ($post_type) {
                    if ($post->post_type === $post_type) {
                        return array();
                    }
                    return $actions;
                }, PHP_INT_MAX, 2);

                // Also filter page_row_actions for hierarchical post types
                add_filter('page_row_actions', function($actions, $post) use ($post_type) {
                    if ($post->post_type === $post_type) {
                        return array();
                    }
                    return $actions;
                }, PHP_INT_MAX, 2);
            }, PHP_INT_MAX);

            // Register sortable columns
            add_filter("manage_edit-{$post_type}_sortable_columns", function($sortable) use ($columns_config) {
                return $this->register_sortable_columns($sortable, $columns_config);
            });
        }

        // Handle sorting query
        add_action('pre_get_posts', array($this, 'handle_sort_query'));

        // Handle filter query
        add_action('pre_get_posts', array($this, 'handle_filter_query'));

        // Add filter bar
        add_action('restrict_manage_posts', array($this, 'render_filter_bar'));

        // Enqueue filter bar assets
        add_action('admin_enqueue_scripts', array($this, 'enqueue_filter_assets'));

        // Add export modal
        add_action('admin_footer', array($this, 'render_export_modal'));

        // Add Edit Columns link
        add_action('manage_posts_extra_tablenav', array($this, 'render_edit_columns_link'));
    }

    /**
     * Render the Edit Columns link in the post list table
     */
    public function render_edit_columns_link($which) {
        // Only show on the top tablenav
        if ($which !== 'top') {
            return;
        }

        global $typenow;

        if (empty($typenow)) {
            return;
        }

        $configs = get_option('voxel_toolkit_admin_columns', array());

        // Only show for configured post types
        if (!isset($configs[$typenow])) {
            return;
        }

        // Check user capability
        if (!current_user_can('manage_options')) {
            return;
        }

        $edit_url = admin_url('admin.php?page=vt-admin-columns&type=' . urlencode($typenow));

        ?>
        <a href="<?php echo esc_url($edit_url); ?>" class="button vt-edit-columns-btn" style="margin-left: 8px;">
            <span class="dashicons dashicons-admin-generic" style="vertical-align: middle; margin-top: -2px; font-size: 16px;"></span>
            <?php _e('Edit Columns', 'voxel-toolkit'); ?>
        </a>
        <button type="button" class="button vt-export-btn" id="vt-export-btn" style="margin-left: 4px;">
            <span class="dashicons dashicons-download" style="vertical-align: middle; margin-top: -2px; font-size: 16px;"></span>
            <?php _e('Export', 'voxel-toolkit'); ?>
        </button>
        <?php
    }

    /**
     * Render clear filter button via JavaScript
     */
    public function render_clear_filter_button() {
        global $typenow;

        if (empty($typenow)) {
            return;
        }

        $configs = get_option('voxel_toolkit_admin_columns', array());

        if (!isset($configs[$typenow])) {
            return;
        }

        // Check if any filters are active
        $has_active_filters = false;
        $filter_params = array();

        foreach ($configs[$typenow]['columns'] as $col) {
            if (empty($col['filterable'])) {
                continue;
            }

            // Determine the filter key based on field type
            $filter_key = 'vt_filter_' . $col['field_key'];

            // Special cases for WordPress/Voxel native parameters
            if ($col['field_key'] === ':status') {
                $filter_key = 'post_status';
            } elseif ($col['field_key'] === ':author') {
                $filter_key = 'author';
            } elseif ($col['field_key'] === ':listing_plan') {
                $filter_key = 'vt_filter_listing_plan';
            }

            if (isset($_GET[$filter_key]) && $_GET[$filter_key] !== '') {
                $has_active_filters = true;
                $filter_params[] = $filter_key;
            }
        }

        // Build clear URL (current URL without filter params)
        $clear_url = remove_query_arg($filter_params);

        ?>
        <script>
        (function() {
            var hasActiveFilters = <?php echo $has_active_filters ? 'true' : 'false'; ?>;
            var clearUrl = <?php echo wp_json_encode($clear_url); ?>;

            if (!hasActiveFilters) {
                return;
            }

            function addClearButton() {
                // Find the Filter button
                var filterButton = document.querySelector('#post-query-submit');
                if (!filterButton) {
                    return;
                }

                // Check if clear button already exists
                if (document.querySelector('.vt-clear-filter-btn')) {
                    return;
                }

                // Create clear button
                var clearBtn = document.createElement('a');
                clearBtn.href = clearUrl;
                clearBtn.className = 'button vt-clear-filter-btn';
                clearBtn.style.marginLeft = '4px';
                clearBtn.innerHTML = '<?php echo esc_js(__('Clear', 'voxel-toolkit')); ?>';

                // Insert after Filter button
                filterButton.parentNode.insertBefore(clearBtn, filterButton.nextSibling);
            }

            // Run when DOM is ready
            if (document.readyState === 'loading') {
                document.addEventListener('DOMContentLoaded', addClearButton);
            } else {
                addClearButton();
            }
        })();
        </script>
        <?php
    }

    /**
     * Render export modal
     */
    public function render_export_modal() {
        global $typenow;

        if (empty($typenow)) {
            return;
        }

        $configs = get_option('voxel_toolkit_admin_columns', array());

        if (!isset($configs[$typenow])) {
            return;
        }

        if (!current_user_can('manage_options')) {
            return;
        }

        $config = $configs[$typenow];
        $columns = $config['columns'];

        // Get total count based on current filters
        global $wp_query;
        $total_items = $wp_query->found_posts ?? 0;

        ?>
        <!-- Export Modal Overlay -->
        <div id="vt-export-modal-overlay" class="vt-export-overlay" style="display: none;">
            <div class="vt-export-modal">
                <div class="vt-export-header">
                    <h2><?php _e('Export', 'voxel-toolkit'); ?></h2>
                    <button type="button" class="vt-export-close" id="vt-export-close">&times;</button>
                </div>
                <div class="vt-export-body">
                    <div class="vt-export-columns" id="vt-export-columns">
                        <?php foreach ($columns as $col) : ?>
                        <div class="vt-export-column-item" data-column-id="<?php echo esc_attr($col['id']); ?>">
                            <span class="vt-export-drag-handle">⋮⋮</span>
                            <label class="vt-export-toggle-switch">
                                <input type="checkbox" checked data-column-id="<?php echo esc_attr($col['id']); ?>">
                                <span class="vt-export-toggle-slider"></span>
                            </label>
                            <span class="vt-export-column-label"><?php echo esc_html($col['label']); ?></span>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <div class="vt-export-footer">
                    <div class="vt-export-count">
                        <?php printf(__('This will affect <strong>%s items</strong>', 'voxel-toolkit'), '<span id="vt-export-count">' . number_format_i18n($total_items) . '</span>'); ?>
                    </div>
                    <button type="button" class="button button-primary vt-export-submit" id="vt-export-submit">
                        <?php _e('Export', 'voxel-toolkit'); ?>
                    </button>
                </div>
            </div>
        </div>

        <style>
        .vt-export-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.6);
            z-index: 100000;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .vt-export-modal {
            background: #fff;
            border-radius: 8px;
            width: 400px;
            max-width: 90vw;
            max-height: 80vh;
            display: flex;
            flex-direction: column;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.3);
        }
        .vt-export-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 16px 20px;
            border-bottom: 1px solid #eee;
        }
        .vt-export-header h2 {
            margin: 0;
            font-size: 18px;
            font-weight: 600;
        }
        .vt-export-close {
            background: none;
            border: none;
            font-size: 24px;
            cursor: pointer;
            color: #666;
            padding: 0;
            line-height: 1;
        }
        .vt-export-close:hover {
            color: #333;
        }
        .vt-export-body {
            padding: 16px 20px;
            overflow-y: auto;
            flex: 1;
        }
        .vt-export-columns {
            display: flex;
            flex-direction: column;
            gap: 8px;
        }
        .vt-export-column-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 8px 0;
        }
        .vt-export-drag-handle {
            cursor: grab;
            color: #999;
            font-size: 14px;
            user-select: none;
        }
        .vt-export-drag-handle:active {
            cursor: grabbing;
        }
        .vt-export-column-label {
            flex: 1;
            font-size: 14px;
        }
        /* Toggle Switch */
        .vt-export-toggle-switch {
            position: relative;
            display: inline-block;
            width: 44px;
            height: 24px;
            flex-shrink: 0;
        }
        .vt-export-toggle-switch input {
            opacity: 0;
            width: 0;
            height: 0;
        }
        .vt-export-toggle-slider {
            position: absolute;
            cursor: pointer;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-color: #ccc;
            transition: .3s;
            border-radius: 24px;
        }
        .vt-export-toggle-slider:before {
            position: absolute;
            content: "";
            height: 18px;
            width: 18px;
            left: 3px;
            bottom: 3px;
            background-color: white;
            transition: .3s;
            border-radius: 50%;
        }
        .vt-export-toggle-switch input:checked + .vt-export-toggle-slider {
            background-color: #2271b1;
        }
        .vt-export-toggle-switch input:checked + .vt-export-toggle-slider:before {
            transform: translateX(20px);
        }
        .vt-export-footer {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 16px 20px;
            border-top: 1px solid #eee;
            background: #f9f9f9;
            border-radius: 0 0 8px 8px;
        }
        .vt-export-count {
            font-size: 14px;
            color: #666;
        }
        .vt-export-submit {
            min-width: 100px;
        }
        .vt-export-submit:disabled {
            opacity: 0.6;
            cursor: not-allowed;
        }
        /* Sortable styles */
        .vt-export-column-item.sortable-ghost {
            opacity: 0.4;
        }
        .vt-export-column-item.sortable-drag {
            background: #fff;
            box-shadow: 0 2px 8px rgba(0,0,0,0.15);
        }
        </style>

        <script>
        (function() {
            var modal = document.getElementById('vt-export-modal-overlay');
            var openBtn = document.getElementById('vt-export-btn');
            var closeBtn = document.getElementById('vt-export-close');
            var submitBtn = document.getElementById('vt-export-submit');
            var columnsContainer = document.getElementById('vt-export-columns');

            if (!modal || !openBtn) return;

            // Open modal
            openBtn.addEventListener('click', function(e) {
                e.preventDefault();
                modal.style.display = 'flex';
                initSortable();
            });

            // Close modal
            closeBtn.addEventListener('click', function() {
                modal.style.display = 'none';
            });

            // Close on overlay click
            modal.addEventListener('click', function(e) {
                if (e.target === modal) {
                    modal.style.display = 'none';
                }
            });

            // Close on Escape key
            document.addEventListener('keydown', function(e) {
                if (e.key === 'Escape' && modal.style.display === 'flex') {
                    modal.style.display = 'none';
                }
            });

            // Initialize Sortable for column reordering
            var sortableInstance = null;
            function initSortable() {
                if (sortableInstance) return;
                if (typeof Sortable !== 'undefined') {
                    sortableInstance = new Sortable(columnsContainer, {
                        handle: '.vt-export-drag-handle',
                        animation: 150,
                        ghostClass: 'sortable-ghost',
                        dragClass: 'sortable-drag'
                    });
                }
            }

            // Export functionality
            submitBtn.addEventListener('click', function() {
                var selectedColumns = [];
                var items = columnsContainer.querySelectorAll('.vt-export-column-item');

                items.forEach(function(item) {
                    var checkbox = item.querySelector('input[type="checkbox"]');
                    if (checkbox && checkbox.checked) {
                        selectedColumns.push(item.dataset.columnId);
                    }
                });

                if (selectedColumns.length === 0) {
                    alert('<?php echo esc_js(__('Please select at least one column to export.', 'voxel-toolkit')); ?>');
                    return;
                }

                submitBtn.disabled = true;
                submitBtn.textContent = '<?php echo esc_js(__('Exporting...', 'voxel-toolkit')); ?>';

                // Get current URL params for filters
                var urlParams = new URLSearchParams(window.location.search);
                var queryArgs = {};
                urlParams.forEach(function(value, key) {
                    queryArgs[key] = value;
                });

                // Make AJAX request
                var formData = new FormData();
                formData.append('action', 'vt_admin_columns_export');
                formData.append('nonce', '<?php echo wp_create_nonce('vt_admin_columns_nonce'); ?>');
                formData.append('post_type', '<?php echo esc_js($typenow); ?>');
                selectedColumns.forEach(function(col) {
                    formData.append('columns[]', col);
                });
                formData.append('query_args', JSON.stringify(queryArgs));

                fetch(ajaxurl, {
                    method: 'POST',
                    body: formData
                })
                .then(function(response) { return response.json(); })
                .then(function(data) {
                    if (data.success) {
                        downloadCSV(data.data.data, data.data.filename);
                        modal.style.display = 'none';
                    } else {
                        alert(data.data.message || '<?php echo esc_js(__('Export failed.', 'voxel-toolkit')); ?>');
                    }
                })
                .catch(function(error) {
                    console.error('Export error:', error);
                    alert('<?php echo esc_js(__('Export failed.', 'voxel-toolkit')); ?>');
                })
                .finally(function() {
                    submitBtn.disabled = false;
                    submitBtn.textContent = '<?php echo esc_js(__('Export', 'voxel-toolkit')); ?>';
                });
            });

            // Download CSV
            function downloadCSV(data, filename) {
                var csv = data.map(function(row) {
                    return row.map(function(cell) {
                        // Escape quotes and wrap in quotes if contains comma, quote, or newline
                        var cellStr = String(cell === null || cell === undefined ? '' : cell);
                        if (cellStr.indexOf(',') !== -1 || cellStr.indexOf('"') !== -1 || cellStr.indexOf('\n') !== -1) {
                            cellStr = '"' + cellStr.replace(/"/g, '""') + '"';
                        }
                        return cellStr;
                    }).join(',');
                }).join('\n');

                // Add BOM for Excel UTF-8 compatibility
                var blob = new Blob(['\ufeff' + csv], { type: 'text/csv;charset=utf-8;' });
                var link = document.createElement('a');
                var url = URL.createObjectURL(blob);
                link.setAttribute('href', url);
                link.setAttribute('download', filename);
                link.style.visibility = 'hidden';
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
            }
        })();
        </script>
        <?php
    }

    /**
     * Modify columns for a post type
     */
    private function modify_columns($columns, $config) {
        $new_columns = array();

        // Keep checkbox column
        if (isset($columns['cb'])) {
            $new_columns['cb'] = $columns['cb'];
        }

        // Add configured columns - use unique ID to allow duplicate fields
        foreach ($config['columns'] as $col) {
            $column_key = 'vt_' . $col['id'];
            $new_columns[$column_key] = !empty($col['label']) ? $col['label'] : $col['field_key'];
        }

        // Note: We don't keep the default 'date' column since users can add :date if they want it

        return $new_columns;
    }

    /**
     * Public wrapper for render_column_content (needed for closure callback)
     */
    public function render_column_content_public($column, $post_id, $config, $renderer) {
        $this->render_column_content($column, $post_id, $config, $renderer);
    }

    /**
     * Render column content
     */
    private function render_column_content($column, $post_id, $config, $renderer) {
        // Check if this is one of our columns
        if (strpos($column, 'vt_') !== 0) {
            return;
        }

        $column_id = substr($column, 3); // Remove 'vt_' prefix

        // Find the column config by ID
        $column_config = null;
        foreach ($config['columns'] as $col) {
            if ($col['id'] === $column_id) {
                $column_config = $col;
                break;
            }
        }

        if (!$column_config) {
            echo '&mdash;';
            return;
        }


        // Pass column config to renderer for image sizing - use field_key for rendering
        echo $renderer->render($column_config['field_key'], $post_id, $column_config);
    }

    /**
     * Register sortable columns
     */
    private function register_sortable_columns($sortable, $config) {
        foreach ($config['columns'] as $col) {
            if (!empty($col['sortable'])) {
                $column_key = 'vt_' . $col['id'];
                $sortable[$column_key] = $col['field_key'];
            }
        }

        return $sortable;
    }

    /**
     * Handle sort query modifications
     */
    public function handle_sort_query($query) {
        if (!is_admin() || !$query->is_main_query()) {
            return;
        }

        $orderby = $query->get('orderby');

        if (empty($orderby)) {
            return;
        }

        $post_type = $query->get('post_type');
        $configs = get_option('voxel_toolkit_admin_columns', array());

        if (!isset($configs[$post_type])) {
            return;
        }

        // Check if sorting by one of our columns
        foreach ($configs[$post_type]['columns'] as $col) {
            if ($col['field_key'] === $orderby && !empty($col['sortable'])) {
                // Handle WordPress core fields (prefixed with :)
                if (strpos($col['field_key'], ':') === 0) {
                    $this->handle_wp_field_sort($query, $col['field_key']);
                }
                // Handle Voxel title field (maps to post_title)
                elseif ($col['field_key'] === 'title') {
                    $query->set('orderby', 'title');
                }
                else {
                    $field_type = $this->get_field_type($col['field_key'], $post_type);

                    // Handle product fields with custom sorting
                    if ($field_type === 'product') {
                        $this->handle_product_sort($query, $col['field_key']);
                    } else {
                        // Handle Voxel meta fields
                        $query->set('meta_key', $col['field_key']);

                        // Determine if numeric sort is needed
                        $type_info = $this->column_types->get_type_info($field_type);
                        $query->set('orderby', $type_info['numeric'] ? 'meta_value_num' : 'meta_value');
                    }
                }

                break;
            }
        }
    }

    /**
     * Handle sorting for product fields (extract price from JSON)
     */
    private function handle_product_sort($query, $field_key) {
        // Add filter to modify SQL query
        add_filter('posts_clauses', function($clauses, $wp_query) use ($field_key) {
            global $wpdb;

            if (!$wp_query->is_main_query() || is_admin() === false) {
                return $clauses;
            }

            // Extract price from JSON using MySQL JSON functions
            // JSON path: $.base_price.amount
            $clauses['join'] .= " LEFT JOIN {$wpdb->postmeta} AS vt_product_sort ON {$wpdb->posts}.ID = vt_product_sort.post_id AND vt_product_sort.meta_key = '" . esc_sql($field_key) . "'";

            // Use CAST(JSON_EXTRACT()) to get numeric price value
            $clauses['orderby'] = "CAST(JSON_UNQUOTE(JSON_EXTRACT(vt_product_sort.meta_value, '$.base_price.amount')) AS DECIMAL(10,2)) " . esc_sql($wp_query->get('order', 'ASC'));

            return $clauses;
        }, 10, 2);
    }

    /**
     * Handle sorting for WordPress core fields
     */
    private function handle_wp_field_sort($query, $field_key) {
        switch ($field_key) {
            case ':date':
                $query->set('orderby', 'date');
                break;

            case ':modified':
                $query->set('orderby', 'modified');
                break;

            case ':author':
                $query->set('orderby', 'author');
                break;

            case ':id':
                $query->set('orderby', 'ID');
                break;

            case ':slug':
                $query->set('orderby', 'name');
                break;

            case ':comments':
                $query->set('orderby', 'comment_count');
                break;

            case ':menu_order':
                $query->set('orderby', 'menu_order');
                break;
        }
    }

    /**
     * Enqueue filter bar assets for post list pages
     */
    public function enqueue_filter_assets($hook) {
        if ($hook !== 'edit.php') {
            return;
        }

        global $typenow;

        if (empty($typenow)) {
            return;
        }

        $configs = get_option('voxel_toolkit_admin_columns', array());

        if (!isset($configs[$typenow])) {
            return;
        }

        // Check if any columns have filterable enabled
        $has_filterable = false;
        foreach ($configs[$typenow]['columns'] as $col) {
            if (!empty($col['filterable'])) {
                $has_filterable = true;
                break;
            }
        }

        if (!$has_filterable) {
            return;
        }

        Voxel_Toolkit_Filter_Bar::enqueue_assets();
    }

    /**
     * Render the filter bar for posts
     */
    public function render_filter_bar($post_type) {
        $configs = get_option('voxel_toolkit_admin_columns', array());

        if (!isset($configs[$post_type])) {
            return;
        }

        // Get filterable fields
        $filterable_fields = $this->get_filterable_fields($post_type, $configs[$post_type]);

        if (empty($filterable_fields)) {
            return;
        }

        // Create and render filter bar
        $filter_bar = new Voxel_Toolkit_Filter_Bar('posts', $post_type);
        $filter_bar->set_fields($filterable_fields);
        $filter_bar->render();
    }

    /**
     * Get filterable fields for a post type
     */
    private function get_filterable_fields($post_type, $config) {
        $fields = array();

        foreach ($config['columns'] as $col) {
            if (empty($col['filterable'])) {
                continue;
            }

            $field = array(
                'key' => $col['field_key'],
                'label' => $col['label'],
            );

            // Determine filter type based on field
            if ($col['field_key'] === ':status') {
                $field['filter_type'] = 'select';
                $field['options'] = $this->get_status_options();
            } elseif ($col['field_key'] === ':author') {
                $field['filter_type'] = 'select';
                $field['options'] = $this->get_author_options($post_type);
            } elseif ($col['field_key'] === ':listing_plan') {
                $field['filter_type'] = 'select';
                $field['options'] = $this->get_listing_plan_options($post_type);
            } else {
                // Get field type from Voxel
                $voxel_type = $this->get_field_type($col['field_key'], $post_type);

                // Map field types to appropriate filter types for operator selection
                $filter_type = $this->map_field_to_filter_type($voxel_type, $col['field_key']);
                $field['filter_type'] = $filter_type;

                // Get options for select/taxonomy fields
                if ($voxel_type === 'taxonomy') {
                    $taxonomy = $this->get_taxonomy_for_field($col['field_key'], $post_type);
                    if ($taxonomy) {
                        $field['taxonomy'] = $taxonomy;
                        $field['options'] = $this->get_taxonomy_options($taxonomy);
                    }
                } elseif ($voxel_type === 'select') {
                    $field['options'] = $this->get_select_field_options($col['field_key'], $post_type);
                } elseif ($voxel_type === 'switcher') {
                    $field['options'] = array(
                        array('value' => '1', 'label' => __('Yes', 'voxel-toolkit')),
                        array('value' => '0', 'label' => __('No', 'voxel-toolkit')),
                    );
                }
            }

            $fields[] = $field;
        }

        return $fields;
    }

    /**
     * Map field types to filter types for appropriate operator selection
     *
     * @param string $field_type The Voxel field type
     * @param string $field_key The field key
     * @return string The filter type for operator selection
     */
    private function map_field_to_filter_type($field_type, $field_key) {
        // WordPress core fields with specific types
        $wp_field_types = array(
            ':id' => 'number',
            ':date' => 'date',
            ':modified' => 'date',
            ':menu_order' => 'number',
            ':comments' => 'number',
            ':word_count' => 'number',
            ':view_counts' => 'number',
            ':review_stats' => 'number',
            ':article_helpful' => 'number',
        );

        if (isset($wp_field_types[$field_key])) {
            return $wp_field_types[$field_key];
        }

        // Map Voxel field types to filter types
        $type_map = array(
            // Numeric types - use number operators (equals, greater than, less than, etc.)
            'number' => 'number',
            'product' => 'number',
            'poll' => 'number',
            'poll-vt' => 'number',
            'article-helpful' => 'number',

            // Date types - use date operators (equals, before, after)
            'date' => 'date',
            'recurring-date' => 'date',
            'event-date' => 'date',
            'time' => 'date',

            // Text types - use text operators (equals, contains, starts with, etc.)
            'text' => 'text',
            'title' => 'text',
            'textarea' => 'text',
            'texteditor' => 'text',
            'description' => 'text',
            'email' => 'text',
            'phone' => 'text',
            'url' => 'text',
            'color' => 'text',
            'timezone' => 'text',
            'profile-name' => 'text',

            // Select types - use select operators (is, is not)
            'select' => 'select',
            'multiselect' => 'select',
            'post-relation' => 'select',

            // Taxonomy - use taxonomy operators
            'taxonomy' => 'taxonomy',

            // Boolean/existence - use boolean operators (is empty, is not empty)
            'switcher' => 'boolean',
            'image' => 'boolean',
            'file' => 'boolean',
        );

        return isset($type_map[$field_type]) ? $type_map[$field_type] : 'text';
    }

    /**
     * Get status options for filter
     */
    private function get_status_options() {
        $statuses = get_post_stati(array('show_in_admin_status_list' => true), 'objects');
        $options = array();

        foreach ($statuses as $status) {
            $options[] = array(
                'value' => $status->name,
                'label' => $status->label,
            );
        }

        return $options;
    }

    /**
     * Get author options for filter
     * Queries actual post authors for the specific post type (includes all users, not just those with author role)
     */
    private function get_author_options($post_type = '') {
        global $wpdb;

        // Query distinct post authors for this post type
        $query = "SELECT DISTINCT p.post_author
                  FROM {$wpdb->posts} p
                  WHERE p.post_type = %s
                  AND p.post_status != 'auto-draft'
                  AND p.post_author > 0";

        $author_ids = $wpdb->get_col($wpdb->prepare($query, $post_type));

        if (empty($author_ids)) {
            return array();
        }

        // Get user data for these authors
        $authors = get_users(array(
            'include' => $author_ids,
            'orderby' => 'display_name',
            'order' => 'ASC',
        ));

        $options = array();
        foreach ($authors as $author) {
            $options[] = array(
                'value' => (string) $author->ID,
                'label' => $author->display_name,
            );
        }

        return $options;
    }

    /**
     * Get listing plan options for filter
     */
    private function get_listing_plan_options($post_type) {
        $plans = $this->get_listing_plans($post_type);
        $options = array();

        foreach ($plans as $key => $label) {
            $options[] = array(
                'value' => $key,
                'label' => $label,
            );
        }

        return $options;
    }

    /**
     * Get taxonomy options for filter
     */
    private function get_taxonomy_options($taxonomy) {
        $terms = get_terms(array(
            'taxonomy' => $taxonomy,
            'hide_empty' => true,
            'orderby' => 'name',
            'order' => 'ASC',
        ));

        $options = array();
        if (!is_wp_error($terms)) {
            foreach ($terms as $term) {
                $options[] = array(
                    'value' => (string) $term->term_id,
                    'label' => $term->name . ' (' . $term->count . ')',
                );
            }
        }

        return $options;
    }

    /**
     * Get select field options
     */
    private function get_select_field_options($field_key, $post_type) {
        $filter_options = $this->get_filter_options($field_key, $post_type, 'select');
        $options = array();

        foreach ($filter_options as $value => $label) {
            $options[] = array(
                'value' => $value,
                'label' => $label,
            );
        }

        return $options;
    }

    /**
     * Get listing plans for a post type
     */
    private function get_listing_plans($post_type) {
        if (!class_exists('\Voxel\Post_Type')) {
            return array();
        }

        $voxel_post_type = \Voxel\Post_Type::get($post_type);
        if (!$voxel_post_type) {
            return array();
        }

        $plans = array();

        // Try to get plans from Voxel
        if (method_exists($voxel_post_type, 'get_plans')) {
            $voxel_plans = $voxel_post_type->get_plans();
            foreach ($voxel_plans as $plan) {
                if (method_exists($plan, 'get_key') && method_exists($plan, 'get_label')) {
                    $plans[$plan->get_key()] = $plan->get_label();
                }
            }
        }

        return $plans;
    }

    /**
     * Get filter options for a field
     */
    private function get_filter_options($field_key, $post_type, $field_type) {
        if ($field_type === 'switcher') {
            return array(
                '1' => __('Yes', 'voxel-toolkit'),
                '0' => __('No', 'voxel-toolkit'),
            );
        }

        // For select fields, get options from field config
        if (!class_exists('\Voxel\Post_Type')) {
            return array();
        }

        $voxel_post_type = \Voxel\Post_Type::get($post_type);
        if (!$voxel_post_type) {
            return array();
        }

        $field = $voxel_post_type->get_field($field_key);
        if (!$field) {
            return array();
        }

        $options = array();
        $choices = null;

        // Try to get choices from field using get_prop (Voxel's method)
        if (method_exists($field, 'get_prop')) {
            $choices = $field->get_prop('choices');
        }

        // Fallback: try get_choices method if available
        if (empty($choices) && method_exists($field, 'get_choices')) {
            $choices = $field->get_choices();
        }

        // Process choices in various formats
        if (is_array($choices)) {
            foreach ($choices as $key => $choice) {
                // Format 1: array of ['value' => ..., 'label' => ...]
                if (is_array($choice) && isset($choice['value']) && isset($choice['label'])) {
                    $options[$choice['value']] = $choice['label'];
                }
                // Format 2: array of ['value' => ..., 'label' => ...] with 'key' instead of 'value'
                elseif (is_array($choice) && isset($choice['key']) && isset($choice['label'])) {
                    $options[$choice['key']] = $choice['label'];
                }
                // Format 3: simple key => label associative array
                elseif (is_string($choice) && is_string($key)) {
                    $options[$key] = $choice;
                }
                // Format 4: simple indexed array of values (use value as both key and label)
                elseif (is_string($choice) && is_int($key)) {
                    $options[$choice] = ucfirst(str_replace(array('-', '_'), ' ', $choice));
                }
            }
        }

        return $options;
    }

    /**
     * Handle filter query modifications
     */
    public function handle_filter_query($query) {
        if (!is_admin() || !$query->is_main_query()) {
            return;
        }

        $post_type = $query->get('post_type');
        $configs = get_option('voxel_toolkit_admin_columns', array());

        if (!isset($configs[$post_type])) {
            return;
        }

        // Parse filters from new filter bar system
        $filters = Voxel_Toolkit_Filter_Bar::parse_filters();

        if (empty($filters)) {
            return;
        }

        // Get filter logic FIRST
        $this->filter_logic = Voxel_Toolkit_Filter_Bar::get_filter_logic();
        $this->filtering_post_type = $post_type;

        // Build field config for filter bar
        $field_config = array();
        foreach ($configs[$post_type]['columns'] as $col) {
            if (empty($col['filterable'])) {
                continue;
            }

            $field_type = $this->get_field_type($col['field_key'], $post_type);
            $field_config[$col['field_key']] = array(
                'filter_type' => $field_type,
                'field_type' => $field_type,
                'column_config' => $col,
            );

            if ($field_type === 'taxonomy') {
                $taxonomy = $this->get_taxonomy_for_field($col['field_key'], $post_type);
                if ($taxonomy) {
                    $field_config[$col['field_key']]['taxonomy'] = $taxonomy;
                }
            }
        }

        // Store all filters for processing in posts_where
        $this->all_post_filters = array();

        foreach ($filters as $filter) {
            $field_key = $filter['field'];
            $filter_data = array(
                'field_key' => $field_key,
                'operator' => $filter['operator'],
                'value' => $filter['value'],
                'field_config' => isset($field_config[$field_key]) ? $field_config[$field_key] : array(),
            );
            $this->all_post_filters[] = $filter_data;
        }

        // Add single hook to handle all filters with proper AND/OR logic
        if (!empty($this->all_post_filters)) {
            add_filter('posts_where', array($this, 'apply_all_post_filters_to_query'), 10, 2);
            add_filter('posts_join', array($this, 'apply_post_filters_join'), 10, 2);
        }
    }

    /**
     * Add necessary JOINs for post filters
     */
    public function apply_post_filters_join($join, $query) {
        if (!is_admin() || !$query->is_main_query()) {
            return $join;
        }

        if (empty($this->all_post_filters)) {
            return $join;
        }

        global $wpdb;

        // Track which joins we've added
        static $joins_added = array();
        $join_key = md5(serialize($this->all_post_filters));

        if (isset($joins_added[$join_key])) {
            return $join;
        }
        $joins_added[$join_key] = true;

        // Check if we need postmeta join
        $needs_postmeta = false;
        foreach ($this->all_post_filters as $filter) {
            $field_key = $filter['field_key'];
            // Fields that use postmeta
            if (!in_array($field_key, array(':status', ':author', ':id', ':slug', ':date', ':modified', ':parent', ':menu_order', ':comments'))) {
                if (empty($filter['field_config']['filter_type']) || $filter['field_config']['filter_type'] !== 'taxonomy') {
                    $needs_postmeta = true;
                    break;
                }
            }
        }

        // Only add the join if we need it and it's not already there
        if ($needs_postmeta && strpos($join, 'vt_postmeta') === false) {
            // We don't add a global join - we handle each meta filter with subqueries
        }

        return $join;
    }

    /**
     * Apply all post filters to query with proper AND/OR logic
     */
    public function apply_all_post_filters_to_query($where, $query) {
        if (!is_admin() || !$query->is_main_query()) {
            return $where;
        }

        if (empty($this->all_post_filters)) {
            return $where;
        }

        global $wpdb;

        $conditions = array();

        foreach ($this->all_post_filters as $filter) {
            $field_key = $filter['field_key'];
            $operator = $filter['operator'];
            $value = $filter['value'];
            $field_config = $filter['field_config'];

            $condition = $this->build_post_sql_condition($field_key, $operator, $value, $field_config);
            if ($condition) {
                $conditions[] = $condition;
            }
        }

        // Apply conditions with AND or OR logic
        if (!empty($conditions)) {
            $logic = $this->filter_logic === 'OR' ? ' OR ' : ' AND ';
            $where .= ' AND (' . implode($logic, $conditions) . ')';
        }

        // Clear filters after applying
        $this->all_post_filters = array();

        return $where;
    }

    /**
     * Build SQL condition for a single post filter
     */
    private function build_post_sql_condition($field_key, $operator, $value, $field_config) {
        global $wpdb;

        switch ($field_key) {
            case ':id':
                return $this->build_post_field_sql('ID', $operator, $value);

            case ':status':
                return $this->build_post_field_sql('post_status', $operator, $value);

            case ':author':
                return $this->build_post_field_sql('post_author', $operator, $value);

            case ':date':
                return $this->build_post_date_sql('post_date', $operator, $value);

            case ':modified':
                return $this->build_post_date_sql('post_modified', $operator, $value);

            case ':slug':
                return $this->build_post_field_sql('post_name', $operator, $value);

            case ':parent':
                return $this->build_post_field_sql('post_parent', $operator, $value);

            case ':menu_order':
                return $this->build_post_field_sql('menu_order', $operator, $value);

            case ':excerpt':
                return $this->build_post_field_sql('post_excerpt', $operator, $value);

            case ':comments':
                return $this->build_post_field_sql('comment_count', $operator, $value);

            case ':word_count':
                // Word count is calculated, use post_content length as approximation
                return $this->build_word_count_sql($operator, $value);

            case ':listing_plan':
                return $this->build_post_meta_sql('voxel:plan', $operator, $value);

            case ':view_counts':
                return $this->build_view_counts_sql($operator, $value);

            case ':review_stats':
                return $this->build_review_stats_sql($operator, $value);

            case ':article_helpful':
                return $this->build_article_helpful_sql($operator, $value);

            default:
                // Check if taxonomy
                if (!empty($field_config['filter_type']) && $field_config['filter_type'] === 'taxonomy') {
                    $taxonomy = isset($field_config['taxonomy']) ? $field_config['taxonomy'] : null;
                    if ($taxonomy) {
                        return $this->build_taxonomy_sql($taxonomy, $operator, $value);
                    }
                }

                // Check if product field (price stored as JSON)
                if (!empty($field_config['field_type']) && $field_config['field_type'] === 'product') {
                    return $this->build_product_sql($field_key, $operator, $value);
                }

                // Check if image/file field (only is_empty/is_not_empty make sense)
                if (!empty($field_config['field_type']) && in_array($field_config['field_type'], array('image', 'file'))) {
                    return $this->build_media_exists_sql($field_key, $operator);
                }

                // Check if post-relation field (array of post IDs)
                if (!empty($field_config['field_type']) && $field_config['field_type'] === 'post-relation') {
                    return $this->build_post_relation_sql($field_key, $operator, $value);
                }

                // Regular meta field (Voxel fields store without the leading colon in some cases)
                $meta_key = $field_key;
                return $this->build_post_meta_sql($meta_key, $operator, $value);
        }
    }

    /**
     * Build SQL for post table field
     */
    private function build_post_field_sql($field, $operator, $value) {
        global $wpdb;
        $column = "{$wpdb->posts}.{$field}";

        switch ($operator) {
            case 'equals':
                return $wpdb->prepare("{$column} = %s", $value);
            case 'not_equals':
                return $wpdb->prepare("{$column} != %s", $value);
            case 'contains':
                return $wpdb->prepare("{$column} LIKE %s", '%' . $wpdb->esc_like($value) . '%');
            case 'not_contains':
                return $wpdb->prepare("{$column} NOT LIKE %s", '%' . $wpdb->esc_like($value) . '%');
            case 'starts_with':
                return $wpdb->prepare("{$column} LIKE %s", $wpdb->esc_like($value) . '%');
            case 'ends_with':
                return $wpdb->prepare("{$column} LIKE %s", '%' . $wpdb->esc_like($value));
            case 'greater_than':
                return $wpdb->prepare("{$column} > %s", $value);
            case 'less_than':
                return $wpdb->prepare("{$column} < %s", $value);
            case 'greater_equal':
                return $wpdb->prepare("{$column} >= %s", $value);
            case 'less_equal':
                return $wpdb->prepare("{$column} <= %s", $value);
            case 'is_empty':
                return "({$column} IS NULL OR {$column} = '')";
            case 'is_not_empty':
                return "({$column} IS NOT NULL AND {$column} != '')";
        }
        return '';
    }

    /**
     * Build SQL for post date field
     */
    private function build_post_date_sql($field, $operator, $value) {
        global $wpdb;
        $column = "{$wpdb->posts}.{$field}";

        switch ($operator) {
            case 'equals':
                return $wpdb->prepare("DATE({$column}) = %s", $value);
            case 'not_equals':
                return $wpdb->prepare("DATE({$column}) != %s", $value);
            case 'greater_than':
            case 'after':
                return $wpdb->prepare("{$column} > %s", $value);
            case 'less_than':
            case 'before':
                return $wpdb->prepare("{$column} < %s", $value);
            case 'greater_equal':
                return $wpdb->prepare("{$column} >= %s", $value);
            case 'less_equal':
                return $wpdb->prepare("{$column} <= %s", $value);
        }
        return '';
    }

    /**
     * Build SQL for post meta field
     */
    private function build_post_meta_sql($meta_key, $operator, $value, $type = 'CHAR') {
        global $wpdb;

        switch ($operator) {
            case 'equals':
                return $wpdb->prepare(
                    "({$wpdb->posts}.ID IN (SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = %s AND meta_value = %s))",
                    $meta_key, $value
                );
            case 'not_equals':
                return $wpdb->prepare(
                    "({$wpdb->posts}.ID NOT IN (SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = %s AND meta_value = %s))",
                    $meta_key, $value
                );
            case 'contains':
                return $wpdb->prepare(
                    "({$wpdb->posts}.ID IN (SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = %s AND meta_value LIKE %s))",
                    $meta_key, '%' . $wpdb->esc_like($value) . '%'
                );
            case 'not_contains':
                return $wpdb->prepare(
                    "({$wpdb->posts}.ID NOT IN (SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = %s AND meta_value LIKE %s))",
                    $meta_key, '%' . $wpdb->esc_like($value) . '%'
                );
            case 'greater_than':
                if ($type === 'NUMERIC') {
                    return $wpdb->prepare(
                        "({$wpdb->posts}.ID IN (SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = %s AND CAST(meta_value AS SIGNED) > %d))",
                        $meta_key, intval($value)
                    );
                }
                return $wpdb->prepare(
                    "({$wpdb->posts}.ID IN (SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = %s AND meta_value > %s))",
                    $meta_key, $value
                );
            case 'less_than':
                if ($type === 'NUMERIC') {
                    return $wpdb->prepare(
                        "({$wpdb->posts}.ID IN (SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = %s AND CAST(meta_value AS SIGNED) < %d))",
                        $meta_key, intval($value)
                    );
                }
                return $wpdb->prepare(
                    "({$wpdb->posts}.ID IN (SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = %s AND meta_value < %s))",
                    $meta_key, $value
                );
            case 'greater_equal':
                if ($type === 'NUMERIC') {
                    return $wpdb->prepare(
                        "({$wpdb->posts}.ID IN (SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = %s AND CAST(meta_value AS SIGNED) >= %d))",
                        $meta_key, intval($value)
                    );
                }
                return $wpdb->prepare(
                    "({$wpdb->posts}.ID IN (SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = %s AND meta_value >= %s))",
                    $meta_key, $value
                );
            case 'less_equal':
                if ($type === 'NUMERIC') {
                    return $wpdb->prepare(
                        "({$wpdb->posts}.ID IN (SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = %s AND CAST(meta_value AS SIGNED) <= %d))",
                        $meta_key, intval($value)
                    );
                }
                return $wpdb->prepare(
                    "({$wpdb->posts}.ID IN (SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = %s AND meta_value <= %s))",
                    $meta_key, $value
                );
            case 'is_empty':
                return $wpdb->prepare(
                    "({$wpdb->posts}.ID NOT IN (SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = %s AND meta_value != ''))",
                    $meta_key
                );
            case 'is_not_empty':
                return $wpdb->prepare(
                    "({$wpdb->posts}.ID IN (SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = %s AND meta_value != ''))",
                    $meta_key
                );
        }
        return '';
    }

    /**
     * Build SQL for taxonomy field
     */
    private function build_taxonomy_sql($taxonomy, $operator, $value) {
        global $wpdb;

        switch ($operator) {
            case 'equals':
                return $wpdb->prepare(
                    "({$wpdb->posts}.ID IN (SELECT object_id FROM {$wpdb->term_relationships} tr
                     INNER JOIN {$wpdb->term_taxonomy} tt ON tr.term_taxonomy_id = tt.term_taxonomy_id
                     WHERE tt.taxonomy = %s AND tt.term_id = %d))",
                    $taxonomy, absint($value)
                );
            case 'not_equals':
                return $wpdb->prepare(
                    "({$wpdb->posts}.ID NOT IN (SELECT object_id FROM {$wpdb->term_relationships} tr
                     INNER JOIN {$wpdb->term_taxonomy} tt ON tr.term_taxonomy_id = tt.term_taxonomy_id
                     WHERE tt.taxonomy = %s AND tt.term_id = %d))",
                    $taxonomy, absint($value)
                );
            case 'is_empty':
                return $wpdb->prepare(
                    "({$wpdb->posts}.ID NOT IN (SELECT object_id FROM {$wpdb->term_relationships} tr
                     INNER JOIN {$wpdb->term_taxonomy} tt ON tr.term_taxonomy_id = tt.term_taxonomy_id
                     WHERE tt.taxonomy = %s))",
                    $taxonomy
                );
            case 'is_not_empty':
                return $wpdb->prepare(
                    "({$wpdb->posts}.ID IN (SELECT object_id FROM {$wpdb->term_relationships} tr
                     INNER JOIN {$wpdb->term_taxonomy} tt ON tr.term_taxonomy_id = tt.term_taxonomy_id
                     WHERE tt.taxonomy = %s))",
                    $taxonomy
                );
        }
        return '';
    }

    /**
     * Build SQL for word count
     */
    private function build_word_count_sql($operator, $value) {
        global $wpdb;
        // Approximate word count by dividing content length by average word length (5 chars + space)
        $word_count_expr = "(LENGTH({$wpdb->posts}.post_content) - LENGTH(REPLACE({$wpdb->posts}.post_content, ' ', '')) + 1)";
        $int_value = intval($value);

        switch ($operator) {
            case 'equals':
                return "{$word_count_expr} = {$int_value}";
            case 'not_equals':
                return "{$word_count_expr} != {$int_value}";
            case 'greater_than':
                return "{$word_count_expr} > {$int_value}";
            case 'less_than':
                return "{$word_count_expr} < {$int_value}";
            case 'greater_equal':
                return "{$word_count_expr} >= {$int_value}";
            case 'less_equal':
                return "{$word_count_expr} <= {$int_value}";
        }
        return '';
    }

    /**
     * Build SQL for article helpful
     */
    private function build_article_helpful_sql($operator, $value) {
        global $wpdb;
        // Article helpful is stored as meta with yes/no counts
        $meta_key = '_vt_article_helpful';
        $int_value = intval($value);

        switch ($operator) {
            case 'greater_than':
                return $wpdb->prepare(
                    "({$wpdb->posts}.ID IN (SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = %s AND CAST(meta_value AS SIGNED) > %d))",
                    $meta_key . '_yes', $int_value
                );
            case 'less_than':
                return $wpdb->prepare(
                    "({$wpdb->posts}.ID IN (SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = %s AND CAST(meta_value AS SIGNED) < %d))",
                    $meta_key . '_yes', $int_value
                );
            case 'equals':
                return $wpdb->prepare(
                    "({$wpdb->posts}.ID IN (SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = %s AND CAST(meta_value AS SIGNED) = %d))",
                    $meta_key . '_yes', $int_value
                );
        }
        return '';
    }

    /**
     * Build SQL for product field (price stored as JSON)
     */
    private function build_product_sql($meta_key, $operator, $value) {
        global $wpdb;
        // Product data is stored as JSON: {"base_price":{"amount":"100","currency":"USD"}}
        // Use MySQL JSON_EXTRACT to filter by base_price.amount
        $decimal_value = floatval($value);

        switch ($operator) {
            case 'equals':
                return $wpdb->prepare(
                    "({$wpdb->posts}.ID IN (SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = %s AND CAST(JSON_UNQUOTE(JSON_EXTRACT(meta_value, '$.base_price.amount')) AS DECIMAL(10,2)) = %f))",
                    $meta_key, $decimal_value
                );
            case 'not_equals':
                return $wpdb->prepare(
                    "({$wpdb->posts}.ID NOT IN (SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = %s AND CAST(JSON_UNQUOTE(JSON_EXTRACT(meta_value, '$.base_price.amount')) AS DECIMAL(10,2)) = %f))",
                    $meta_key, $decimal_value
                );
            case 'greater_than':
                return $wpdb->prepare(
                    "({$wpdb->posts}.ID IN (SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = %s AND CAST(JSON_UNQUOTE(JSON_EXTRACT(meta_value, '$.base_price.amount')) AS DECIMAL(10,2)) > %f))",
                    $meta_key, $decimal_value
                );
            case 'less_than':
                return $wpdb->prepare(
                    "({$wpdb->posts}.ID IN (SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = %s AND CAST(JSON_UNQUOTE(JSON_EXTRACT(meta_value, '$.base_price.amount')) AS DECIMAL(10,2)) < %f))",
                    $meta_key, $decimal_value
                );
            case 'greater_equal':
                return $wpdb->prepare(
                    "({$wpdb->posts}.ID IN (SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = %s AND CAST(JSON_UNQUOTE(JSON_EXTRACT(meta_value, '$.base_price.amount')) AS DECIMAL(10,2)) >= %f))",
                    $meta_key, $decimal_value
                );
            case 'less_equal':
                return $wpdb->prepare(
                    "({$wpdb->posts}.ID IN (SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = %s AND CAST(JSON_UNQUOTE(JSON_EXTRACT(meta_value, '$.base_price.amount')) AS DECIMAL(10,2)) <= %f))",
                    $meta_key, $decimal_value
                );
            case 'is_empty':
                return $wpdb->prepare(
                    "({$wpdb->posts}.ID NOT IN (SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = %s AND meta_value IS NOT NULL AND meta_value != ''))",
                    $meta_key
                );
            case 'is_not_empty':
                return $wpdb->prepare(
                    "({$wpdb->posts}.ID IN (SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = %s AND meta_value IS NOT NULL AND meta_value != ''))",
                    $meta_key
                );
        }
        return '';
    }

    /**
     * Build SQL for view counts field (stored as JSON in voxel:view_counts)
     */
    private function build_view_counts_sql($operator, $value) {
        global $wpdb;
        // View counts data is stored as JSON: {"views":{"all":123,"30d":45}}
        // Use MySQL JSON_EXTRACT to filter by views.all
        $meta_key = 'voxel:view_counts';
        $int_value = intval($value);

        switch ($operator) {
            case 'equals':
                return $wpdb->prepare(
                    "({$wpdb->posts}.ID IN (SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = %s AND CAST(JSON_UNQUOTE(JSON_EXTRACT(meta_value, '$.views.all')) AS SIGNED) = %d))",
                    $meta_key, $int_value
                );
            case 'not_equals':
                return $wpdb->prepare(
                    "({$wpdb->posts}.ID NOT IN (SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = %s AND CAST(JSON_UNQUOTE(JSON_EXTRACT(meta_value, '$.views.all')) AS SIGNED) = %d))",
                    $meta_key, $int_value
                );
            case 'greater_than':
                return $wpdb->prepare(
                    "({$wpdb->posts}.ID IN (SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = %s AND CAST(JSON_UNQUOTE(JSON_EXTRACT(meta_value, '$.views.all')) AS SIGNED) > %d))",
                    $meta_key, $int_value
                );
            case 'less_than':
                return $wpdb->prepare(
                    "({$wpdb->posts}.ID IN (SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = %s AND CAST(JSON_UNQUOTE(JSON_EXTRACT(meta_value, '$.views.all')) AS SIGNED) < %d))",
                    $meta_key, $int_value
                );
            case 'greater_equal':
                return $wpdb->prepare(
                    "({$wpdb->posts}.ID IN (SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = %s AND CAST(JSON_UNQUOTE(JSON_EXTRACT(meta_value, '$.views.all')) AS SIGNED) >= %d))",
                    $meta_key, $int_value
                );
            case 'less_equal':
                return $wpdb->prepare(
                    "({$wpdb->posts}.ID IN (SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = %s AND CAST(JSON_UNQUOTE(JSON_EXTRACT(meta_value, '$.views.all')) AS SIGNED) <= %d))",
                    $meta_key, $int_value
                );
            case 'is_empty':
                return $wpdb->prepare(
                    "({$wpdb->posts}.ID NOT IN (SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = %s AND meta_value IS NOT NULL AND meta_value != '' AND JSON_EXTRACT(meta_value, '$.views.all') IS NOT NULL))",
                    $meta_key
                );
            case 'is_not_empty':
                return $wpdb->prepare(
                    "({$wpdb->posts}.ID IN (SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = %s AND meta_value IS NOT NULL AND meta_value != '' AND JSON_EXTRACT(meta_value, '$.views.all') IS NOT NULL))",
                    $meta_key
                );
        }
        return '';
    }

    /**
     * Build SQL for review stats field (stored as JSON in voxel:review_stats)
     * Filters by total number of reviews
     */
    private function build_review_stats_sql($operator, $value) {
        global $wpdb;
        // Review stats data is stored as JSON: {"total":5,"average":1.5}
        // Filter by total number of reviews
        $meta_key = 'voxel:review_stats';
        $int_value = intval($value);

        switch ($operator) {
            case 'equals':
                return $wpdb->prepare(
                    "({$wpdb->posts}.ID IN (SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = %s AND CAST(JSON_UNQUOTE(JSON_EXTRACT(meta_value, '$.total')) AS SIGNED) = %d))",
                    $meta_key, $int_value
                );
            case 'not_equals':
                return $wpdb->prepare(
                    "({$wpdb->posts}.ID NOT IN (SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = %s AND CAST(JSON_UNQUOTE(JSON_EXTRACT(meta_value, '$.total')) AS SIGNED) = %d))",
                    $meta_key, $int_value
                );
            case 'greater_than':
                return $wpdb->prepare(
                    "({$wpdb->posts}.ID IN (SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = %s AND CAST(JSON_UNQUOTE(JSON_EXTRACT(meta_value, '$.total')) AS SIGNED) > %d))",
                    $meta_key, $int_value
                );
            case 'less_than':
                return $wpdb->prepare(
                    "({$wpdb->posts}.ID IN (SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = %s AND CAST(JSON_UNQUOTE(JSON_EXTRACT(meta_value, '$.total')) AS SIGNED) < %d))",
                    $meta_key, $int_value
                );
            case 'greater_equal':
                return $wpdb->prepare(
                    "({$wpdb->posts}.ID IN (SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = %s AND CAST(JSON_UNQUOTE(JSON_EXTRACT(meta_value, '$.total')) AS SIGNED) >= %d))",
                    $meta_key, $int_value
                );
            case 'less_equal':
                return $wpdb->prepare(
                    "({$wpdb->posts}.ID IN (SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = %s AND CAST(JSON_UNQUOTE(JSON_EXTRACT(meta_value, '$.total')) AS SIGNED) <= %d))",
                    $meta_key, $int_value
                );
            case 'is_empty':
                return $wpdb->prepare(
                    "({$wpdb->posts}.ID NOT IN (SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = %s AND meta_value IS NOT NULL AND meta_value != '' AND CAST(JSON_UNQUOTE(JSON_EXTRACT(meta_value, '$.total')) AS SIGNED) > 0))",
                    $meta_key
                );
            case 'is_not_empty':
                return $wpdb->prepare(
                    "({$wpdb->posts}.ID IN (SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = %s AND meta_value IS NOT NULL AND meta_value != '' AND CAST(JSON_UNQUOTE(JSON_EXTRACT(meta_value, '$.total')) AS SIGNED) > 0))",
                    $meta_key
                );
        }
        return '';
    }

    /**
     * Build SQL for image/file fields (check existence only)
     */
    private function build_media_exists_sql($meta_key, $operator) {
        global $wpdb;

        switch ($operator) {
            case 'is_empty':
            case 'equals':
                // Treat "equals" with no value as empty check
                return $wpdb->prepare(
                    "({$wpdb->posts}.ID NOT IN (SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = %s AND meta_value IS NOT NULL AND meta_value != '' AND meta_value != '[]'))",
                    $meta_key
                );
            case 'is_not_empty':
            case 'not_equals':
                return $wpdb->prepare(
                    "({$wpdb->posts}.ID IN (SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = %s AND meta_value IS NOT NULL AND meta_value != '' AND meta_value != '[]'))",
                    $meta_key
                );
        }
        return '';
    }

    /**
     * Build SQL for post-relation fields (array of post IDs stored as JSON)
     */
    private function build_post_relation_sql($meta_key, $operator, $value) {
        global $wpdb;

        switch ($operator) {
            case 'equals':
                // Check if the relation contains the specified post ID
                return $wpdb->prepare(
                    "({$wpdb->posts}.ID IN (SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = %s AND (meta_value LIKE %s OR meta_value LIKE %s OR meta_value LIKE %s)))",
                    $meta_key,
                    '[' . $value . ',%',  // First item
                    '%,' . $value . ',%', // Middle item
                    '%,' . $value . ']'   // Last item
                );
            case 'not_equals':
                return $wpdb->prepare(
                    "({$wpdb->posts}.ID NOT IN (SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = %s AND (meta_value LIKE %s OR meta_value LIKE %s OR meta_value LIKE %s)))",
                    $meta_key,
                    '[' . $value . ',%',
                    '%,' . $value . ',%',
                    '%,' . $value . ']'
                );
            case 'is_empty':
                return $wpdb->prepare(
                    "({$wpdb->posts}.ID NOT IN (SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = %s AND meta_value IS NOT NULL AND meta_value != '' AND meta_value != '[]'))",
                    $meta_key
                );
            case 'is_not_empty':
                return $wpdb->prepare(
                    "({$wpdb->posts}.ID IN (SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = %s AND meta_value IS NOT NULL AND meta_value != '' AND meta_value != '[]'))",
                    $meta_key
                );
        }
        return '';
    }

    /**
     * Build a single meta filter based on operator
     */
    private function build_single_meta_filter($meta_key, $operator, $value) {
        switch ($operator) {
            case 'equals':
                return array(
                    'key' => $meta_key,
                    'value' => $value,
                    'compare' => '=',
                );

            case 'not_equals':
                return array(
                    'key' => $meta_key,
                    'value' => $value,
                    'compare' => '!=',
                );

            case 'contains':
                return array(
                    'key' => $meta_key,
                    'value' => $value,
                    'compare' => 'LIKE',
                );

            case 'not_contains':
                return array(
                    'key' => $meta_key,
                    'value' => $value,
                    'compare' => 'NOT LIKE',
                );

            case 'starts_with':
                return array(
                    'key' => $meta_key,
                    'value' => $value . '%',
                    'compare' => 'LIKE',
                );

            case 'ends_with':
                return array(
                    'key' => $meta_key,
                    'value' => '%' . $value,
                    'compare' => 'LIKE',
                );

            case 'greater_than':
                return array(
                    'key' => $meta_key,
                    'value' => $value,
                    'compare' => '>',
                    'type' => is_numeric($value) ? 'NUMERIC' : 'CHAR',
                );

            case 'less_than':
                return array(
                    'key' => $meta_key,
                    'value' => $value,
                    'compare' => '<',
                    'type' => is_numeric($value) ? 'NUMERIC' : 'CHAR',
                );

            case 'greater_equal':
                return array(
                    'key' => $meta_key,
                    'value' => $value,
                    'compare' => '>=',
                    'type' => is_numeric($value) ? 'NUMERIC' : 'CHAR',
                );

            case 'less_equal':
                return array(
                    'key' => $meta_key,
                    'value' => $value,
                    'compare' => '<=',
                    'type' => is_numeric($value) ? 'NUMERIC' : 'CHAR',
                );

            case 'is_empty':
                return array(
                    'relation' => 'OR',
                    array(
                        'key' => $meta_key,
                        'compare' => 'NOT EXISTS',
                    ),
                    array(
                        'key' => $meta_key,
                        'value' => '',
                        'compare' => '=',
                    ),
                );

            case 'is_not_empty':
                return array(
                    'relation' => 'AND',
                    array(
                        'key' => $meta_key,
                        'compare' => 'EXISTS',
                    ),
                    array(
                        'key' => $meta_key,
                        'value' => '',
                        'compare' => '!=',
                    ),
                );

            default:
                return null;
        }
    }

    /**
     * Get taxonomy key from a taxonomy field by field key and post type
     */
    private function get_taxonomy_for_field($field_key, $post_type) {
        if (!class_exists('\Voxel\Post_Type')) {
            return null;
        }

        $voxel_post_type = \Voxel\Post_Type::get($post_type);
        if (!$voxel_post_type) {
            return null;
        }

        $field = $voxel_post_type->get_field($field_key);
        if (!$field) {
            return null;
        }

        if (method_exists($field, 'get_prop')) {
            return $field->get_prop('taxonomy');
        }

        return null;
    }

    /**
     * Get field type for a given field key
     */
    private function get_field_type($field_key, $post_type) {
        if (!class_exists('\Voxel\Post_Type')) {
            return 'text';
        }

        $voxel_post_type = \Voxel\Post_Type::get($post_type);
        if (!$voxel_post_type) {
            return 'text';
        }

        $field = $voxel_post_type->get_field($field_key);
        if (!$field) {
            return 'text';
        }

        return $field->get_type();
    }

    /**
     * AJAX: Get terms for a taxonomy (bulk edit)
     */
    public function ajax_bulk_get_terms() {
        check_ajax_referer('vt_admin_columns_bulk_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => __('Unauthorized', 'voxel-toolkit')));
        }

        $taxonomy = isset($_POST['taxonomy']) ? sanitize_text_field($_POST['taxonomy']) : '';
        $search = isset($_POST['search']) ? sanitize_text_field($_POST['search']) : '';

        if (empty($taxonomy) || !taxonomy_exists($taxonomy)) {
            wp_send_json_error(array('message' => __('Invalid taxonomy', 'voxel-toolkit')));
        }

        $args = array(
            'taxonomy' => $taxonomy,
            'hide_empty' => false,
            'number' => 100,
            'orderby' => 'name',
            'order' => 'ASC',
        );

        if (!empty($search)) {
            $args['search'] = $search;
        }

        $terms = get_terms($args);

        if (is_wp_error($terms)) {
            wp_send_json_error(array('message' => $terms->get_error_message()));
        }

        $result = array();
        foreach ($terms as $term) {
            $result[] = array(
                'term_id' => $term->term_id,
                'name' => $term->name,
                'slug' => $term->slug,
                'count' => $term->count,
                'parent' => $term->parent,
            );
        }

        wp_send_json_success($result);
    }

    /**
     * AJAX: Get posts for post-relation field bulk edit
     */
    public function ajax_bulk_get_posts() {
        check_ajax_referer('vt_admin_columns_bulk_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => __('Unauthorized', 'voxel-toolkit')));
        }

        $related_post_type = isset($_POST['related_post_type']) ? sanitize_text_field($_POST['related_post_type']) : '';
        $search = isset($_POST['search']) ? sanitize_text_field($_POST['search']) : '';

        if (empty($related_post_type) || !post_type_exists($related_post_type)) {
            wp_send_json_error(array('message' => __('Invalid post type', 'voxel-toolkit')));
        }

        $args = array(
            'post_type' => $related_post_type,
            'post_status' => 'publish',
            'posts_per_page' => 50,
            'orderby' => 'title',
            'order' => 'ASC',
        );

        if (!empty($search)) {
            $args['s'] = $search;
        }

        $posts = get_posts($args);

        $result = array();
        foreach ($posts as $post) {
            $result[] = array(
                'id' => $post->ID,
                'title' => $post->post_title,
            );
        }

        wp_send_json_success($result);
    }

    /**
     * AJAX: Apply bulk edit to posts
     */
    public function ajax_bulk_apply() {
        check_ajax_referer('vt_admin_columns_bulk_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => __('Unauthorized', 'voxel-toolkit')));
        }

        $post_ids = isset($_POST['post_ids']) ? array_map('intval', (array) $_POST['post_ids']) : array();
        $field_type = isset($_POST['field_type']) ? sanitize_text_field($_POST['field_type']) : '';
        $field_key = isset($_POST['field_key']) ? sanitize_text_field($_POST['field_key']) : '';
        $action = isset($_POST['bulk_action']) ? sanitize_text_field($_POST['bulk_action']) : '';
        $post_type = isset($_POST['post_type']) ? sanitize_text_field($_POST['post_type']) : '';
        $values = isset($_POST['values']) ? $_POST['values'] : array();

        // Legacy support for taxonomy-only calls
        $taxonomy = isset($_POST['taxonomy']) ? sanitize_text_field($_POST['taxonomy']) : '';
        $term_ids = isset($_POST['term_ids']) ? array_map('intval', (array) $_POST['term_ids']) : array();

        // Validate inputs
        if (empty($post_ids)) {
            wp_send_json_error(array('message' => __('No posts selected', 'voxel-toolkit')));
        }

        // Determine field type (backward compatibility)
        if (empty($field_type) && !empty($taxonomy)) {
            $field_type = 'taxonomy';
        }

        if (empty($field_type)) {
            wp_send_json_error(array('message' => __('Invalid field type', 'voxel-toolkit')));
        }

        $processed = 0;
        $errors = array();

        foreach ($post_ids as $post_id) {
            // Verify post exists and is the correct post type
            $post = get_post($post_id);
            if (!$post) {
                $errors[] = sprintf(__('Post %d not found', 'voxel-toolkit'), $post_id);
                continue;
            }

            if (!empty($post_type) && $post->post_type !== $post_type) {
                $errors[] = sprintf(__('Post %d is not of type %s', 'voxel-toolkit'), $post_id, $post_type);
                continue;
            }

            $update_success = false;

            switch ($field_type) {
                case 'taxonomy':
                    // Use legacy term_ids if values is empty
                    $term_values = !empty($values) ? array_map('intval', (array) $values) : $term_ids;
                    $tax = !empty($taxonomy) ? $taxonomy : (isset($_POST['taxonomy']) ? sanitize_text_field($_POST['taxonomy']) : '');

                    if (empty($tax) || !taxonomy_exists($tax)) {
                        $errors[] = sprintf(__('Invalid taxonomy for post %d', 'voxel-toolkit'), $post_id);
                        continue 2;
                    }

                    switch ($action) {
                        case 'add':
                            $result = wp_set_object_terms($post_id, $term_values, $tax, true);
                            break;
                        case 'replace':
                            $result = wp_set_object_terms($post_id, $term_values, $tax, false);
                            break;
                        case 'remove':
                            if (!empty($term_values)) {
                                $current_terms = wp_get_object_terms($post_id, $tax, array('fields' => 'ids'));
                                if (!is_wp_error($current_terms)) {
                                    $new_terms = array_diff($current_terms, $term_values);
                                    $result = wp_set_object_terms($post_id, $new_terms, $tax, false);
                                }
                            } else {
                                $result = wp_set_object_terms($post_id, array(), $tax, false);
                            }
                            break;
                    }
                    $update_success = !is_wp_error($result);
                    break;

                case 'post-relation':
                    $related_ids = array_map('intval', (array) $values);
                    $meta_key = $field_key;

                    $current_value = get_post_meta($post_id, $meta_key, true);
                    $current_ids = !empty($current_value) ? array_map('intval', (array) $current_value) : array();

                    switch ($action) {
                        case 'add':
                            $new_ids = array_unique(array_merge($current_ids, $related_ids));
                            break;
                        case 'replace':
                            $new_ids = $related_ids;
                            break;
                        case 'remove':
                            $new_ids = array_diff($current_ids, $related_ids);
                            break;
                    }

                    $update_success = update_post_meta($post_id, $meta_key, $new_ids);
                    break;

                case 'multiselect':
                    $selected_values = (array) $values;
                    $meta_key = $field_key;

                    $current_value = get_post_meta($post_id, $meta_key, true);
                    $current_values = !empty($current_value) ? (array) $current_value : array();

                    switch ($action) {
                        case 'add':
                            $new_values = array_unique(array_merge($current_values, $selected_values));
                            break;
                        case 'replace':
                            $new_values = $selected_values;
                            break;
                        case 'remove':
                            $new_values = array_diff($current_values, $selected_values);
                            break;
                    }

                    $update_success = update_post_meta($post_id, $meta_key, array_values($new_values));
                    break;

                case 'select':
                    $meta_key = $field_key;
                    $value = is_array($values) ? reset($values) : sanitize_text_field($values);
                    $update_success = update_post_meta($post_id, $meta_key, $value);
                    break;

                case 'switcher':
                    $meta_key = $field_key;
                    $value = is_array($values) ? reset($values) : $values;
                    // Convert to boolean-like value
                    $bool_value = ($value === 'true' || $value === '1' || $value === 1) ? 1 : 0;
                    $update_success = update_post_meta($post_id, $meta_key, $bool_value);
                    break;

                case 'text':
                    $meta_key = $field_key;
                    $value = is_array($values) ? reset($values) : sanitize_text_field($values);
                    $update_success = update_post_meta($post_id, $meta_key, $value);
                    break;

                case 'number':
                    $meta_key = $field_key;
                    $value = is_array($values) ? reset($values) : $values;
                    $numeric_value = is_numeric($value) ? floatval($value) : 0;
                    $update_success = update_post_meta($post_id, $meta_key, $numeric_value);
                    break;

                case 'textarea':
                case 'texteditor':
                    $meta_key = $field_key;
                    $value = is_array($values) ? reset($values) : $values;
                    // Allow HTML but sanitize it
                    $update_success = update_post_meta($post_id, $meta_key, wp_kses_post($value));
                    break;

                case 'email':
                    $meta_key = $field_key;
                    $value = is_array($values) ? reset($values) : $values;
                    $email_value = sanitize_email($value);
                    $update_success = update_post_meta($post_id, $meta_key, $email_value);
                    break;

                case 'phone':
                    $meta_key = $field_key;
                    $value = is_array($values) ? reset($values) : $values;
                    // Sanitize phone - allow numbers, spaces, dashes, parentheses, plus
                    $phone_value = preg_replace('/[^0-9\s\-\(\)\+]/', '', $value);
                    $update_success = update_post_meta($post_id, $meta_key, $phone_value);
                    break;

                case 'url':
                    $meta_key = $field_key;
                    $value = is_array($values) ? reset($values) : $values;
                    $url_value = esc_url_raw($value);
                    $update_success = update_post_meta($post_id, $meta_key, $url_value);
                    break;

                case 'date':
                    $meta_key = $field_key;
                    $value = is_array($values) ? reset($values) : sanitize_text_field($values);
                    $update_success = update_post_meta($post_id, $meta_key, $value);
                    break;

                default:
                    $errors[] = sprintf(__('Unsupported field type: %s', 'voxel-toolkit'), $field_type);
                    continue 2;
            }

            if ($update_success !== false) {
                $processed++;
            } else {
                $errors[] = sprintf(__('Failed to update post %d', 'voxel-toolkit'), $post_id);
            }
        }

        wp_send_json_success(array(
            'processed' => $processed,
            'total' => count($post_ids),
            'errors' => $errors,
        ));
    }
}
