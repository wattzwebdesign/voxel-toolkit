<?php
/**
 * Plugin Name: Voxel Toolkit
 * Plugin URI: https://codewattz.com/voxel-toolkit-plugin/
 * Description: A comprehensive toolkit for extending Voxel theme functionality with toggleable features and customizable settings.
 * Version: 1.6.1.2
 * Author: Code Wattz
 * Author URI: https://codewattz.com
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: voxel-toolkit
 * Domain Path: /languages
 * Requires at least: 5.0
 * Tested up to: 6.8.2
 * Requires PHP: 8.1
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
if (!defined('VOXEL_TOOLKIT_VERSION')) {
    define('VOXEL_TOOLKIT_VERSION', '1.6.1.2');
}
if (!defined('VOXEL_TOOLKIT_PLUGIN_DIR')) {
    define('VOXEL_TOOLKIT_PLUGIN_DIR', plugin_dir_path(__FILE__));
}
if (!defined('VOXEL_TOOLKIT_PLUGIN_URL')) {
    define('VOXEL_TOOLKIT_PLUGIN_URL', plugin_dir_url(__FILE__));
}
if (!defined('VOXEL_TOOLKIT_URL')) {
    define('VOXEL_TOOLKIT_URL', plugin_dir_url(__FILE__));
}
if (!defined('VOXEL_TOOLKIT_PLUGIN_FILE')) {
    define('VOXEL_TOOLKIT_PLUGIN_FILE', __FILE__);
}

/**
 * Load Order By Manager early (before theme config loads)
 * This must be loaded at the top level to register filters before Voxel theme config is processed
 */
if (file_exists(VOXEL_TOOLKIT_PLUGIN_DIR . 'includes/order-by/class-order-by-manager.php')) {
    require_once VOXEL_TOOLKIT_PLUGIN_DIR . 'includes/order-by/class-order-by-manager.php';
}

/**
 * Load Filter Manager early (before theme config loads)
 * This must be loaded at the top level to register filters before Voxel theme config is processed
 */
if (file_exists(VOXEL_TOOLKIT_PLUGIN_DIR . 'includes/filters/class-filter-manager.php')) {
    require_once VOXEL_TOOLKIT_PLUGIN_DIR . 'includes/filters/class-filter-manager.php';
}

/**
 * Main Voxel Toolkit Class
 */
if (!class_exists('Voxel_Toolkit')) {
class Voxel_Toolkit {
    
    private static $instance = null;
    
    /**
     * Get singleton instance
     */
    public static function instance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Constructor
     */
    private function __construct() {
        add_action('init', array($this, 'init'));
        add_action('plugins_loaded', array($this, 'load_textdomain'));
        add_action('plugins_loaded', array($this, 'early_init'), 5);

        // Plugin activation/deactivation hooks
        register_activation_hook(__FILE__, array($this, 'activate'));
        register_deactivation_hook(__FILE__, array($this, 'deactivate'));
    }
    
    /**
     * Early initialization for post fields (must run before Voxel config loads)
     */
    public function early_init() {
        // Handle temporary login URL early (before any auth checks)
        $this->handle_temp_login_early();

        // Register poll field type filter early (before Voxel calls it)
        add_filter('voxel/field-types', array($this, 'register_poll_field_if_enabled'), 10);

        // Register auto-reply field type filter early (before Voxel calls it)
        add_filter('voxel/field-types', array($this, 'register_auto_reply_field_if_enabled'), 10);

        // Register team members field type filter early (before Voxel calls it)
        add_filter('voxel/field-types', array($this, 'register_team_members_field_if_enabled'), 10);

        // Register advanced phone field type filter (replaces native phone field)
        add_filter('voxel/field-types', array($this, 'register_advanced_phone_field_if_enabled'), 15);

        // Register extended taxonomy field type filter (adds Add Category functionality)
        add_filter('voxel/field-types', array($this, 'register_extended_taxonomy_field_if_enabled'), 15);

        // Register checklist field type filter early (before Voxel calls it)
        add_filter('voxel/field-types', array($this, 'register_checklist_field_if_enabled'), 10);

        // Register saved search app events filter early (before Voxel caches events)
        add_filter('voxel/app-events/register', array($this, 'register_saved_search_events_if_enabled'), 99);

        // Register add category app events filter early (before Voxel caches events)
        add_filter('voxel/app-events/register', array($this, 'register_add_category_events_if_enabled'), 99);

        // Hook into Voxel's event save to also save SMS settings
        add_action('voxel_ajax_app_events.save_config', array($this, 'save_sms_event_settings'), 5);

        // Load the actual field class later when Voxel classes are available
        add_action('after_setup_theme', array($this, 'init_post_fields'), 10);
    }

    /**
     * Register poll field type if enabled (called early via filter)
     */
    public function register_poll_field_if_enabled($fields) {
        // Load settings class if not loaded
        if (!class_exists('Voxel_Toolkit_Settings')) {
            if (file_exists(VOXEL_TOOLKIT_PLUGIN_DIR . 'includes/class-settings.php')) {
                require_once VOXEL_TOOLKIT_PLUGIN_DIR . 'includes/class-settings.php';
            } else {
                return $fields;
            }
        }

        $settings = Voxel_Toolkit_Settings::instance();
        if (!$settings->is_function_enabled('post_field_poll_field')) {
            return $fields;
        }

        // Check if the field type class will be available
        if (!class_exists('\Voxel\Post_Types\Fields\Base_Post_Field')) {
            return $fields;
        }

        $fields['poll-vt'] = '\Voxel_Toolkit_Poll_Field_Type';
        return $fields;
    }

    /**
     * Register auto-reply field type if enabled (called early via filter)
     */
    public function register_auto_reply_field_if_enabled($fields) {
        // Load settings class if not loaded
        if (!class_exists('Voxel_Toolkit_Settings')) {
            if (file_exists(VOXEL_TOOLKIT_PLUGIN_DIR . 'includes/class-settings.php')) {
                require_once VOXEL_TOOLKIT_PLUGIN_DIR . 'includes/class-settings.php';
            } else {
                return $fields;
            }
        }

        $settings = Voxel_Toolkit_Settings::instance();
        if (!$settings->is_function_enabled('post_field_auto_reply_field')) {
            return $fields;
        }

        // Check if the field type class will be available
        if (!class_exists('\Voxel\Post_Types\Fields\Base_Post_Field')) {
            return $fields;
        }

        // Load the field file to ensure the class is available
        $field_file = VOXEL_TOOLKIT_PLUGIN_DIR . 'includes/post-fields/class-auto-reply-field.php';
        if (file_exists($field_file) && !class_exists('Voxel_Toolkit_Auto_Reply_Field_Type')) {
            require_once $field_file;
        }

        $fields['auto-reply-vt'] = '\Voxel_Toolkit_Auto_Reply_Field_Type';
        return $fields;
    }

    /**
     * Register team members field type if enabled (called early via filter)
     */
    public function register_team_members_field_if_enabled($fields) {
        // Load settings class if not loaded
        if (!class_exists('Voxel_Toolkit_Settings')) {
            if (file_exists(VOXEL_TOOLKIT_PLUGIN_DIR . 'includes/class-settings.php')) {
                require_once VOXEL_TOOLKIT_PLUGIN_DIR . 'includes/class-settings.php';
            } else {
                return $fields;
            }
        }

        $settings = Voxel_Toolkit_Settings::instance();
        // Check if Team Members function is enabled
        if (!$settings->is_function_enabled('team_members')) {
            return $fields;
        }

        // Check if the field type class will be available
        if (!class_exists('\Voxel\Post_Types\Fields\Base_Post_Field')) {
            return $fields;
        }

        // Load the field file to ensure the class is available
        $field_file = VOXEL_TOOLKIT_PLUGIN_DIR . 'includes/functions/class-team-members.php';
        if (file_exists($field_file) && !class_exists('Voxel_Toolkit_Team_Members_Field_Type')) {
            require_once $field_file;
        }

        $fields['team-members-vt'] = '\Voxel_Toolkit_Team_Members_Field_Type';
        return $fields;
    }

    /**
     * Register advanced phone field type if enabled (replaces native phone field)
     */
    public function register_advanced_phone_field_if_enabled($fields) {
        // Load settings class if not loaded
        if (!class_exists('Voxel_Toolkit_Settings')) {
            if (file_exists(VOXEL_TOOLKIT_PLUGIN_DIR . 'includes/class-settings.php')) {
                require_once VOXEL_TOOLKIT_PLUGIN_DIR . 'includes/class-settings.php';
            } else {
                return $fields;
            }
        }

        $settings = Voxel_Toolkit_Settings::instance();
        if (!$settings->is_function_enabled('advanced_phone_input')) {
            return $fields;
        }

        // Check if Voxel's Phone_Field class exists (we extend it)
        if (!class_exists('\Voxel\Post_Types\Fields\Phone_Field')) {
            return $fields;
        }

        // Load the field file to ensure the class is available
        $field_file = VOXEL_TOOLKIT_PLUGIN_DIR . 'includes/functions/class-advanced-phone-input.php';
        if (file_exists($field_file) && !class_exists('Voxel_Toolkit_Extended_Phone_Field')) {
            require_once $field_file;
        }

        // Replace native phone field with our extended version
        $fields['phone'] = '\Voxel_Toolkit_Extended_Phone_Field';
        return $fields;
    }

    /**
     * Register extended taxonomy field type if enabled (adds Add Category functionality)
     */
    public function register_extended_taxonomy_field_if_enabled($fields) {
        // Load settings class if not loaded
        if (!class_exists('Voxel_Toolkit_Settings')) {
            if (file_exists(VOXEL_TOOLKIT_PLUGIN_DIR . 'includes/class-settings.php')) {
                require_once VOXEL_TOOLKIT_PLUGIN_DIR . 'includes/class-settings.php';
            } else {
                return $fields;
            }
        }

        $settings = Voxel_Toolkit_Settings::instance();
        if (!$settings->is_function_enabled('add_category')) {
            return $fields;
        }

        // Check if Voxel's Taxonomy_Field class exists (we extend it)
        if (!class_exists('\Voxel\Post_Types\Fields\Taxonomy_Field')) {
            return $fields;
        }

        // Load the field file to ensure the class is available
        $field_file = VOXEL_TOOLKIT_PLUGIN_DIR . 'includes/functions/class-add-category.php';
        if (file_exists($field_file) && !class_exists('Voxel_Toolkit_Extended_Taxonomy_Field')) {
            require_once $field_file;
        }

        // Replace native taxonomy field with our extended version
        $fields['taxonomy'] = '\Voxel_Toolkit_Extended_Taxonomy_Field';
        return $fields;
    }

    /**
     * Register checklist field type if enabled (called early via filter)
     */
    public function register_checklist_field_if_enabled($fields) {
        // Load settings class if not loaded
        if (!class_exists('Voxel_Toolkit_Settings')) {
            if (file_exists(VOXEL_TOOLKIT_PLUGIN_DIR . 'includes/class-settings.php')) {
                require_once VOXEL_TOOLKIT_PLUGIN_DIR . 'includes/class-settings.php';
            } else {
                return $fields;
            }
        }

        $settings = Voxel_Toolkit_Settings::instance();
        if (!$settings->is_function_enabled('post_field_checklist_field')) {
            return $fields;
        }

        // Check if the field type class will be available
        if (!class_exists('\Voxel\Post_Types\Fields\Base_Post_Field')) {
            return $fields;
        }

        // Load the field file to ensure the class is available
        $field_file = VOXEL_TOOLKIT_PLUGIN_DIR . 'includes/post-fields/class-checklist-field.php';
        if (file_exists($field_file) && !class_exists('Voxel_Toolkit_Checklist_Field_Type')) {
            require_once $field_file;
        }

        $fields['checklist-vt'] = '\Voxel_Toolkit_Checklist_Field_Type';
        return $fields;
    }

    /**
     * Register saved search app events if enabled (called early via filter)
     * This must run before Voxel caches events in Base_Event::get_all()
     */
    public function register_saved_search_events_if_enabled($events) {
        // Load settings class if not loaded
        if (!class_exists('Voxel_Toolkit_Settings')) {
            if (file_exists(VOXEL_TOOLKIT_PLUGIN_DIR . 'includes/class-settings.php')) {
                require_once VOXEL_TOOLKIT_PLUGIN_DIR . 'includes/class-settings.php';
            } else {
                return $events;
            }
        }

        $settings = Voxel_Toolkit_Settings::instance();
        if (!$settings->is_function_enabled('saved_search')) {
            return $events;
        }

        // Check if Voxel Post_Type class exists
        if (!class_exists('\Voxel\Post_Type')) {
            return $events;
        }

        // Load the saved search event class
        $event_file = VOXEL_TOOLKIT_PLUGIN_DIR . 'includes/functions/saved-search/class-saved-search-event.php';
        if (file_exists($event_file) && !class_exists('Voxel_Toolkit_Saved_Search_Event')) {
            require_once $event_file;
        }

        if (!class_exists('Voxel_Toolkit_Saved_Search_Event')) {
            return $events;
        }

        // Register saved search events for each post type
        foreach (\Voxel\Post_Type::get_voxel_types() as $post_type) {
            $event = new Voxel_Toolkit_Saved_Search_Event($post_type);
            $events[$event->get_key()] = $event;
        }

        return $events;
    }

    /**
     * Register add category app events if enabled (called early via filter)
     * This must run before Voxel caches events in Base_Event::get_all()
     */
    public function register_add_category_events_if_enabled($events) {
        // Load settings class if not loaded
        if (!class_exists('Voxel_Toolkit_Settings')) {
            if (file_exists(VOXEL_TOOLKIT_PLUGIN_DIR . 'includes/class-settings.php')) {
                require_once VOXEL_TOOLKIT_PLUGIN_DIR . 'includes/class-settings.php';
            } else {
                return $events;
            }
        }

        $settings = Voxel_Toolkit_Settings::instance();
        if (!$settings->is_function_enabled('add_category')) {
            return $events;
        }

        // Check if Voxel Base_Event class exists
        if (!class_exists('\Voxel\Events\Base_Event')) {
            return $events;
        }

        // Load the Add Category file (contains event classes)
        $file = VOXEL_TOOLKIT_PLUGIN_DIR . 'includes/functions/class-add-category.php';
        if (file_exists($file) && !class_exists('Voxel_Toolkit_Term_Added_Event')) {
            require_once $file;
        }

        // Register the three events
        if (class_exists('Voxel_Toolkit_Term_Added_Event')) {
            $events['voxel_toolkit/term:added'] = new \Voxel_Toolkit_Term_Added_Event();
        }
        if (class_exists('Voxel_Toolkit_Term_Pending_Event')) {
            $events['voxel_toolkit/term:pending'] = new \Voxel_Toolkit_Term_Pending_Event();
        }
        if (class_exists('Voxel_Toolkit_Term_Approved_Event')) {
            $events['voxel_toolkit/term:approved'] = new \Voxel_Toolkit_Term_Approved_Event();
        }

        return $events;
    }

    /**
     * Save SMS event settings when Voxel saves app events config
     * This runs before Voxel's save handler to capture and save SMS data
     */
    public function save_sms_event_settings() {
        if (!current_user_can('manage_options')) {
            return;
        }

        if (!function_exists('\Voxel\get') || !function_exists('\Voxel\set')) {
            return;
        }

        $config = json_decode(stripslashes($_POST['config'] ?? ''), true);
        if (!is_array($config)) {
            return;
        }

        // Get current Voxel events config
        $voxel_events = \Voxel\get('events', []);

        // Process each event's SMS settings
        foreach ($config as $event_key => $event_config) {
            if (!isset($event_config['notifications']) || !is_array($event_config['notifications'])) {
                continue;
            }

            foreach ($event_config['notifications'] as $destination => $notification) {
                if (!isset($notification['sms'])) {
                    continue;
                }

                // Ensure the event structure exists
                if (!isset($voxel_events[$event_key])) {
                    $voxel_events[$event_key] = ['notifications' => []];
                }
                if (!isset($voxel_events[$event_key]['notifications'])) {
                    $voxel_events[$event_key]['notifications'] = [];
                }
                if (!isset($voxel_events[$event_key]['notifications'][$destination])) {
                    $voxel_events[$event_key]['notifications'][$destination] = [];
                }

                // Save SMS settings
                $voxel_events[$event_key]['notifications'][$destination]['sms'] = [
                    'enabled' => !empty($notification['sms']['enabled']),
                    'message' => sanitize_textarea_field($notification['sms']['message'] ?? ''),
                ];
            }
        }

        // Save the updated config with SMS data
        \Voxel\set('events', $voxel_events, false);
    }

    /**
     * Initialize post fields early (load the actual classes)
     */
    public function init_post_fields() {
        if (file_exists(VOXEL_TOOLKIT_PLUGIN_DIR . 'includes/class-settings.php')) {
            require_once VOXEL_TOOLKIT_PLUGIN_DIR . 'includes/class-settings.php';
        }
        if (file_exists(VOXEL_TOOLKIT_PLUGIN_DIR . 'includes/class-post-fields.php')) {
            require_once VOXEL_TOOLKIT_PLUGIN_DIR . 'includes/class-post-fields.php';

            // Initialize post fields manager
            if (class_exists('Voxel_Toolkit_Post_Fields')) {
                Voxel_Toolkit_Post_Fields::instance();
            }
        }
    }

    /**
     * Initialize plugin
     */
    public function init() {
        // Delay theme check until after themes are loaded
        if (did_action('after_setup_theme')) {
            $this->check_theme_and_init();
        } else {
            add_action('after_setup_theme', array($this, 'check_theme_and_init'), 20);
        }
    }
    
    /**
     * Check theme and initialize if valid
     */
    public function check_theme_and_init() {
        // Check if Voxel theme is active
        if (!$this->is_voxel_theme_active()) {
            add_action('admin_notices', array($this, 'voxel_theme_required_notice'));
            return;
        }
        
        // Initialize licensing system
        $this->init_licensing();
        
        // Load plugin components
        $this->load_includes();
        $this->init_hooks();

        // Run migrations
        $this->maybe_migrate_ai_settings();

        // Clear Elementor cache if needed
        $this->maybe_clear_elementor_cache();
        
        // Initialize admin if in admin area
        if (is_admin()) {
            $this->init_admin();
            $this->init_license_notices();
            $this->init_deactivation_warning();
        }
    }
    
    /**
     * Load plugin text domain
     */
    public function load_textdomain() {
        load_plugin_textdomain('voxel-toolkit', false, dirname(plugin_basename(__FILE__)) . '/languages');
    }
    
    /**
     * Check if Voxel theme is active
     */
    private function is_voxel_theme_active() {
        // Make sure we can safely call wp_get_theme()
        if (!function_exists('wp_get_theme')) {
            return false;
        }
        
        $theme = wp_get_theme();
        
        // Check both theme name and template for child theme compatibility
        $theme_name = $theme->get('Name');
        $template = $theme->get_template();
        $stylesheet = $theme->get_stylesheet();
        
        return (
            $theme_name === 'Voxel' || 
            $template === 'voxel' || 
            $stylesheet === 'voxel' ||
            strpos(strtolower($theme_name), 'voxel') !== false
        );
    }
    
    /**
     * Show notice if Voxel theme is not active
     */
    public function voxel_theme_required_notice() {
        echo '<div class="notice notice-error"><p>';
        echo __('Voxel Toolkit requires the Voxel theme to be active.', 'voxel-toolkit');
        echo '</p></div>';
    }
    
    /**
     * Load includes
     */
    private function load_includes() {
        $files = array(
            'includes/class-settings.php',
            'includes/class-functions.php',
            'includes/class-post-fields.php',
            'includes/functions/class-field-formatters.php',
            'includes/functions/class-auto-verify-posts.php',
            'includes/functions/class-admin-menu-hide.php',
            'includes/functions/class-admin-notifications.php',
            'includes/functions/class-featured-posts.php',
            'includes/functions/class-sms-notifications.php', // Loads AJAX handlers early
            'includes/functions/class-field-columns.php', // Field column picker (always on)
            'includes/functions/class-plugin-stats.php', // Anonymous usage stats (opt-out available)
            'includes/dynamic-tags/class-dynamic-tags.php'
            // Note: order-by-manager is loaded at top level before theme config
        );

        if (is_admin()) {
            $files[] = 'includes/admin/class-admin.php';
            $files[] = 'includes/admin/messenger-settings.php';
        }

        foreach ($files as $file) {
            $file_path = VOXEL_TOOLKIT_PLUGIN_DIR . $file;
            if (file_exists($file_path)) {
                require_once $file_path;
            } else {
                error_log("Voxel Toolkit: Required file missing - {$file}");
            }
        }
    }
    
    /**
     * Initialize hooks
     */
    private function init_hooks() {
        try {
            // Initialize settings (already loaded in early_init)
            if (class_exists('Voxel_Toolkit_Settings')) {
                Voxel_Toolkit_Settings::instance();
            }

            // Initialize functions manager
            if (class_exists('Voxel_Toolkit_Functions')) {
                Voxel_Toolkit_Functions::instance();
            }

            // Post fields manager already initialized in early_init

            // Initialize dynamic tags
            if (class_exists('Voxel_Toolkit_Dynamic_Tags')) {
                new Voxel_Toolkit_Dynamic_Tags();
            }

            // Always initialize Profile Progress Widget for dynamic tag support
            if (class_exists('Voxel_Toolkit_Profile_Progress_Widget')) {
                new Voxel_Toolkit_Profile_Progress_Widget();
            }

            // Initialize Field Columns (always on - adds column picker to post field settings)
            if (class_exists('Voxel_Toolkit_Field_Columns')) {
                new Voxel_Toolkit_Field_Columns();
            }

            // Initialize Plugin Stats (anonymous usage stats - opt-out available)
            if (class_exists('Voxel_Toolkit_Plugin_Stats')) {
                Voxel_Toolkit_Plugin_Stats::instance();
            }

            // Add hook to refresh Elementor widget cache on init
            add_action('elementor/init', array($this, 'force_elementor_widget_refresh'));

        } catch (Exception $e) {
            error_log('Voxel Toolkit: Error initializing hooks - ' . $e->getMessage());
        }
    }
    
    /**
     * Initialize licensing system
     */
    private function init_licensing() {
        try {
            if (!class_exists('\VoxelToolkit\FluentLicensing')) {
                require_once VOXEL_TOOLKIT_PLUGIN_DIR . 'updater/FluentLicensing.php';
            }
            
            $licensing = new \VoxelToolkit\FluentLicensing();
            
            $licensing->register([
                'version'     => VOXEL_TOOLKIT_VERSION,
                'item_id'     => '179',
                'basename'    => plugin_basename(VOXEL_TOOLKIT_PLUGIN_FILE),
                'api_url'     => 'https://codewattz.com/'
            ]);
            
            // Initialize license settings page
            if (!class_exists('\VoxelToolkit\LicenseSettings')) {
                require_once VOXEL_TOOLKIT_PLUGIN_DIR . 'updater/LicenseSettings.php';
            }
            
            $licenseSettings = new \VoxelToolkit\LicenseSettings();
            $licenseSettings->register($licensing)
                ->setConfig([
                    'menu_title'      => __('License', 'voxel-toolkit'),
                    'title'           => __('Voxel Toolkit License', 'voxel-toolkit'),
                    'license_key'     => __('License Key', 'voxel-toolkit'),
                    'purchase_url'    => 'https://codewattz.com/?fluent-cart=instant_checkout&item_id=10&quantity=1',
                    'account_url'     => 'https://codewattz.com/account/',
                    'plugin_name'     => __('Voxel Toolkit', 'voxel-toolkit'),
                ]);
            
            // Add license page as submenu under Voxel Toolkit
            $licenseSettings->addPage([
                'type' => 'submenu',
                'parent_slug' => 'voxel-toolkit'
            ]);
            
        } catch (Exception $e) {
            error_log('Voxel Toolkit: Error initializing licensing - ' . $e->getMessage());
        }
    }
    
    /**
     * Initialize admin
     */
    private function init_admin() {
        try {
            if (class_exists('Voxel_Toolkit_Admin')) {
                Voxel_Toolkit_Admin::instance();
            }
        } catch (Exception $e) {
            error_log('Voxel Toolkit: Error initializing admin - ' . $e->getMessage());
        }
    }
    
    /**
     * Initialize license notices
     */
    private function init_license_notices() {
        add_action('admin_notices', array($this, 'license_admin_notice'));
    }
    
    /**
     * Initialize deactivation warning
     */
    private function init_deactivation_warning() {
        add_action('admin_footer', array($this, 'add_deactivation_warning_script'));
    }
    
    /**
     * Display license activation notice
     */
    public function license_admin_notice() {
        // Only show to administrators
        if (!current_user_can('manage_options')) {
            return;
        }

        try {
            // Get license instance
            $licensing = \VoxelToolkit\FluentLicensing::getInstance();
            if (!$licensing) {
                return;
            }

            // Don't show on license page itself
            $licenseSlug = $licensing->getConfig('slug');
            if (isset($_GET['page']) && $_GET['page'] === $licenseSlug . '-manage-license') {
                return;
            }

            // Check cached license status to avoid repeated checks
            $cache_key = 'voxel_toolkit_license_notice_status';
            $status = get_transient($cache_key);

            if (false === $status) {
                // Cache miss - get fresh status
                $status = $licensing->getStatus();
                // Cache for 6 hours
                set_transient($cache_key, $status, 6 * HOUR_IN_SECONDS);
            }
            
            // Only show notice if license is not valid
            if (!is_wp_error($status) && isset($status['status']) && $status['status'] === 'valid') {
                return; // License is valid, don't show notice
            }
            
            // Get current license key
            $currentKey = $licensing->getCurrentLicenseKey();
            
            // Get the correct license page URL dynamically
            $licenseSlug = $licensing->getConfig('slug');
            $licensePageUrl = admin_url('admin.php?page=' . $licenseSlug . '-manage-license');
            $purchaseUrl = 'https://codewattz.com/?fluent-cart=instant_checkout&item_id=10&quantity=1';
            
            ?>
            <div class="notice notice-warning is-dismissible" style="border-left-color: #2271b1;">
                <div style="display: flex; align-items: center; padding: 5px 0;">
                    <div style="margin-right: 10px;">
                        <span class="dashicons dashicons-admin-tools" style="font-size: 20px; color: #2271b1;"></span>
                    </div>
                    <div style="flex-grow: 1;">
                        <p style="margin: 0; font-weight: 600;">
                            <?php _e('Voxel Toolkit License Required', 'voxel-toolkit'); ?>
                        </p>
                        <p style="margin: 5px 0 0 0;">
                            <?php if (empty($currentKey)): ?>
                                <?php _e('Please activate your license to receive updates and support for Voxel Toolkit.', 'voxel-toolkit'); ?>
                            <?php else: ?>
                                <?php _e('Your license key appears to be invalid or expired. Please check your license status.', 'voxel-toolkit'); ?>
                            <?php endif; ?>
                        </p>
                        <p style="margin: 5px 0 0 0;">
                            <a href="<?php echo esc_url($licensePageUrl); ?>" class="button button-primary" style="margin-right: 10px;">
                                <?php _e('Activate License', 'voxel-toolkit'); ?>
                            </a>
                            <a href="<?php echo esc_url($purchaseUrl); ?>" class="button button-secondary" target="_blank">
                                <?php _e('Purchase License', 'voxel-toolkit'); ?>
                            </a>
                        </p>
                    </div>
                </div>
            </div>
            <?php
            
        } catch (Exception $e) {
            // Silently fail if there's an error checking license status
            error_log('Voxel Toolkit: Error checking license status for admin notice - ' . $e->getMessage());
        }
    }
    
    /**
     * Handle temporary login URL early (before normal WordPress auth)
     * This runs on plugins_loaded to catch login URLs before redirects happen
     */
    public function handle_temp_login_early() {
        // Check if this is a temp login request
        if (!isset($_GET['vt_temp_login']) || empty($_GET['vt_temp_login'])) {
            return;
        }

        // Don't process if already logged in
        if (is_user_logged_in()) {
            return;
        }

        // Load settings to check if function is enabled
        if (!class_exists('Voxel_Toolkit_Settings')) {
            if (file_exists(VOXEL_TOOLKIT_PLUGIN_DIR . 'includes/class-settings.php')) {
                require_once VOXEL_TOOLKIT_PLUGIN_DIR . 'includes/class-settings.php';
            } else {
                return;
            }
        }

        $settings = Voxel_Toolkit_Settings::instance();
        if (!$settings->is_function_enabled('temporary_login')) {
            return;
        }

        // Load and initialize the temporary login class
        if (file_exists(VOXEL_TOOLKIT_PLUGIN_DIR . 'includes/functions/class-temporary-login.php')) {
            require_once VOXEL_TOOLKIT_PLUGIN_DIR . 'includes/functions/class-temporary-login.php';

            if (class_exists('Voxel_Toolkit_Temporary_Login')) {
                $temp_login = new Voxel_Toolkit_Temporary_Login();
                $temp_login->handle_temp_login();
            }
        }
    }

    /**
     * Add deactivation warning script
     */
    public function add_deactivation_warning_script() {
        $screen = get_current_screen();
        if ($screen && $screen->id === 'plugins') {
            $plugin_basename = plugin_basename(VOXEL_TOOLKIT_PLUGIN_FILE);
            ?>
            <script type="text/javascript">
            jQuery(document).ready(function($) {
                // Find the deactivate link for our plugin
                var deactivateLink = $('tr[data-plugin="<?php echo esc_js($plugin_basename); ?>"] .deactivate a');
                
                if (deactivateLink.length) {
                    deactivateLink.on('click', function(e) {
                        e.preventDefault();
                        
                        var confirmed = confirm(
                            "⚠️ IMPORTANT WARNING\n\n" +
                            "Deactivating Voxel Toolkit will immediately break:\n" +
                            "• All embedded review badges on external websites\n" +
                            "• All Voxel Toolkit widgets on your site\n" +
                            "• Custom functionality provided by enabled functions\n\n" +
                            "If you have embedded review badges on other websites, they will show errors until you reactivate this plugin.\n\n" +
                            "Are you sure you want to continue with deactivation?"
                        );
                        
                        if (confirmed) {
                            // User confirmed, proceed with deactivation
                            window.location.href = this.href;
                        }
                        // If not confirmed, do nothing (stay on page)
                    });
                }
            });
            </script>
            <?php
        }
    }
    
    /**
     * Plugin activation
     */
    public function activate() {
        // Set default options
        $default_options = array(
            'auto_verify_posts' => array(
                'enabled' => false,
                'post_types' => array()
            ),
            'admin_menu_hide' => array(
                'enabled' => false,
                'hidden_menus' => array()
            ),
            'light_mode' => array(
                'enabled' => false,
                'color_scheme' => 'auto',
                'custom_accent' => '#2271b1'
            ),
            'online_status' => array(
                'enabled' => true,
                'show_in_dashboard' => true,
                'show_in_inbox' => true,
                'show_in_messenger' => true,
                'show_in_admin' => true,
                'timeout_minutes' => 3
            )
        );
        
        add_option('voxel_toolkit_options', $default_options);
        
        // Flush rewrite rules
        flush_rewrite_rules();
    }
    
    /**
     * Force Elementor to refresh widget cache
     */
    public function force_elementor_widget_refresh() {
        // Check if we need to refresh widgets due to title changes
        $current_version = get_option('voxel_toolkit_widget_cache_version', '0');
        
        if (version_compare($current_version, VOXEL_TOOLKIT_VERSION, '<')) {
            // Force Elementor to refresh widget list
            if (class_exists('\Elementor\Plugin')) {
                // Delete cached widgets list
                wp_cache_delete('elementor_widgets', 'elementor');
                
                // Force refresh of widgets registry
                if (method_exists('\Elementor\Plugin', 'instance')) {
                    $elementor = \Elementor\Plugin::instance();
                    if (isset($elementor->widgets_manager)) {
                        // Clear the widgets cache
                        $elementor->widgets_manager->_init_widgets();
                    }
                }
            }
        }
    }
    
    /**
     * Clear Elementor cache if needed to refresh widget titles
     */
    private function maybe_clear_elementor_cache() {
        // Only run this once per plugin update by checking version option
        $current_version = get_option('voxel_toolkit_widget_cache_version', '0');
        
        if (version_compare($current_version, VOXEL_TOOLKIT_VERSION, '<')) {
            // Clear Elementor cache if Elementor is active
            if (class_exists('\Elementor\Plugin')) {
                // Clear Elementor cache
                if (method_exists('\Elementor\Plugin', 'instance')) {
                    $elementor = \Elementor\Plugin::instance();
                    
                    // Clear files cache
                    if (isset($elementor->files_manager)) {
                        $elementor->files_manager->clear_cache();
                    }
                    
                    // Clear widgets cache
                    if (isset($elementor->widgets_manager)) {
                        // Force refresh of widget list
                        wp_cache_delete('elementor_widgets', 'elementor');
                    }
                }
                
                // Clear any Elementor specific caches
                delete_transient('elementor_remote_info_api_data');
                delete_transient('elementor_system_info');
            }
            
            // Update version to prevent running this again
            update_option('voxel_toolkit_widget_cache_version', VOXEL_TOOLKIT_VERSION);
        }
    }

    /**
     * Migrate legacy AI settings to central AI Settings
     *
     * Runs once on upgrade to 1.6.0+ to migrate API keys from:
     * - AI Review Summary (ai_review_summary.api_key)
     * - Timeline Reply Summary (timeline_reply_summary.api_key)
     *
     * To the central AI Settings (ai_settings.api_key)
     */
    private function maybe_migrate_ai_settings() {
        $migration_version = get_option('vt_ai_settings_migration', '0');

        // Only run migration once
        if (version_compare($migration_version, '1.6.0', '>=')) {
            return;
        }

        $options = get_option('voxel_toolkit_options', array());

        // Check if central AI Settings already has an API key
        $central_key = isset($options['ai_settings']['api_key']) ? trim($options['ai_settings']['api_key']) : '';

        if (empty($central_key)) {
            // Try to migrate from AI Review Summary
            $review_summary_key = isset($options['ai_review_summary']['api_key']) ? trim($options['ai_review_summary']['api_key']) : '';

            if (!empty($review_summary_key)) {
                // Migrate the key
                if (!isset($options['ai_settings'])) {
                    $options['ai_settings'] = array();
                }
                $options['ai_settings']['api_key'] = $review_summary_key;
                $options['ai_settings']['provider'] = 'openai'; // AI Review Summary only supported OpenAI
                $options['ai_settings']['openai_model'] = 'gpt-4o-mini'; // Default model

                update_option('voxel_toolkit_options', $options);
            } else {
                // Try to migrate from Timeline Reply Summary
                $timeline_key = isset($options['timeline_reply_summary']['api_key']) ? trim($options['timeline_reply_summary']['api_key']) : '';

                if (!empty($timeline_key)) {
                    // Migrate the key
                    if (!isset($options['ai_settings'])) {
                        $options['ai_settings'] = array();
                    }
                    $options['ai_settings']['api_key'] = $timeline_key;

                    // Check if Timeline Reply Summary had a provider set
                    $provider = isset($options['timeline_reply_summary']['ai_provider']) ? $options['timeline_reply_summary']['ai_provider'] : 'openai';
                    $options['ai_settings']['provider'] = $provider;

                    // Set default models
                    $options['ai_settings']['openai_model'] = 'gpt-4o-mini';
                    $options['ai_settings']['anthropic_model'] = 'claude-3-5-haiku-20241022';

                    update_option('voxel_toolkit_options', $options);
                }
            }
        }

        // Mark migration as complete
        update_option('vt_ai_settings_migration', '1.6.0');
    }

    /**
     * Plugin deactivation
     */
    public function deactivate() {
        // Flush rewrite rules
        flush_rewrite_rules();
    }
}
} // End class_exists check

// Initialize plugin
if (class_exists('Voxel_Toolkit')) {
    Voxel_Toolkit::instance();
}

// Activation hook to flush rewrite rules for embed endpoints
register_activation_hook(__FILE__, function() {
    // Set flag to flush rules on next init
    update_option('voxel_toolkit_flush_rules', '1');
    flush_rewrite_rules();
});

// Deactivation hook to cleanup rewrite rules
register_deactivation_hook(__FILE__, function() {
    flush_rewrite_rules();
});