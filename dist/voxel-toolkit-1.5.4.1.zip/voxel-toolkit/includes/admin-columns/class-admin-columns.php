<?php
/**
 * Admin Columns Feature
 *
 * Configure custom columns for Voxel post types in WordPress admin list tables.
 *
 * @package Voxel_Toolkit
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

class Voxel_Toolkit_Admin_Columns {

    /**
     * Singleton instance
     */
    private static $instance = null;

    /**
     * Column renderer instance
     */
    private $renderer = null;

    /**
     * Column types instance
     */
    private $column_types = null;

    /**
     * Get singleton instance
     */
    public static function instance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Constructor
     */
    private function __construct() {
        // Only run in admin
        if (!is_admin()) {
            return;
        }

        $this->load_dependencies();
        $this->init_hooks();
    }

    /**
     * Load required files
     */
    private function load_dependencies() {
        require_once VOXEL_TOOLKIT_PLUGIN_DIR . 'includes/admin-columns/class-column-types.php';
        require_once VOXEL_TOOLKIT_PLUGIN_DIR . 'includes/admin-columns/class-column-renderer.php';

        $this->column_types = new Voxel_Toolkit_Column_Types();
        $this->renderer = new Voxel_Toolkit_Column_Renderer($this->column_types);
    }

    /**
     * Initialize hooks
     */
    private function init_hooks() {
        // Admin menu
        add_action('admin_menu', array($this, 'add_admin_menu'), 25);

        // Scripts and styles
        add_action('admin_enqueue_scripts', array($this, 'enqueue_scripts'));

        // AJAX endpoints
        add_action('wp_ajax_vt_admin_columns_get_post_types', array($this, 'ajax_get_post_types'));
        add_action('wp_ajax_vt_admin_columns_get_fields', array($this, 'ajax_get_fields'));
        add_action('wp_ajax_vt_admin_columns_save', array($this, 'ajax_save_config'));
        add_action('wp_ajax_vt_admin_columns_load', array($this, 'ajax_load_config'));
        add_action('wp_ajax_vt_admin_columns_restore_defaults', array($this, 'ajax_restore_defaults'));

        // Register column hooks for configured post types
        add_action('admin_init', array($this, 'register_column_hooks'));
    }

    /**
     * Add admin menu
     */
    public function add_admin_menu() {
        add_submenu_page(
            'voxel-toolkit',
            __('Admin Columns', 'voxel-toolkit'),
            __('Admin Columns', 'voxel-toolkit'),
            'manage_options',
            'vt-admin-columns',
            array($this, 'render_settings_page')
        );
    }

    /**
     * Enqueue scripts and styles
     */
    public function enqueue_scripts($hook) {
        // Load on settings page
        if (strpos($hook, 'vt-admin-columns') !== false) {
            $this->enqueue_settings_page_assets();
            return;
        }

        // Load on post list pages (edit.php) for configured post types
        if ($hook === 'edit.php') {
            $this->enqueue_post_list_assets();
        }
    }

    /**
     * Enqueue assets for the settings page
     */
    private function enqueue_settings_page_assets() {
        // Deregister any existing Vue to ensure we use the full build with template compiler
        wp_deregister_script('vue');

        // Vue 3 (full build with template compiler for in-DOM templates)
        wp_enqueue_script(
            'vue',
            'https://unpkg.com/vue@3.4.21/dist/vue.global.js',
            array(),
            '3.4.21',
            true
        );

        // SortableJS for drag and drop
        wp_enqueue_script(
            'sortablejs',
            'https://cdn.jsdelivr.net/npm/sortablejs@1.15.2/Sortable.min.js',
            array(),
            '1.15.2',
            true
        );

        // Admin Columns App
        wp_enqueue_script(
            'vt-admin-columns-app',
            VOXEL_TOOLKIT_PLUGIN_URL . 'includes/admin-columns/assets/js/admin-columns-app.js',
            array('vue', 'sortablejs'),
            VOXEL_TOOLKIT_VERSION,
            true
        );

        // Admin Columns CSS
        wp_enqueue_style(
            'vt-admin-columns',
            VOXEL_TOOLKIT_PLUGIN_URL . 'includes/admin-columns/assets/css/admin-columns.css',
            array(),
            VOXEL_TOOLKIT_VERSION
        );
    }

    /**
     * Enqueue assets for post list pages
     */
    private function enqueue_post_list_assets() {
        global $typenow;

        if (empty($typenow)) {
            return;
        }

        $configs = get_option('voxel_toolkit_admin_columns', array());

        if (!isset($configs[$typenow])) {
            return;
        }

        // Admin Columns CSS for column display styles
        wp_enqueue_style(
            'vt-admin-columns',
            VOXEL_TOOLKIT_PLUGIN_URL . 'includes/admin-columns/assets/css/admin-columns.css',
            array(),
            VOXEL_TOOLKIT_VERSION
        );

        // Output column width styles
        $this->output_column_width_styles($typenow, $configs[$typenow]);

        // Add inline script for dropdown positioning
        add_action('admin_footer', array($this, 'output_dropdown_positioning_script'));
    }

    /**
     * Output inline script for dropdown positioning
     */
    public function output_dropdown_positioning_script() {
        ?>
        <script>
        (function() {
            document.addEventListener('mouseover', function(e) {
                var toggle = e.target.closest('.vt-ac-relations-toggle');
                if (!toggle) return;

                var dropdown = toggle.nextElementSibling;
                if (!dropdown || !dropdown.classList.contains('vt-ac-relations-dropdown')) return;

                var rect = toggle.getBoundingClientRect();
                var viewportWidth = window.innerWidth;
                var viewportHeight = window.innerHeight;

                // Reset positioning
                dropdown.style.left = '';
                dropdown.style.right = '';
                dropdown.style.top = '';
                dropdown.style.bottom = '';

                // Check horizontal position
                if (rect.right + 300 > viewportWidth) {
                    // Would overflow right, align to right
                    dropdown.style.right = '0';
                    dropdown.style.left = 'auto';
                } else if (rect.left < 300) {
                    // Near left edge, align to left
                    dropdown.style.left = '0';
                    dropdown.style.right = 'auto';
                } else {
                    // Default: align right
                    dropdown.style.right = '0';
                    dropdown.style.left = 'auto';
                }

                // Check vertical position
                if (rect.bottom + 260 > viewportHeight) {
                    // Would overflow bottom, open upward
                    dropdown.style.bottom = '100%';
                    dropdown.style.top = 'auto';
                    dropdown.style.marginTop = '0';
                    dropdown.style.marginBottom = '4px';
                } else {
                    // Default: open downward
                    dropdown.style.top = '100%';
                    dropdown.style.bottom = 'auto';
                    dropdown.style.marginTop = '4px';
                    dropdown.style.marginBottom = '0';
                }
            });
        })();
        </script>
        <?php
    }

    /**
     * Output inline CSS for column widths
     */
    private function output_column_width_styles($post_type, $config) {
        if (empty($config['columns'])) {
            return;
        }

        $styles = array();

        foreach ($config['columns'] as $col) {
            if (isset($col['width']) && $col['width']['mode'] !== 'auto' && !empty($col['width']['value'])) {
                $column_key = 'vt_' . $col['id'];
                $width_value = intval($col['width']['value']);
                $width_unit = $col['width']['mode'] === '%' ? '%' : 'px';

                $styles[] = sprintf(
                    '.wp-list-table .column-%s { width: %d%s; }',
                    esc_attr($column_key),
                    $width_value,
                    $width_unit
                );
            }
        }

        if (!empty($styles)) {
            wp_add_inline_style('vt-admin-columns', implode("\n", $styles));
        }
    }

    /**
     * Get localization data for JavaScript
     */
    public function get_js_data() {
        return array(
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('vt_admin_columns_nonce'),
            'fieldTypes' => $this->column_types->get_field_type_info(),
            'i18n' => array(
                'save' => __('Save Changes', 'voxel-toolkit'),
                'saving' => __('Saving...', 'voxel-toolkit'),
                'saved' => __('Saved!', 'voxel-toolkit'),
                'addColumn' => __('Add Column', 'voxel-toolkit'),
                'removeColumn' => __('Remove', 'voxel-toolkit'),
                'selectPostType' => __('Select a post type', 'voxel-toolkit'),
                'selectField' => __('Select a field', 'voxel-toolkit'),
                'noColumns' => __('No columns configured. Click "Add Column" to get started.', 'voxel-toolkit'),
                'label' => __('Label', 'voxel-toolkit'),
                'field' => __('Field', 'voxel-toolkit'),
                'width' => __('Width', 'voxel-toolkit'),
                'auto' => __('Auto', 'voxel-toolkit'),
                'sortable' => __('Sortable', 'voxel-toolkit'),
                'filterable' => __('Filterable', 'voxel-toolkit'),
                'viewPosts' => __('View Posts', 'voxel-toolkit'),
                'restoreDefaults' => __('Restore Defaults', 'voxel-toolkit'),
                'confirmRestore' => __('Are you sure you want to restore default columns for this post type?', 'voxel-toolkit'),
                'error' => __('An error occurred. Please try again.', 'voxel-toolkit'),
                'loading' => __('Loading...', 'voxel-toolkit'),
            ),
        );
    }

    /**
     * Render settings page
     */
    public function render_settings_page() {
        include VOXEL_TOOLKIT_PLUGIN_DIR . 'includes/admin-columns/templates/admin-columns-page.php';
    }

    /**
     * AJAX: Get Voxel post types
     */
    public function ajax_get_post_types() {
        check_ajax_referer('vt_admin_columns_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => __('Unauthorized', 'voxel-toolkit')));
        }

        if (!class_exists('\Voxel\Post_Type')) {
            wp_send_json_error(array('message' => __('Voxel is not active', 'voxel-toolkit')));
        }

        $voxel_types = \Voxel\Post_Type::get_voxel_types();
        $post_types = array();

        foreach ($voxel_types as $key => $type) {
            $post_types[] = array(
                'key' => $key,
                'label' => $type->get_label(),
                'singular' => $type->get_singular_name(),
                'edit_url' => admin_url("edit.php?post_type={$key}"),
            );
        }

        wp_send_json_success($post_types);
    }

    /**
     * AJAX: Get fields for a post type
     */
    public function ajax_get_fields() {
        check_ajax_referer('vt_admin_columns_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => __('Unauthorized', 'voxel-toolkit')));
        }

        $post_type_key = isset($_POST['post_type']) ? sanitize_text_field($_POST['post_type']) : '';

        if (empty($post_type_key)) {
            wp_send_json_error(array('message' => __('Post type is required', 'voxel-toolkit')));
        }

        if (!class_exists('\Voxel\Post_Type')) {
            wp_send_json_error(array('message' => __('Voxel is not active', 'voxel-toolkit')));
        }

        $post_type = \Voxel\Post_Type::get($post_type_key);

        if (!$post_type) {
            wp_send_json_error(array('message' => __('Invalid post type', 'voxel-toolkit')));
        }

        $field_data = array();

        // Add WordPress core fields first (prefixed with :)
        $field_data[] = array(
            'key' => ':date',
            'label' => __('Date Published', 'voxel-toolkit'),
            'type' => 'wp-date',
            'type_label' => __('WordPress', 'voxel-toolkit'),
            'sortable' => true,
            'filterable' => false,
        );

        $field_data[] = array(
            'key' => ':author',
            'label' => __('Author', 'voxel-toolkit'),
            'type' => 'wp-author',
            'type_label' => __('WordPress', 'voxel-toolkit'),
            'sortable' => true,
            'filterable' => false,
        );

        $field_data[] = array(
            'key' => ':status',
            'label' => __('Status', 'voxel-toolkit'),
            'type' => 'wp-status',
            'type_label' => __('WordPress', 'voxel-toolkit'),
            'sortable' => false,
            'filterable' => true,
        );

        $field_data[] = array(
            'key' => ':id',
            'label' => __('Post ID', 'voxel-toolkit'),
            'type' => 'wp-id',
            'type_label' => __('WordPress', 'voxel-toolkit'),
            'sortable' => true,
            'filterable' => false,
        );

        $field_data[] = array(
            'key' => ':modified',
            'label' => __('Last Modified', 'voxel-toolkit'),
            'type' => 'wp-modified',
            'type_label' => __('WordPress', 'voxel-toolkit'),
            'sortable' => true,
            'filterable' => false,
        );

        $field_data[] = array(
            'key' => ':slug',
            'label' => __('Slug', 'voxel-toolkit'),
            'type' => 'wp-slug',
            'type_label' => __('WordPress', 'voxel-toolkit'),
            'sortable' => true,
            'filterable' => false,
        );

        $field_data[] = array(
            'key' => ':excerpt',
            'label' => __('Excerpt', 'voxel-toolkit'),
            'type' => 'wp-excerpt',
            'type_label' => __('WordPress', 'voxel-toolkit'),
            'sortable' => false,
            'filterable' => false,
        );

        $field_data[] = array(
            'key' => ':thumbnail',
            'label' => __('Featured Image', 'voxel-toolkit'),
            'type' => 'wp-thumbnail',
            'type_label' => __('WordPress', 'voxel-toolkit'),
            'sortable' => false,
            'filterable' => false,
            'is_image' => true,
        );

        $field_data[] = array(
            'key' => ':comments',
            'label' => __('Comments', 'voxel-toolkit'),
            'type' => 'wp-comments',
            'type_label' => __('WordPress', 'voxel-toolkit'),
            'sortable' => true,
            'filterable' => false,
        );

        $field_data[] = array(
            'key' => ':menu_order',
            'label' => __('Menu Order', 'voxel-toolkit'),
            'type' => 'wp-menu-order',
            'type_label' => __('WordPress', 'voxel-toolkit'),
            'sortable' => true,
            'filterable' => false,
        );

        $field_data[] = array(
            'key' => ':parent',
            'label' => __('Parent', 'voxel-toolkit'),
            'type' => 'wp-parent',
            'type_label' => __('WordPress', 'voxel-toolkit'),
            'sortable' => false,
            'filterable' => false,
        );

        $field_data[] = array(
            'key' => ':word_count',
            'label' => __('Word Count', 'voxel-toolkit'),
            'type' => 'wp-word-count',
            'type_label' => __('WordPress', 'voxel-toolkit'),
            'sortable' => false, // Calculated on-the-fly, can't sort efficiently
            'filterable' => false,
        );

        $field_data[] = array(
            'key' => ':view_counts',
            'label' => __('View Counts', 'voxel-toolkit'),
            'type' => 'voxel-view-counts',
            'type_label' => __('Voxel', 'voxel-toolkit'),
            'sortable' => true,
            'filterable' => false,
        );

        $field_data[] = array(
            'key' => ':review_stats',
            'label' => __('Review Stats', 'voxel-toolkit'),
            'type' => 'voxel-review-stats',
            'type_label' => __('Voxel', 'voxel-toolkit'),
            'sortable' => true,
            'filterable' => false,
        );

        $field_data[] = array(
            'key' => ':listing_plan',
            'label' => __('Listing Plan', 'voxel-toolkit'),
            'type' => 'voxel-listing-plan',
            'type_label' => __('Voxel', 'voxel-toolkit'),
            'sortable' => false,
            'filterable' => true,
        );

        // Add Voxel fields
        $fields = $post_type->get_fields();
        $skip_types = array('ui-step', 'ui-heading', 'ui-image');

        foreach ($fields as $field) {
            $type = $field->get_type();

            // Skip UI-only fields
            if (in_array($type, $skip_types)) {
                continue;
            }

            $type_info = $this->column_types->get_type_info($type);

            $field_entry = array(
                'key' => $field->get_key(),
                'label' => $field->get_label(),
                'type' => $type,
                'type_label' => $type_info['label'],
                'sortable' => $type_info['sortable'],
                'filterable' => $type_info['filterable'],
            );

            // Flag image fields for special handling
            if (in_array($type, array('image', 'profile-avatar'))) {
                $field_entry['is_image'] = true;
            }

            $field_data[] = $field_entry;
        }

        wp_send_json_success($field_data);
    }

    /**
     * AJAX: Save column configuration
     */
    public function ajax_save_config() {
        check_ajax_referer('vt_admin_columns_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => __('Unauthorized', 'voxel-toolkit')));
        }

        $post_type = isset($_POST['post_type']) ? sanitize_text_field($_POST['post_type']) : '';
        $config = isset($_POST['config']) ? json_decode(stripslashes($_POST['config']), true) : null;

        if (empty($post_type)) {
            wp_send_json_error(array('message' => __('Post type is required', 'voxel-toolkit')));
        }

        if (!is_array($config)) {
            wp_send_json_error(array('message' => __('Invalid configuration', 'voxel-toolkit')));
        }

        $sanitized = $this->sanitize_config($config);

        $all_configs = get_option('voxel_toolkit_admin_columns', array());
        $all_configs[$post_type] = $sanitized;

        update_option('voxel_toolkit_admin_columns', $all_configs);

        wp_send_json_success(array('message' => __('Configuration saved', 'voxel-toolkit')));
    }

    /**
     * AJAX: Load column configuration
     */
    public function ajax_load_config() {
        check_ajax_referer('vt_admin_columns_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => __('Unauthorized', 'voxel-toolkit')));
        }

        $post_type = isset($_POST['post_type']) ? sanitize_text_field($_POST['post_type']) : '';

        if (empty($post_type)) {
            wp_send_json_error(array('message' => __('Post type is required', 'voxel-toolkit')));
        }

        $all_configs = get_option('voxel_toolkit_admin_columns', array());

        if (isset($all_configs[$post_type])) {
            // Return saved config
            $config = $all_configs[$post_type];
        } else {
            // Return default columns for new post types
            $config = $this->get_default_config($post_type);
        }

        wp_send_json_success($config);
    }

    /**
     * Get default column configuration for a post type
     */
    private function get_default_config($post_type) {
        $default_columns = array(
            array(
                'id' => 'col_title',
                'field_key' => 'title',
                'label' => __('Title', 'voxel-toolkit'),
                'width' => array('mode' => 'auto', 'value' => null),
                'sortable' => true,
                'filterable' => false,
            ),
            array(
                'id' => 'col_date',
                'field_key' => ':date',
                'label' => __('Date Published', 'voxel-toolkit'),
                'width' => array('mode' => 'auto', 'value' => null),
                'sortable' => true,
                'filterable' => false,
            ),
            array(
                'id' => 'col_author',
                'field_key' => ':author',
                'label' => __('Author', 'voxel-toolkit'),
                'width' => array('mode' => 'auto', 'value' => null),
                'sortable' => true,
                'filterable' => false,
            ),
        );

        return array(
            'columns' => $default_columns,
            'settings' => array(
                'default_sort' => array('column' => 'date', 'order' => 'desc'),
                'primary_column' => 'title',
            ),
        );
    }

    /**
     * AJAX: Restore default columns
     */
    public function ajax_restore_defaults() {
        check_ajax_referer('vt_admin_columns_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => __('Unauthorized', 'voxel-toolkit')));
        }

        $post_type = isset($_POST['post_type']) ? sanitize_text_field($_POST['post_type']) : '';

        if (empty($post_type)) {
            wp_send_json_error(array('message' => __('Post type is required', 'voxel-toolkit')));
        }

        $all_configs = get_option('voxel_toolkit_admin_columns', array());

        if (isset($all_configs[$post_type])) {
            unset($all_configs[$post_type]);
            update_option('voxel_toolkit_admin_columns', $all_configs);
        }

        wp_send_json_success(array('message' => __('Defaults restored', 'voxel-toolkit')));
    }

    /**
     * Sanitize configuration
     */
    private function sanitize_config($config) {
        $sanitized = array(
            'columns' => array(),
            'settings' => array(
                'default_sort' => array('column' => 'date', 'order' => 'desc'),
                'primary_column' => 'title',
            ),
        );

        // Sanitize columns
        if (isset($config['columns']) && is_array($config['columns'])) {
            foreach ($config['columns'] as $column) {
                if (!isset($column['field_key']) || empty($column['field_key'])) {
                    continue;
                }

                $sanitized_column = array(
                    'id' => isset($column['id']) ? sanitize_text_field($column['id']) : $this->generate_id(),
                    'field_key' => sanitize_text_field($column['field_key']),
                    'label' => isset($column['label']) ? sanitize_text_field($column['label']) : '',
                    'width' => array(
                        'mode' => isset($column['width']['mode']) && in_array($column['width']['mode'], array('auto', 'px', '%'))
                            ? $column['width']['mode']
                            : 'auto',
                        'value' => isset($column['width']['value']) ? absint($column['width']['value']) : null,
                    ),
                    'sortable' => !empty($column['sortable']),
                    'filterable' => !empty($column['filterable']),
                );

                // Sanitize image settings if present
                if (isset($column['image_settings']) && is_array($column['image_settings'])) {
                    $valid_sizes = array('thumbnail', 'medium', 'medium_large', 'large', 'full');
                    $sanitized_column['image_settings'] = array(
                        'display_width' => isset($column['image_settings']['display_width'])
                            ? min(500, max(20, absint($column['image_settings']['display_width'])))
                            : 60,
                        'display_height' => isset($column['image_settings']['display_height'])
                            ? min(500, max(20, absint($column['image_settings']['display_height'])))
                            : 60,
                        'wp_size' => isset($column['image_settings']['wp_size']) && in_array($column['image_settings']['wp_size'], $valid_sizes)
                            ? $column['image_settings']['wp_size']
                            : 'thumbnail',
                    );
                }

                // Sanitize product settings if present
                if (isset($column['product_settings']) && is_array($column['product_settings'])) {
                    $valid_displays = array('price', 'price_range', 'product_type', 'booking_type', 'stock', 'calendar', 'summary');
                    $sanitized_column['product_settings'] = array(
                        'display' => isset($column['product_settings']['display']) && in_array($column['product_settings']['display'], $valid_displays)
                            ? $column['product_settings']['display']
                            : 'price',
                    );
                }

                // Sanitize work hours settings if present
                if (isset($column['work_hours_settings']) && is_array($column['work_hours_settings'])) {
                    $valid_displays = array('status', 'today', 'badge');
                    $sanitized_column['work_hours_settings'] = array(
                        'display' => isset($column['work_hours_settings']['display']) && in_array($column['work_hours_settings']['display'], $valid_displays)
                            ? $column['work_hours_settings']['display']
                            : 'status',
                    );
                }

                // Sanitize location settings if present
                if (isset($column['location_settings']) && is_array($column['location_settings'])) {
                    $valid_displays = array('address', 'coordinates', 'latitude', 'longitude', 'full');
                    $sanitized_column['location_settings'] = array(
                        'display' => isset($column['location_settings']['display']) && in_array($column['location_settings']['display'], $valid_displays)
                            ? $column['location_settings']['display']
                            : 'address',
                    );
                }

                // Sanitize date settings if present
                if (isset($column['date_settings']) && is_array($column['date_settings'])) {
                    $valid_displays = array('date', 'datetime', 'relative');
                    $sanitized_column['date_settings'] = array(
                        'display' => isset($column['date_settings']['display']) && in_array($column['date_settings']['display'], $valid_displays)
                            ? $column['date_settings']['display']
                            : 'date',
                    );
                }

                // Sanitize recurring date settings if present
                if (isset($column['recurring_date_settings']) && is_array($column['recurring_date_settings'])) {
                    $valid_displays = array('start_date', 'start_datetime', 'end_date', 'end_datetime', 'date_range', 'frequency', 'multiday', 'allday', 'summary');
                    $sanitized_column['recurring_date_settings'] = array(
                        'display' => isset($column['recurring_date_settings']['display']) && in_array($column['recurring_date_settings']['display'], $valid_displays)
                            ? $column['recurring_date_settings']['display']
                            : 'start_date',
                    );
                }

                // Sanitize listing plan settings if present
                if (isset($column['listing_plan_settings']) && is_array($column['listing_plan_settings'])) {
                    $valid_displays = array('plan_name', 'amount', 'frequency', 'purchase_date', 'expiration', 'summary');
                    $sanitized_column['listing_plan_settings'] = array(
                        'display' => isset($column['listing_plan_settings']['display']) && in_array($column['listing_plan_settings']['display'], $valid_displays)
                            ? $column['listing_plan_settings']['display']
                            : 'plan_name',
                    );
                }

                $sanitized['columns'][] = $sanitized_column;
            }
        }

        // Sanitize settings
        if (isset($config['settings']) && is_array($config['settings'])) {
            if (isset($config['settings']['default_sort'])) {
                $sanitized['settings']['default_sort'] = array(
                    'column' => isset($config['settings']['default_sort']['column'])
                        ? sanitize_text_field($config['settings']['default_sort']['column'])
                        : 'date',
                    'order' => isset($config['settings']['default_sort']['order']) && in_array($config['settings']['default_sort']['order'], array('asc', 'desc'))
                        ? $config['settings']['default_sort']['order']
                        : 'desc',
                );
            }

            if (isset($config['settings']['primary_column'])) {
                $sanitized['settings']['primary_column'] = sanitize_text_field($config['settings']['primary_column']);
            }
        }

        return $sanitized;
    }

    /**
     * Generate unique ID
     */
    private function generate_id() {
        return 'col_' . substr(md5(uniqid()), 0, 8);
    }

    /**
     * Register column hooks for all configured post types
     */
    public function register_column_hooks() {
        $configs = get_option('voxel_toolkit_admin_columns', array());

        if (empty($configs)) {
            return;
        }

        foreach ($configs as $post_type => $config) {
            if (empty($config['columns'])) {
                continue;
            }

            // Store config in closure
            $columns_config = $config;
            $renderer = $this->renderer;
            $column_types = $this->column_types;

            // Modify column headers
            add_filter("manage_{$post_type}_posts_columns", function($columns) use ($columns_config) {
                return $this->modify_columns($columns, $columns_config);
            }, 100);

            // Render column content
            add_action("manage_{$post_type}_posts_custom_column", function($column, $post_id) use ($columns_config, $renderer) {
                $this->render_column_content($column, $post_id, $columns_config, $renderer);
            }, 10, 2);

            // Register sortable columns
            add_filter("manage_edit-{$post_type}_sortable_columns", function($sortable) use ($columns_config) {
                return $this->register_sortable_columns($sortable, $columns_config);
            });
        }

        // Handle sorting query
        add_action('pre_get_posts', array($this, 'handle_sort_query'));

        // Handle filter query
        add_action('pre_get_posts', array($this, 'handle_filter_query'));

        // Add filter dropdowns
        add_action('restrict_manage_posts', array($this, 'render_filter_dropdowns'));

        // Add Edit Columns link
        add_action('manage_posts_extra_tablenav', array($this, 'render_edit_columns_link'));
    }

    /**
     * Render the Edit Columns link in the post list table
     */
    public function render_edit_columns_link($which) {
        // Only show on the top tablenav
        if ($which !== 'top') {
            return;
        }

        global $typenow;

        if (empty($typenow)) {
            return;
        }

        $configs = get_option('voxel_toolkit_admin_columns', array());

        // Only show for configured post types
        if (!isset($configs[$typenow])) {
            return;
        }

        // Check user capability
        if (!current_user_can('manage_options')) {
            return;
        }

        $edit_url = admin_url('admin.php?page=vt-admin-columns&type=' . urlencode($typenow));

        ?>
        <a href="<?php echo esc_url($edit_url); ?>" class="button vt-edit-columns-btn" style="margin-left: 8px;">
            <span class="dashicons dashicons-admin-generic" style="vertical-align: middle; margin-top: -2px; font-size: 16px;"></span>
            <?php _e('Edit Columns', 'voxel-toolkit'); ?>
        </a>
        <?php
    }

    /**
     * Modify columns for a post type
     */
    private function modify_columns($columns, $config) {
        $new_columns = array();

        // Keep checkbox column
        if (isset($columns['cb'])) {
            $new_columns['cb'] = $columns['cb'];
        }

        // Add configured columns - use unique ID to allow duplicate fields
        foreach ($config['columns'] as $col) {
            $column_key = 'vt_' . $col['id'];
            $new_columns[$column_key] = !empty($col['label']) ? $col['label'] : $col['field_key'];
        }

        // Note: We don't keep the default 'date' column since users can add :date if they want it

        return $new_columns;
    }

    /**
     * Render column content
     */
    private function render_column_content($column, $post_id, $config, $renderer) {
        // Check if this is one of our columns
        if (strpos($column, 'vt_') !== 0) {
            return;
        }

        $column_id = substr($column, 3); // Remove 'vt_' prefix

        // Find the column config by ID
        $column_config = null;
        foreach ($config['columns'] as $col) {
            if ($col['id'] === $column_id) {
                $column_config = $col;
                break;
            }
        }

        if (!$column_config) {
            echo '&mdash;';
            return;
        }

        // Pass column config to renderer for image sizing - use field_key for rendering
        echo $renderer->render($column_config['field_key'], $post_id, $column_config);
    }

    /**
     * Register sortable columns
     */
    private function register_sortable_columns($sortable, $config) {
        foreach ($config['columns'] as $col) {
            if (!empty($col['sortable'])) {
                $column_key = 'vt_' . $col['id'];
                $sortable[$column_key] = $col['field_key'];
            }
        }

        return $sortable;
    }

    /**
     * Handle sort query modifications
     */
    public function handle_sort_query($query) {
        if (!is_admin() || !$query->is_main_query()) {
            return;
        }

        $orderby = $query->get('orderby');

        if (empty($orderby)) {
            return;
        }

        $post_type = $query->get('post_type');
        $configs = get_option('voxel_toolkit_admin_columns', array());

        if (!isset($configs[$post_type])) {
            return;
        }

        // Check if sorting by one of our columns
        foreach ($configs[$post_type]['columns'] as $col) {
            if ($col['field_key'] === $orderby && !empty($col['sortable'])) {
                // Handle WordPress core fields (prefixed with :)
                if (strpos($col['field_key'], ':') === 0) {
                    $this->handle_wp_field_sort($query, $col['field_key']);
                } else {
                    // Handle Voxel meta fields
                    $query->set('meta_key', $col['field_key']);

                    // Determine if numeric sort is needed
                    $type_info = $this->column_types->get_type_info($this->get_field_type($col['field_key'], $post_type));
                    $query->set('orderby', $type_info['numeric'] ? 'meta_value_num' : 'meta_value');
                }

                break;
            }
        }
    }

    /**
     * Handle sorting for WordPress core fields
     */
    private function handle_wp_field_sort($query, $field_key) {
        switch ($field_key) {
            case ':date':
                $query->set('orderby', 'date');
                break;

            case ':modified':
                $query->set('orderby', 'modified');
                break;

            case ':author':
                $query->set('orderby', 'author');
                break;

            case ':id':
                $query->set('orderby', 'ID');
                break;

            case ':slug':
                $query->set('orderby', 'name');
                break;

            case ':comments':
                $query->set('orderby', 'comment_count');
                break;

            case ':menu_order':
                $query->set('orderby', 'menu_order');
                break;
        }
    }

    /**
     * Render filter dropdowns
     */
    public function render_filter_dropdowns($post_type) {
        $configs = get_option('voxel_toolkit_admin_columns', array());

        if (!isset($configs[$post_type])) {
            return;
        }

        foreach ($configs[$post_type]['columns'] as $col) {
            if (empty($col['filterable'])) {
                continue;
            }

            // Handle WordPress core fields
            if ($col['field_key'] === ':status') {
                $this->render_status_filter($col);
                continue;
            }

            $field_type = $this->get_field_type($col['field_key'], $post_type);

            // Only render filters for select and switcher types
            if (!in_array($field_type, array('select', 'switcher'))) {
                continue;
            }

            $this->render_single_filter($col, $post_type, $field_type);
        }
    }

    /**
     * Render the post status filter dropdown
     */
    private function render_status_filter($col) {
        $current_value = isset($_GET['post_status']) ? sanitize_text_field($_GET['post_status']) : '';

        $statuses = get_post_stati(array('show_in_admin_status_list' => true), 'objects');

        ?>
        <select name="post_status">
            <option value=""><?php echo esc_html($col['label'] ?: __('Status', 'voxel-toolkit')); ?></option>
            <?php foreach ($statuses as $status): ?>
                <option value="<?php echo esc_attr($status->name); ?>" <?php selected($current_value, $status->name); ?>>
                    <?php echo esc_html($status->label); ?>
                </option>
            <?php endforeach; ?>
        </select>
        <?php
    }

    /**
     * Render a single filter dropdown
     */
    private function render_single_filter($col, $post_type, $field_type) {
        $current_value = isset($_GET['vt_filter_' . $col['field_key']])
            ? sanitize_text_field($_GET['vt_filter_' . $col['field_key']])
            : '';

        $options = $this->get_filter_options($col['field_key'], $post_type, $field_type);

        if (empty($options)) {
            return;
        }

        ?>
        <select name="vt_filter_<?php echo esc_attr($col['field_key']); ?>">
            <option value=""><?php echo esc_html($col['label'] ?: $col['field_key']); ?></option>
            <?php foreach ($options as $value => $label): ?>
                <option value="<?php echo esc_attr($value); ?>" <?php selected($current_value, $value); ?>>
                    <?php echo esc_html($label); ?>
                </option>
            <?php endforeach; ?>
        </select>
        <?php
    }

    /**
     * Get filter options for a field
     */
    private function get_filter_options($field_key, $post_type, $field_type) {
        if ($field_type === 'switcher') {
            return array(
                '1' => __('Yes', 'voxel-toolkit'),
                '0' => __('No', 'voxel-toolkit'),
            );
        }

        // For select fields, get options from field config
        if (!class_exists('\Voxel\Post_Type')) {
            return array();
        }

        $voxel_post_type = \Voxel\Post_Type::get($post_type);
        if (!$voxel_post_type) {
            return array();
        }

        $field = $voxel_post_type->get_field($field_key);
        if (!$field) {
            return array();
        }

        // Try to get choices from field
        if (method_exists($field, 'get_choices')) {
            $choices = $field->get_choices();
            $options = array();

            foreach ($choices as $choice) {
                if (isset($choice['value']) && isset($choice['label'])) {
                    $options[$choice['value']] = $choice['label'];
                }
            }

            return $options;
        }

        return array();
    }

    /**
     * Handle filter query modifications
     */
    public function handle_filter_query($query) {
        if (!is_admin() || !$query->is_main_query()) {
            return;
        }

        $post_type = $query->get('post_type');
        $configs = get_option('voxel_toolkit_admin_columns', array());

        if (!isset($configs[$post_type])) {
            return;
        }

        $meta_query = $query->get('meta_query') ?: array();

        foreach ($configs[$post_type]['columns'] as $col) {
            if (empty($col['filterable'])) {
                continue;
            }

            $filter_key = 'vt_filter_' . $col['field_key'];

            if (!isset($_GET[$filter_key]) || $_GET[$filter_key] === '') {
                continue;
            }

            $filter_value = sanitize_text_field($_GET[$filter_key]);

            $meta_query[] = array(
                'key' => $col['field_key'],
                'value' => $filter_value,
                'compare' => '=',
            );
        }

        if (!empty($meta_query)) {
            $query->set('meta_query', $meta_query);
        }
    }

    /**
     * Get field type for a given field key
     */
    private function get_field_type($field_key, $post_type) {
        if (!class_exists('\Voxel\Post_Type')) {
            return 'text';
        }

        $voxel_post_type = \Voxel\Post_Type::get($post_type);
        if (!$voxel_post_type) {
            return 'text';
        }

        $field = $voxel_post_type->get_field($field_key);
        if (!$field) {
            return 'text';
        }

        return $field->get_type();
    }
}
