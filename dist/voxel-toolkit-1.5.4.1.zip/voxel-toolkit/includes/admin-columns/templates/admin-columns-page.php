<?php
/**
 * Admin Columns Settings Page Template
 *
 * @package Voxel_Toolkit
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Get the admin columns instance and output JS data inline
$admin_columns = Voxel_Toolkit_Admin_Columns::instance();
$js_data = $admin_columns->get_js_data();
?>
<script>
    var vtAdminColumns = <?php echo wp_json_encode($js_data); ?>;
</script>
<div class="wrap vt-ac-wrap">
    <h1><?php _e('Admin Columns', 'voxel-toolkit'); ?></h1>
    <p class="description"><?php _e('Configure which columns appear in the WordPress admin list for each Voxel post type.', 'voxel-toolkit'); ?></p>

    <div id="vt-admin-columns-app" v-cloak>
        <!-- Header with Post Type Selector -->
        <div class="vt-ac-header">
            <select v-model="selectedPostType" :disabled="loading">
                <option :value="null">{{ vtAdminColumns.i18n.selectPostType }}</option>
                <option v-for="pt in postTypes" :key="pt.key" :value="pt.key">
                    {{ pt.label }}
                </option>
            </select>

            <a v-if="selectedPostType && currentPostType"
               :href="currentEditUrl"
               target="_blank"
               class="button">
                {{ vtAdminColumns.i18n.viewPosts }} &rarr;
            </a>

            <span v-if="loading" class="spinner is-active" style="float: none;"></span>
        </div>

        <!-- Loading State -->
        <div v-if="loadingFields" class="vt-ac-loading">
            <span class="spinner is-active" style="float: none;"></span>
            {{ vtAdminColumns.i18n.loading }}
        </div>

        <!-- No Post Type Selected -->
        <div v-else-if="!selectedPostType" class="vt-ac-empty-state">
            <p><?php _e('Select a post type above to configure its admin columns.', 'voxel-toolkit'); ?></p>
        </div>

        <!-- Main Content -->
        <div v-else class="vt-ac-main">
            <!-- Columns Area -->
            <div class="vt-ac-columns-area">
                <!-- Empty State -->
                <div v-if="columns.length === 0" class="vt-ac-empty-state">
                    <p>{{ vtAdminColumns.i18n.noColumns }}</p>
                    <button @click="addColumn" class="button button-primary">
                        + {{ vtAdminColumns.i18n.addColumn }}
                    </button>
                </div>

                <!-- Column List -->
                <div v-else class="vt-ac-column-list">
                    <div id="vt-sortable-columns">
                        <div v-for="(element, index) in columns"
                             :key="element.id"
                             class="vt-ac-column-card"
                             :class="{ expanded: expandedColumnId === element.id }">
                            <!-- Column Header -->
                            <div class="vt-ac-column-header" @click="toggleExpand(element.id)">
                                <span class="vt-ac-drag-handle">&#8942;&#8942;</span>

                                <span class="vt-ac-column-label">
                                    {{ element.label || element.field_key || '<?php _e('New Column', 'voxel-toolkit'); ?>' }}
                                </span>

                                <span v-if="element.field_key" class="vt-ac-column-type">
                                    {{ getFieldTypeLabel(element.field_key) }}
                                </span>

                                <span class="vt-ac-column-expand dashicons dashicons-arrow-down-alt2"></span>

                                <button
                                    @click.stop="removeColumn(element.id)"
                                    class="vt-ac-remove"
                                    :title="vtAdminColumns.i18n.removeColumn">
                                    &times;
                                </button>
                            </div>

                            <!-- Column Settings -->
                            <div v-if="expandedColumnId === element.id" class="vt-ac-column-settings">
                                <!-- Field Selection with Searchable Dropdown -->
                                <div class="vt-ac-field-group">
                                    <label>{{ vtAdminColumns.i18n.field }}</label>
                                    <div class="vt-ac-dropdown" :class="{ open: dropdownOpen === element.id }">
                                        <button type="button"
                                                class="vt-ac-dropdown-trigger"
                                                @click.stop="toggleDropdown(element.id)">
                                            <span v-if="element.field_key">{{ getField(element.field_key)?.label || element.field_key }}</span>
                                            <span v-else class="vt-ac-dropdown-placeholder"><?php _e('Select a field...', 'voxel-toolkit'); ?></span>
                                            <span class="dashicons dashicons-arrow-down-alt2"></span>
                                        </button>
                                        <div v-if="dropdownOpen === element.id" class="vt-ac-dropdown-menu" @click.stop>
                                            <div class="vt-ac-dropdown-search">
                                                <input type="text"
                                                       v-model="fieldSearch"
                                                       placeholder="<?php _e('Search fields...', 'voxel-toolkit'); ?>"
                                                       ref="dropdownSearchInput"
                                                       @keydown.escape="closeDropdown">
                                            </div>
                                            <div class="vt-ac-dropdown-options">
                                                <div v-if="filteredFields.length === 0" class="vt-ac-dropdown-empty">
                                                    <?php _e('No fields found', 'voxel-toolkit'); ?>
                                                </div>
                                                <button v-for="field in filteredFields"
                                                        :key="field.key"
                                                        type="button"
                                                        class="vt-ac-dropdown-option"
                                                        :class="{ selected: element.field_key === field.key }"
                                                        @click="selectField(element, field.key)">
                                                    <span class="vt-ac-dropdown-option-label">{{ field.label }}</span>
                                                    <span class="vt-ac-dropdown-option-type">{{ field.type_label }}</span>
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <!-- Label -->
                                <div class="vt-ac-field-group">
                                    <label>{{ vtAdminColumns.i18n.label }}</label>
                                    <input type="text"
                                           v-model="element.label"
                                           @input="markChanged"
                                           :placeholder="getField(element.field_key)?.label || ''">
                                </div>

                                <!-- Width -->
                                <div class="vt-ac-field-group">
                                    <label>{{ vtAdminColumns.i18n.width }}</label>
                                    <div class="vt-ac-width-control">
                                        <select v-model="element.width.mode" @change="markChanged">
                                            <option value="auto">{{ vtAdminColumns.i18n.auto }}</option>
                                            <option value="px">px</option>
                                            <option value="%">%</option>
                                        </select>
                                        <input v-if="element.width.mode !== 'auto'"
                                               type="number"
                                               v-model.number="element.width.value"
                                               @input="markChanged"
                                               min="1"
                                               max="500"
                                               placeholder="100">
                                    </div>
                                </div>

                                <!-- Image Settings (only for image fields) -->
                                <div v-if="isImageField(element.field_key) && element.image_settings" class="vt-ac-image-settings">
                                    <h4><?php _e('Image Settings', 'voxel-toolkit'); ?></h4>
                                    <div class="vt-ac-field-row">
                                        <div class="vt-ac-field-group">
                                            <label><?php _e('WordPress Size', 'voxel-toolkit'); ?></label>
                                            <select v-model="element.image_settings.wp_size" @change="markChanged">
                                                <option value="thumbnail"><?php _e('Thumbnail', 'voxel-toolkit'); ?></option>
                                                <option value="medium"><?php _e('Medium', 'voxel-toolkit'); ?></option>
                                                <option value="medium_large"><?php _e('Medium Large', 'voxel-toolkit'); ?></option>
                                                <option value="large"><?php _e('Large', 'voxel-toolkit'); ?></option>
                                                <option value="full"><?php _e('Full', 'voxel-toolkit'); ?></option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="vt-ac-field-row">
                                        <div class="vt-ac-field-group">
                                            <label><?php _e('Display Width (px)', 'voxel-toolkit'); ?></label>
                                            <input type="number"
                                                   v-model.number="element.image_settings.display_width"
                                                   @input="markChanged"
                                                   min="20"
                                                   max="500"
                                                   placeholder="60">
                                        </div>
                                        <div class="vt-ac-field-group">
                                            <label><?php _e('Display Height (px)', 'voxel-toolkit'); ?></label>
                                            <input type="number"
                                                   v-model.number="element.image_settings.display_height"
                                                   @input="markChanged"
                                                   min="20"
                                                   max="500"
                                                   placeholder="60">
                                        </div>
                                    </div>
                                </div>

                                <!-- Product Settings (only for product fields) -->
                                <div v-if="isProductField(element.field_key) && element.product_settings" class="vt-ac-product-settings">
                                    <h4><?php _e('Product Display', 'voxel-toolkit'); ?></h4>
                                    <div class="vt-ac-field-group">
                                        <label><?php _e('Show', 'voxel-toolkit'); ?></label>
                                        <select v-model="element.product_settings.display" @change="markChanged">
                                            <option value="price"><?php _e('Base Price', 'voxel-toolkit'); ?></option>
                                            <option value="price_range"><?php _e('Price Range', 'voxel-toolkit'); ?></option>
                                            <option value="product_type"><?php _e('Product Type', 'voxel-toolkit'); ?></option>
                                            <option value="booking_type"><?php _e('Booking Type', 'voxel-toolkit'); ?></option>
                                            <option value="stock"><?php _e('Stock Status', 'voxel-toolkit'); ?></option>
                                            <option value="calendar"><?php _e('Calendar Type', 'voxel-toolkit'); ?></option>
                                            <option value="summary"><?php _e('Summary (Type + Price)', 'voxel-toolkit'); ?></option>
                                        </select>
                                    </div>
                                </div>

                                <!-- Work Hours Settings (only for work-hours fields) -->
                                <div v-if="isWorkHoursField(element.field_key) && element.work_hours_settings" class="vt-ac-product-settings">
                                    <h4><?php _e('Work Hours Display', 'voxel-toolkit'); ?></h4>
                                    <div class="vt-ac-field-group">
                                        <label><?php _e('Show', 'voxel-toolkit'); ?></label>
                                        <select v-model="element.work_hours_settings.display" @change="markChanged">
                                            <option value="status"><?php _e('Current Status (Open/Closed)', 'voxel-toolkit'); ?></option>
                                            <option value="today"><?php _e("Today's Hours", 'voxel-toolkit'); ?></option>
                                            <option value="badge"><?php _e('Hours Set (Badge)', 'voxel-toolkit'); ?></option>
                                        </select>
                                    </div>
                                </div>

                                <!-- Location Settings (only for location fields) -->
                                <div v-if="isLocationField(element.field_key) && element.location_settings" class="vt-ac-product-settings">
                                    <h4><?php _e('Location Display', 'voxel-toolkit'); ?></h4>
                                    <div class="vt-ac-field-group">
                                        <label><?php _e('Show', 'voxel-toolkit'); ?></label>
                                        <select v-model="element.location_settings.display" @change="markChanged">
                                            <option value="address"><?php _e('Address', 'voxel-toolkit'); ?></option>
                                            <option value="coordinates"><?php _e('Coordinates (Lat, Long)', 'voxel-toolkit'); ?></option>
                                            <option value="latitude"><?php _e('Latitude Only', 'voxel-toolkit'); ?></option>
                                            <option value="longitude"><?php _e('Longitude Only', 'voxel-toolkit'); ?></option>
                                            <option value="full"><?php _e('Address + Coordinates', 'voxel-toolkit'); ?></option>
                                        </select>
                                    </div>
                                </div>

                                <!-- Date Settings (only for date fields) -->
                                <div v-if="isDateField(element.field_key) && element.date_settings" class="vt-ac-product-settings">
                                    <h4><?php _e('Date Display', 'voxel-toolkit'); ?></h4>
                                    <div class="vt-ac-field-group">
                                        <label><?php _e('Show', 'voxel-toolkit'); ?></label>
                                        <select v-model="element.date_settings.display" @change="markChanged">
                                            <option value="date"><?php _e('Date Only', 'voxel-toolkit'); ?></option>
                                            <option value="datetime"><?php _e('Date & Time', 'voxel-toolkit'); ?></option>
                                            <option value="relative"><?php _e('Relative (e.g., 2 days ago)', 'voxel-toolkit'); ?></option>
                                        </select>
                                    </div>
                                </div>

                                <!-- Recurring Date / Event Date Settings -->
                                <div v-if="isRecurringDateField(element.field_key) && element.recurring_date_settings" class="vt-ac-product-settings">
                                    <h4><?php _e('Event Display', 'voxel-toolkit'); ?></h4>
                                    <div class="vt-ac-field-group">
                                        <label><?php _e('Show', 'voxel-toolkit'); ?></label>
                                        <select v-model="element.recurring_date_settings.display" @change="markChanged">
                                            <option value="start_date"><?php _e('Start Date', 'voxel-toolkit'); ?></option>
                                            <option value="start_datetime"><?php _e('Start Date & Time', 'voxel-toolkit'); ?></option>
                                            <option value="end_date"><?php _e('End Date', 'voxel-toolkit'); ?></option>
                                            <option value="end_datetime"><?php _e('End Date & Time', 'voxel-toolkit'); ?></option>
                                            <option value="date_range"><?php _e('Date Range', 'voxel-toolkit'); ?></option>
                                            <option value="frequency"><?php _e('Frequency (e.g., Weekly until...)', 'voxel-toolkit'); ?></option>
                                            <option value="multiday"><?php _e('Multi-day Status', 'voxel-toolkit'); ?></option>
                                            <option value="allday"><?php _e('All Day Status', 'voxel-toolkit'); ?></option>
                                            <option value="summary"><?php _e('Summary (Date + Badges)', 'voxel-toolkit'); ?></option>
                                        </select>
                                    </div>
                                </div>

                                <!-- Listing Plan Settings -->
                                <div v-if="isListingPlanField(element.field_key) && element.listing_plan_settings" class="vt-ac-product-settings">
                                    <h4><?php _e('Listing Plan Display', 'voxel-toolkit'); ?></h4>
                                    <div class="vt-ac-field-group">
                                        <label><?php _e('Show', 'voxel-toolkit'); ?></label>
                                        <select v-model="element.listing_plan_settings.display" @change="markChanged">
                                            <option value="plan_name"><?php _e('Plan Name', 'voxel-toolkit'); ?></option>
                                            <option value="amount"><?php _e('Amount Paid', 'voxel-toolkit'); ?></option>
                                            <option value="frequency"><?php _e('Billing Frequency', 'voxel-toolkit'); ?></option>
                                            <option value="purchase_date"><?php _e('Purchase Date', 'voxel-toolkit'); ?></option>
                                            <option value="expiration"><?php _e('Expiration Date', 'voxel-toolkit'); ?></option>
                                            <option value="summary"><?php _e('Summary (Plan + Price)', 'voxel-toolkit'); ?></option>
                                        </select>
                                    </div>
                                </div>

                                <!-- Toggles - Always enabled -->
                                <div class="vt-ac-toggles">
                                    <label class="vt-ac-toggle">
                                        <input type="checkbox"
                                               v-model="element.sortable"
                                               @change="markChanged">
                                        {{ vtAdminColumns.i18n.sortable }}
                                    </label>

                                    <label class="vt-ac-toggle">
                                        <input type="checkbox"
                                               v-model="element.filterable"
                                               @change="markChanged">
                                        {{ vtAdminColumns.i18n.filterable }}
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Add Column Button -->
                    <button @click="addColumn" class="vt-ac-add-column">
                        + {{ vtAdminColumns.i18n.addColumn }}
                    </button>
                </div>
            </div>

            <!-- Sidebar -->
            <div class="vt-ac-sidebar">
                <!-- Save Card -->
                <div class="vt-ac-sidebar-card">
                    <h3><?php _e('Actions', 'voxel-toolkit'); ?></h3>

                    <button @click="saveConfig"
                            :disabled="saving || columns.length === 0"
                            class="button button-primary vt-ac-save-button"
                            :class="{ saved: saveStatus === 'saved', error: saveStatus === 'error' }">
                        <span v-if="saving">{{ vtAdminColumns.i18n.saving }}</span>
                        <span v-else-if="saveStatus === 'saved'">{{ vtAdminColumns.i18n.saved }}</span>
                        <span v-else>{{ vtAdminColumns.i18n.save }}</span>
                    </button>

                    <a href="#" @click.prevent="restoreDefaults" class="vt-ac-restore-link">
                        {{ vtAdminColumns.i18n.restoreDefaults }}
                    </a>

                    <div v-if="hasChanges && !saving" class="vt-ac-status" style="margin-top: 12px; background: #fff8e5; color: #8a6d3b;">
                        <?php _e('You have unsaved changes.', 'voxel-toolkit'); ?>
                    </div>
                </div>

                <!-- Help Card -->
                <div class="vt-ac-sidebar-card">
                    <h3><?php _e('How it works', 'voxel-toolkit'); ?></h3>
                    <p style="font-size: 13px; color: #666; margin: 0;">
                        <?php _e('Drag columns to reorder them. Click a column to expand its settings. Changes are applied immediately when you click Save.', 'voxel-toolkit'); ?>
                    </p>
                </div>

                <!-- Column Count -->
                <div class="vt-ac-sidebar-card">
                    <h3><?php _e('Column Summary', 'voxel-toolkit'); ?></h3>
                    <p style="font-size: 13px; color: #666; margin: 0;">
                        <strong>{{ columns.length }}</strong> <?php _e('columns configured', 'voxel-toolkit'); ?>
                        <br>
                        <strong>{{ availableFields.length }}</strong> <?php _e('fields available', 'voxel-toolkit'); ?>
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>
